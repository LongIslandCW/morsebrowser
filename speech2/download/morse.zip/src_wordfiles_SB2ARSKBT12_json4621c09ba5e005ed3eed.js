"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ARSKBT12_json"],{

/***/ "./src/wordfiles/SB2ARSKBT12.json":
/*!****************************************!*\
  !*** ./src/wordfiles/SB2ARSKBT12.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb<ar><sk><bt>73?qxv59,kmy4028bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);