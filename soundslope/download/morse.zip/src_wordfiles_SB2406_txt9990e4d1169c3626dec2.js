"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2406_txt"],{

/***/ "./src/wordfiles/SB2406.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2406.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL AK AR CA CO CT DE FL GA HI ID IL IN IA KS LA NE NV NH NM NC ND OH PA RI SC SD TN UT WA WI";

/***/ })

}]);