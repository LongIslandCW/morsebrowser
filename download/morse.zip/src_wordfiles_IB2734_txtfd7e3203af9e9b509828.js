"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2734_txt"],{

/***/ "./src/wordfiles/IB2734.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2734.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AC3D N3GE N3IOE N7RD AB7NT K7MY KB7YM N3KM WB3KMY WB3WUB WB3OHF KB3ERA AA7TIN AC7CLD AB7CDL WB3EAR N3FOH N7CDL";

/***/ })

}]);