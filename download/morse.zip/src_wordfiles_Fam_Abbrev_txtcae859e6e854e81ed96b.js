"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Abbrev_txt"],{

/***/ "./src/wordfiles/Fam_Abbrev.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/Fam_Abbrev.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "\r\n599 \n{599|} \n{599|} \n{|} \r\n73 \n{73|} \n{73|} \n{|} \r\n5NN \n{5NN|} \n{5NN|} \n{|} \r\nABT \n{ABT|} \n{ABT|} \n{|} \r\nAGN \n{AGN|} \n{AGN|} \n{|} \r\nANT \n{ANT|} \n{ANT|} \n{|} \r\nB4 \n{B4|} \n{B4|} \n{|} \r\n{BCNU|be seeing you} \n{BCNU|} \n{BCNU|} \n{|} \r\nCFM \n{CFM|} \n{CFM|} \n{|} \r\nCPI \n{CPI|} \n{CPI|} \n{|} \r\nCPY \n{CPY|} \n{CPY|} \n{|} \r\nCQ \n{CQ|} \n{CQ|} \n{|} \r\nCU \n{CU|} \n{CU|} \n{|} \r\nCUAGN \n{CUAGN|} \n{CUAGN|} \n{|} \r\nCUL \n{CUL|} \n{CUL|} \n{|} \r\nCW \n{CW|} \n{CW|} \n{|} \r\nDE \n{DE|} \n{DE|} \n{|} \r\nDX \n{DX|} \n{DX|} \n{|} \r\nES \n{ES|} \n{ES|} \n{|} \r\nFB \n{FB|} \n{FB|} \n{|} \r\nFER \n{FER|} \n{FER|} \n{|} \r\nFT \n{FT|} \n{FT|} \n{|} \r\nGA \n{GA|} \n{GA|} \n{|} \r\nGE \n{GE|} \n{GE|} \n{|} \r\nGM \n{GM|} \n{GM|} \n{|} \r\nGN \n{GN|} \n{GN|} \n{|} \r\nGUD \n{GUD|} \n{GUD|} \n{|} \r\nHR \n{HR|} \n{HR|} \n{|} \r\nHW \n{HW|} \n{HW|} \n{|} \r\n{HW?|how copy} \n{HW?|} \n{HW?|} \n{|} \r\nPSE \n{PSE|} \n{PSE|} \n{|} \r\nPWR \n{PWR|} \n{PWR|} \n{|} \r\nRPRT \n{RPRT|} \n{RPRT|} \n{|} \r\nRPT \n{RPT|} \n{RPT|} \n{|} \r\nRST \n{RST|} \n{RST|} \n{|} \r\nRX \n{RX|} \n{RX|} \n{|} \r\nSIG \n{SIG|} \n{SIG|} \n{|} \r\nSKED \n{SKED|} \n{SKED|} \n{|} \r\nSRI \n{SRI|} \n{SRI|} \n{|} \r\nTEMP \n{TEMP|} \n{TEMP|} \n{|} \r\nTKS \n{TKS|} \n{TKS|} \n{|} \r\nTNX \n{TNX|} \n{TNX|} \n{|} \r\nTU \n{TU|} \n{TU|} \n{|} \r\nTX \n{TX|} \n{TX|} \n{|} \r\nUR \n{UR|} \n{UR|} \n{|} \r\nVERT \n{VERT|} \n{VERT|} \n{|} \r\nVY \n{VY|} \n{VY|} \n{|} \r\nWID \n{WID|} \n{WID|} \n{|} \r\nWUD \n{WUD|} \n{WUD|} \n{|} \r\nWX \n{WX|} \n{WX|} \n{|} \r\nYRS \n{YRS|} \n{YRS|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);