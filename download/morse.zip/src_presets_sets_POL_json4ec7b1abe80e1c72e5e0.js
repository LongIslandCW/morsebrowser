"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_POL_json"],{

/***/ "./src/presets/sets/POL.json":
/*!***********************************!*\
  !*** ./src/presets/sets/POL.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"BINOMIALS Flow Rate 1","filename":"POL_Random_3x_27.json"},{"display":"BINOMIALS Flow Rate 2","filename":"POL_Random_3x_31.json"},{"display":"CHARACTERS Flow Rate 1","filename":"POL_27.json"},{"display":"CHARACTERS Flow Rate 2","filename":"POL_31.json"},{"display":"PHRASES/WORDS 2X Flow Rate 1","filename":"POL_Random_2x_27.json"},{"display":"PHRASES/WORDS 2X Flow Rate 2","filename":"POL_Random_2x_31.json"},{"display":"PHRASES/WORDS 3X Flow Rate 1","filename":"POL_Random_3x_27.json"},{"display":"PHRASES/WORDS 3X Flow Rate 2","filename":"POL_Random_3x_31.json"},{"display":"PHRASES CW-VOICE-CW Flow Rate 1","filename":"POL_Random_1x_CVC_27.json"},{"display":"PHRASES CW-VOICE-CW Flow Rate 2","filename":"POL_Random_1x_CVC_31.json"},{"display":"SENDING ALPHABET Flow Rate 1","filename":"POL_27_SA.json"},{"display":"SENDING ALPHABET Flow Rate 2","filename":"POL_31_SA.json"},{"display":"SENDING NUMBERS Flow Rate 1","filename":"POL_27_SN.json"},{"display":"SENDING NUMBERS Flow Rate 2","filename":"POL_31_SN.json"},{"display":"SENDING WORDS/PHRASES Flow Rate 1","filename":"POL_Random_1x_VCS_27.json"},{"display":"SENDING WORDS/PHRASES Flow Rate 2","filename":"POL_Random_1x_VCS_31.json"},{"display":"SENTENCES CW-VOICE-CW Flow Rate 1","filename":"POL_Random_Sen_1x_CVC_27.json"},{"display":"SENTENCES CW-VOICE-CW Flow Rate 2","filename":"POL_Random_Sen_1x_CVC_31.json"},{"display":"SUFFIXES Flow Rate 1","filename":"POL_Random_3x_27.json"},{"display":"SUFFIXES Flow Rate 2","filename":"POL_Random_3x_31.json"},{"display":"VOICE AFTER WORDS Flow Rate 1","filename":"POL_VA_Random_3x_27.json"},{"display":"VOICE AFTER WORDS Flow Rate 2","filename":"POL_VA_Random_3x_31.json"}]}');

/***/ })

}]);