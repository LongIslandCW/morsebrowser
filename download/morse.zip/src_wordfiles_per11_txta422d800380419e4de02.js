"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per11_txt"],{

/***/ "./src/wordfiles/per11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/per11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "VV\n4VV4\nSHJW\n7Z8Z\nCYHV\n454V\nV4SH\n";

/***/ })

}]);