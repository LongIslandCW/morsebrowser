"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY5_txt"],{

/***/ "./src/wordfiles/SB2KMY5.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2KMY5.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "AL AK AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NH NM NY NC ND OH OK PA RI SC SD TN UT WA WI WY\n\n";

/***/ })

}]);