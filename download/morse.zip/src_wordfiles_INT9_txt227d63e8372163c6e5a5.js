"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT9_txt"],{

/***/ "./src/wordfiles/INT9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AL \nAK \nAZ \nAR \nCA \nCO \nCT \n{DE|delaware}\nFL \n{GA|georgia} \n{HI|hawaii} \n{ID|idaho}\nIL \n{IN|indiana} \nIA \nKS \nKY \n{LA|louisiana}\n{ME|maine}\nMD \nMA \nMI \nMN \nMS \nMO \nMT \nNE \nNV \nNH \nNJ \nNM \nNY \nNC \nND \n{OH|ohio} \n{OK|oklahoma}  \nPA \nRI \nSC \nSD \nTN \nTX \nUT \nVT \nVA \nWA \nWV \nWI \nWY\n";

/***/ })

}]);