"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ARSKBT4_txt"],{

/***/ "./src/wordfiles/SB2ARSKBT4.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/SB2ARSKBT4.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "NICE TO CU AGN <BT> OP RIN <BT> RIG KNWD ES ANT DIPOLE UP IN TREE <BT> RETIRED AIR FORCE <BT> RIG TEN TEC <BT> TU FER INFO <BT> HPE CUAGN DR BOB <AR> HPE CUAGN DR HIRO san <AR>";

/***/ })

}]);