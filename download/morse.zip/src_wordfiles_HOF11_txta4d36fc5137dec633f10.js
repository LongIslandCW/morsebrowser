"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_HOF11_txt"],{

/***/ "./src/wordfiles/HOF11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/HOF11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "COLD CHOPS  \nDOC FOLDS  \nGOLF SCOOPS  \nSLOP HOGS\nGOLD LOGS  \nDOGS FLOP  \nOLOF SCOLDS  \nOP FLOSS\nOLD DOGS  \nDOC SHOPS  \nCOLD FOG  \nCOD SHOP\nSCOLD DOC  \nPOSH DOGS  \nCOLD CLOGS  \nGOLF SHOP\n";

/***/ })

}]);