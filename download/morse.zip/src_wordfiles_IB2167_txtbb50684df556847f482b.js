"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2167_txt"],{

/***/ "./src/wordfiles/IB2167.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2167.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC \nGA BOB \nOP ALAN \nANT DIPOLE UP 61 FT\nPWR 1W HI HI\nHPE CUAGN BOB\nPSE RPT INFO\nPSE RPT RIG ES ANT\nPSE RPT CALL\nPWR 1TT W  \n";

/***/ })

}]);