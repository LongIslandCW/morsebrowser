"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY7_txt"],{

/***/ "./src/wordfiles/IB2KMY7.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2KMY7.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "MY RIG KNWD <BT> ANT DIPOLE <BT> ANT YAGI <BT> OK OM SOLID CPY <BT> SOLID CPI <BT> FB CATHY <BT> NAME MIKE <BT> NAME HOWARD <BT> NAME RICH <BT> BEEN HAM TWO YRS <BT> SRI OM <BT> MY RIG ICOM <BT> MY RIG YAESU <BT> MY RIG TEN TEC <BT> MY RIG BOAT ANCHOR <BT> MY KEY BUG <BT> NICE SIG OM";

/***/ })

}]);