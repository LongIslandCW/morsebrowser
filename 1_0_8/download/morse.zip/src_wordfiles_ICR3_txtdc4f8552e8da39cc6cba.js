"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR3_txt"],{

/***/ "./src/wordfiles/ICR3.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR3.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A\r\nI\r\nAT\r\nIT\r\nNO\r\nTO\r\nAS\r\nSO\r\nOR\r\nAN\r\nON\r\nIN\r\nIS\r\n";

/***/ })

}]);