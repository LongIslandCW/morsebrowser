"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_REA11_txt"],{

/***/ "./src/wordfiles/REA11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/REA11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "RR FB\r\nHW R U\r\nHR ROB\r\nFB OB\r\nHW\r\nFER WHO\r\nUR HERE\r\nHW ARE U\r\nHEAR BOB\r\nWEAR ROBE\r\nBARE BEAR\r\nBREW BEER\r\nWORE FUR\r\nFEAR WAR\r\nOWE ROB\r\nEURO FARE\r\nHEAR HERB\r\nFOR WHO\r\nFAR WHARF\r\nEAR FUR\r\n";

/***/ })

}]);