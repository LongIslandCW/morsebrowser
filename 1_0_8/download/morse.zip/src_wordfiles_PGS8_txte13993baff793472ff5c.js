"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PGS8_txt"],{

/***/ "./src/wordfiles/PGS8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/PGS8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AR \r\nGA\r\n{IN|indiana} \r\nIA\r\nNE\r\nPA\r\nRI\r\nTN\r\n";

/***/ })

}]);