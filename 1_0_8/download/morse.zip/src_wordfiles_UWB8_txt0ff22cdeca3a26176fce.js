"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_UWB8_txt"],{

/***/ "./src/wordfiles/UWB8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/UWB8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CO \r\nFL\r\n{OH|ohio} \r\n";

/***/ })

}]);