"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2737_txt"],{

/***/ "./src/wordfiles/IB2737.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2737.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "73 ES HP CUAGN\r\nHW?\r\nAC3D DE N3GE\r\nAGE 37\r\nANT DIPOLE UP 73 FT\r\nANT EFHW UP 37 FT\r\nANT WIRE IN ATTIC\r\nAGE 73 RETIRED DOCTOR\r\nPSE RPT RIG ES ANT?\r\nOP FLIP\r\nRIG TEN TEC\r\nSOLID SIG HR\r\nCOLD ES RAIN 3 C\r\nCUL DR SOCHO\r\n";

/***/ })

}]);