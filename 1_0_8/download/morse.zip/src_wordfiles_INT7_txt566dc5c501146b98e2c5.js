"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT7_txt"],{

/***/ "./src/wordfiles/INT7.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT7.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "some\r\nthan\r\nin\r\nnow\r\none\r\nback\r\nof\r\nall\r\nup\r\njust\r\nalso\r\nwhat\r\nlike\r\nthen\r\nme\r\nits\r\nmost\r\nafter\r\nother\r\nwould\r\nuse\r\nus\r\nshe\r\nhave\r\nan\r\nhe\r\nhow\r\nby\r\ncould\r\nhis\r\nnot\r\nno\r\nperson\r\non\r\nwork\r\ngood\r\nknow\r\nwhen\r\nI\r\nlook\r\ngo\r\nday\r\ncome\r\nover\r\nsay\r\nto\r\nfor\r\nabout\r\nthem\r\ncan\r\ninto\r\nway\r\nthere\r\nfrom\r\nour\r\nmy\r\nsee\r\nany\r\nbe\r\nget\r\nas\r\nit\r\nonly\r\nfirst\r\nif\r\nat\r\na\r\nthe\r\nyou\r\nout\r\nwill\r\nwith\r\nher\r\nwe\r\nthink\r\ntime\r\nwho\r\ntheir\r\nwell\r\ndo\r\neven\r\nor\r\nbut\r\nthat\r\nwhich\r\ngive\r\ntwo\r\nso\r\nhim\r\nthis\r\nyear\r\nyour\r\nthese\r\nwant\r\nthey\r\nmake\r\nand\r\nnew\r\nbecause\r\ntake\r\n";

/***/ })

}]);