"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB25914_json"],{

/***/ "./src/wordfiles/SB25914.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB25914.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,kmy4028bkzj/16.<ar><sk><bt>73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);