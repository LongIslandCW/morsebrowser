"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C8_txt"],{

/***/ "./src/wordfiles/IB2C8.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C8.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "AL AK AZ AR CA CO CT DE FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY NC ND OH OK PA RI SC SD TN TX UT VT VA WA WV WI WY\r\n";

/***/ })

}]);