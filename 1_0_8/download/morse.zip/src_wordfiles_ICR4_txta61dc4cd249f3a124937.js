"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR4_txt"],{

/***/ "./src/wordfiles/ICR4.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR4.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A\r\nI\r\nAT\r\nIT\r\nNO\r\nTO\r\nAS\r\nSO\r\nOR\r\nAN\r\nON\r\nIN\r\nIS\r\nANT\r\nTOE\r\nONE\r\nRAT\r\nSAT\r\nEAT\r\nSIT\r\nCAR\r\nACE\r\nCAT\r\nOAR\r\nSET\r\nARE\r\nSEE\r\nACT\r\nTAN\r\nRAN\r\nEEL\r\nNOR\r\nTIN\r\nATE\r\nCAN\r\nOIL\r\nILL\r\nLOT\r\nCOT\r\nNOT\r\nTEN\r\nLIE\r\nALL\r\nITS\r\n\r\n";

/***/ })

}]);