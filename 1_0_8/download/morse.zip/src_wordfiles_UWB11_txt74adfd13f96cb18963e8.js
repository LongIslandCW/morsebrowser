"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_UWB11_txt"],{

/***/ "./src/wordfiles/UWB11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/UWB11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "CUL BOB  \r\nWUD FLOW  \r\nCUD U  \r\nHW LOW  \r\nLOUD CW  \r\nCU DOC  \r\nCUD FOLD  \r\nFB BUD  \r\nWL HOWL\r\nWOLF HOWL  \r\nOLD BOWL  \r\nWHO WOULD  \r\nBOLD BOW\r\nDOC COULD  \r\nCOLD COD  \r\nFOUL BOWL  \r\nLOW CLOUD\r\n";

/***/ })

}]);