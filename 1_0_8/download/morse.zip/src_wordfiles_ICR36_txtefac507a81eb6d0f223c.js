"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR36_txt"],{

/***/ "./src/wordfiles/ICR36.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR36.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "TBUE \r\nUI6U \r\nV55T \r\nSVT4 \r\n44HS \r\nI46B \r\nH4S5 \r\nDJWJ \r\nID15 \r\n4J1U \r\nBUWI \r\nUJDT \r\nEE61 \r\nDUIH \r\nEBEB \r\n6WTJ \r\n1V1T \r\n64T6 \r\nT4EJ \r\nT6VV \r\nWSIW \r\nWSU4 \r\nHTWI \r\nUWHD \r\nTH6D \r\nB4WS \r\nHTI6 \r\nB5EV \r\nBEDB \r\n4DU6 \r\n44D5 \r\nIH6D \r\nI1JT \r\nDSVI \r\nJETU \r\nBE64 \r\nD64U \r\n1VSH \r\nDV4B \r\nUWHH \r\n14U1 \r\n5JDU \r\n5EI1 \r\nE4JE \r\nT5WI \r\nBEH1 \r\nU4W4 \r\n45HV \r\nSJW1 \r\n5JBI \r\nTUI6 \r\n54I4 \r\nWJUI \r\nST4J \r\nI6E1 \r\n44BU \r\nDDVS \r\nTJVT \r\nEDVH \r\nDWBT \r\nHDS5 \r\n6WS6 \r\nEHV5 \r\nJD4H \r\nVIBU \r\nB45E \r\nDE1T \r\nHU1W \r\n6EIV \r\nVETH \r\nIT4I \r\nVWHW \r\nTW5V \r\nSEJB \r\nT51E \r\nU4BD \r\nHSEW \r\nW41V \r\nIJ6E \r\nIVHT \r\nHIBH \r\nHB1J \r\n5SVT \r\nEJVS \r\nWJ6B \r\nE65J \r\n516U \r\nE15U \r\nVW1S \r\nI1IJ \r\nVDJ1 \r\nJBBV \r\nBE1H \r\nEU4B \r\n5EUV \r\nU5V4 \r\nVT5W \r\n66HV \r\nW1JJ \r\nUHU4 \r\nDUW6 \r\nBVUD \r\nJBI4 \r\nT56T \r\nE4TD \r\n4H51 \r\nDD6V \r\nE4WD \r\nDUVT \r\nBD4H \r\n5W6H \r\n4EHW \r\nUSEE \r\nED6V \r\nBEVH \r\nVIT4 \r\nEUES \r\nWDV4 \r\nIEHD \r\nSW5S \r\nWUVS \r\nUHBV \r\nS65E \r\nH6JU \r\nDD4E \r\nEW1B \r\nBUHD \r\nBID4 \r\nEE45 \r\nHUH5 \r\nHTEH \r\nVU1U \r\nH5T5 \r\n6EUH \r\n5SW5 \r\nI6SV \r\nWTDE \r\n1S4J \r\n1ITV \r\nS44S \r\n6IH6 \r\nHSEB \r\n4EBH \r\nV66W \r\nH1S4 \r\nHWBW \r\nTIHW \r\nJIBS \r\nVJ1J \r\nTDUJ \r\nJDT6 \r\nDHS4 \r\n6JSB \r\nWETT \r\n6J4E \r\nTTVD \r\n6EHE \r\nT1HT \r\n64T1 \r\nVITU \r\n4JEJ \r\n5ITJ \r\nVT56 \r\nVJDV \r\n5H56 \r\n6SEB \r\n4EDI \r\nHST4 \r\nV4DU \r\nWBV4 \r\n5UTS \r\n14D5 \r\nSIJS \r\n5WI1 \r\n66WE \r\nV4W1 \r\nI1BB \r\n65DE \r\nUT4B \r\n4DBB \r\nEJVJ \r\n6U6S \r\nISWJ \r\nSHBD \r\nDWTE \r\nUEJI \r\nVWTD \r\nTB1I \r\nI4DS \r\nSI1V \r\nTWWV \r\nTIH5 \r\nJWBV \r\nI4WJ \r\n6H4I \r\nVIBE \r\nIHTW \r\nTIVH \r\n1EDH \r\n4UIV \r\n";

/***/ })

}]);