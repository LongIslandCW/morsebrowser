"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PGS11_txt"],{

/***/ "./src/wordfiles/PGS11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/PGS11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "PATS AGE  \r\nANT RPRT  \r\nGN GREG  \r\nAGN PSE\r\nSRI PSE AGN  \r\nGE PETE  \r\nRR RST  \r\nAGE AGN\r\nSIG RPRT PSE  \r\nGA PAGE  \r\nRR RIG  \r\nRPT RST PSE\r\nSNAP PEAS  \r\nSNAG PIES  \r\nPRINT PENS  \r\nPARENTS GASP\r\nPAINT PANS  \r\nSPIN PETS  \r\nEAT GRAPES  \r\nPEN PAGE\r\nPETER GRINS  \r\nNATE SANG  \r\nPATS PAINTS  \r\nPIRATES RING\r\n";

/***/ })

}]);