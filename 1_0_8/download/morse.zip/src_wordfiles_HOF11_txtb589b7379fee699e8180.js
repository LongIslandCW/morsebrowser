"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_HOF11_txt"],{

/***/ "./src/wordfiles/HOF11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/HOF11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "COLD CHOPS  \r\nDOC FOLDS  \r\nGOLF SCOOPS  \r\nSLOP HOGS\r\nGOLD LOGS  \r\nDOGS FLOP  \r\nOLOF SCOLDS  \r\nOP FLOSS\r\nOLD DOGS  \r\nDOC SHOPS  \r\nCOLD FOG  \r\nCOD SHOP\r\nSCOLD DOC  \r\nPOSH DOGS  \r\nCOLD CLOGS  \r\nGOLF SHOP\r\n";

/***/ })

}]);