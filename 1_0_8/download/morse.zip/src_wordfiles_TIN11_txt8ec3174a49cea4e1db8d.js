"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN11_txt"],{

/***/ "./src/wordfiles/TIN11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/TIN11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "NEW NET   \r\nRR TU  \r\nABT U  \r\nUR ANT  \r\nRU NEW\r\nURBAN TRIBE  \r\nBEEN ABT  \r\nATE BURNT  \r\nEAT TUNA  \r\nTAN TUBER  \r\nWET WATER  \r\nTU NATE  \r\nEA TUNE\r\nU WRITE  \r\nEA WINE  \r\nUNTIE BRENT  \r\nUR EAR  \r\nEA BEAR \r\n";

/***/ })

}]);