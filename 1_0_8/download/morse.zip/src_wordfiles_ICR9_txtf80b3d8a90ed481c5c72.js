"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR9_txt"],{

/***/ "./src/wordfiles/ICR9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "NO TELL\r\nEARN A REST\r\nA CATS TAIL\r\nA CORE ROLE\r\nLET IT REST\r\nTELL IT ALL\r\nNOT ONE IOTA\r\nEASE INTO IT\r\nA COST I LOST\r\nI LOST A RACE\r\nTEAR IN A TIRE\r\nA SCAN AT NOON\r\nEAT IT OR ELSE\r\nA TEN CENT LOAN\r\nTOO SORE TO SIT\r\nI CANT CARE LESS\r\nONE ACRE TO A LOT\r\nI LOST A TEST LIST\r\nSLOT CARS ARE COOL\r\nLETS RACE TO A TREE\r\nIT ISNT A REAL NAIL\r\nITS TOO LATE TO EAT\r\nITS A REAL RAT RACE\r\nA LENS CAN TEAR\r\nA LION IS NOT AN ANT\r\nA COOT SAT ON A SEAT\r\nITS A REAL TEST TONE\r\nOIL IN A CAN\r\nLIE ON A COT IN RAIN \r\nA LAST ONE CAN ROLL IN\r\nA NEAT AREA TO SAIL IN\r\nLAST ONE TO LOSE A RACE\r\nCORN IN AN AREA\r\nIS IT A TALL TALE OR NOT\r\nLETS SIT ON A SEAT TO EAT\r\nA COOL CAT ATE A RATS TAIL\r\n\r\n\r\n";

/***/ })

}]);