"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR1_txt"],{

/***/ "./src/wordfiles/ICR1.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR1.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "E\r\nA\r\nR\r\nI\r\nO\r\nT\r\nN\r\nS\r\nC\r\nL\r\n";

/***/ })

}]);