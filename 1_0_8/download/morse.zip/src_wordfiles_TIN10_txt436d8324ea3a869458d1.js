"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN10_txt"],{

/***/ "./src/wordfiles/TIN10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/TIN10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "BUT NEW EAT WET AIR TUNE TUNER TIN WIRE WENT BURN TEN ART WATER TRAIN NUT BAIT RENT\r\n";

/***/ })

}]);