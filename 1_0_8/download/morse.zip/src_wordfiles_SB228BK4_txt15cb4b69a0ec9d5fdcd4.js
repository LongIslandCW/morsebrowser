"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK4_txt"],{

/***/ "./src/wordfiles/SB228BK4.txt":
/*!************************************!*\
  !*** ./src/wordfiles/SB228BK4.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "HOWARD BTU BK\r\nBK FB RICH AGE 28 RETIRED HI HI BK\r\nBK FB ES TU FER INFO UR RIG DOING FB BK\r\nBK RR UR ANT DOING FB WID GUD SIG HR BK\r\nBK ANT EFHW IN ATTIC BK\r\n";

/***/ })

}]);