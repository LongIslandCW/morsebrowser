"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD11_txt"],{

/***/ "./src/wordfiles/LCD11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/LCD11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "GN LINDI  \r\nSTN SIGN  \r\nGL CLINT  \r\nSPLIT STN \r\nSIG DIPS  \r\nPIGS SPIT  \r\nCLIP PINS \r\nSPIN DITS  \r\nSPLIT LIPS  \r\nPINT LIDS  \r\nLINDI SINGS\r\nGIN PINTS  \r\nCLINT SLID  \r\nPIG LINT  \r\nTIN CLIPS\r\nTIPS CLING  \r\nITS LINT  \r\nNIL PICS  \r\nSPLIT TIPS\r\nSIT SID  \r\nSIGN CLIP  \r\nPICS LIST  \r\nSIP PINTS\r\n";

/***/ })

}]);