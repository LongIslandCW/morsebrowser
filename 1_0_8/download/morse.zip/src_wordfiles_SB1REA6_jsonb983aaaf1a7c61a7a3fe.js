"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1REA6_json"],{

/***/ "./src/wordfiles/SB1REA6.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1REA6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);