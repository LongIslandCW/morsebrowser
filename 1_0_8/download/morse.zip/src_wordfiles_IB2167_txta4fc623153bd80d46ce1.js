"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2167_txt"],{

/***/ "./src/wordfiles/IB2167.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2167.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC \r\nGA BOB \r\nOP ALAN \r\nANT DIPOLE UP 61 FT\r\nPWR 1W HI HI\r\nHPE CUAGN BOB\r\nPSE RPT INFO\r\nPSE RPT RIG ES ANT\r\nPSE RPT CALL\r\nPWR 1TT W  \r\n";

/***/ })

}]);