"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR11_txt"],{

/***/ "./src/wordfiles/ICR11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);