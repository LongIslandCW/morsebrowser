"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Word_04_txt"],{

/***/ "./src/wordfiles/INT3_1 Word_04.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT3_1 Word_04.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "drunk {safely|} \r\n{|drunk safely} \r\nsurely {freedom|} \r\n{|surely freedom} \r\nseason {living|} \r\n{|season living} \r\nwhile {stranger|} \r\n{|while stranger} \r\nhabitat {motion|} \r\n{|habitat motion} \r\novernight {circuit|} \r\n{|overnight circuit} \r\nhonor {pension|} \r\n{|honor pension} \r\nnightmare {awareness|} \r\n{|nightmare awareness} \r\nepidemic {Islam|} \r\n{|epidemic Islam} \r\nencounter {charge|} \r\n{|encounter charge} ";

/***/ })

}]);