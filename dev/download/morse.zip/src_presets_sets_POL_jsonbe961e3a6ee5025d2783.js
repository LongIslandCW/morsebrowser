"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_POL_json"],{

/***/ "./src/presets/sets/POL.json":
/*!***********************************!*\
  !*** ./src/presets/sets/POL.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"CHARACTERS 27 wpm","filename":"POL_27.json"},{"display":"WORDS 27 wpm","filename":"POL_27_WORDS.json"},{"display":"BINOMIALS 27 wpm","filename":"POL_27_BI.json"},{"display":"CHARACTERS 31 wpm","filename":"POL_31.json"},{"display":"WORDS 31 wpm","filename":"POL_31_WORDS.json"},{"display":"BINOMIALS 31 wpm","filename":"POL_31_BI.json"},{"display":"SENDING ALPHABET 27 wpm","filename":"POL_27_SA.json"},{"display":"SENDING NUMBERS 27 wpm","filename":"POL_27_SN.json"},{"display":"SENDING ALPHABET 31 wpm","filename":"POL_31_SA.json"},{"display":"SENDING NUMBERS 31 wpm","filename":"POL_31_SN.json"}]}');

/***/ })

}]);