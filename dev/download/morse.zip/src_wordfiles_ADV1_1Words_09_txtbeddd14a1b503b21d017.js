"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_09_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_09.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_09.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "hazard {whenever|} \r\n{|hazard whenever} \r\nterror {address|} \r\n{|terror address} \r\nOlympics {meanwhile|} \r\n{|Olympics meanwhile} \r\ntestify {sleeve|} \r\n{|testify sleeve} \r\nrailroad {situation|} \r\n{|railroad situation} \r\nidentity {yellow|} \r\n{|identity yellow} \r\nrocket {legend|} \r\n{|rocket legend} \r\nsupport {minimum|} \r\n{|support minimum} \r\nextension {promote|} \r\n{|extension promote} \r\ncollapse {straighten|} \r\n{|collapse straighten} ";

/***/ })

}]);