"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ICR_json"],{

/***/ "./src/presets/sets/ICR+.json":
/*!************************************!*\
  !*** ./src/presets/sets/ICR+.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Spell 12 wpm","filename":"ICR+_12.json"},{"display":"Words 12 wpm","filename":"ICR+_12_Words.json"},{"display":"Spell 16 wpm","filename":"ICR+_16.json"},{"display":"Words 16 wpm","filename":"ICR+_16_Words.json"},{"display":"Spell 18 wpm","filename":"ICR+_18.json"},{"display":"Words 18 wpm","filename":"ICR+_18_Words.json"},{"display":"Spell 20 wpm","filename":"ICR+_20.json"},{"display":"Words 20 wpm","filename":"ICR+_20_Words.json"}]}');

/***/ })

}]);