"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY8_json"],{

/***/ "./src/wordfiles/SB2KMY8.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2KMY8.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy4028bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);