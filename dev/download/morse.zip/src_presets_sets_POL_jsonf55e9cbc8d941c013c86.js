"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_POL_json"],{

/***/ "./src/presets/sets/POL.json":
/*!***********************************!*\
  !*** ./src/presets/sets/POL.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"BINOMIALS 27 wpm","filename":"POL_27_BI.json"},{"display":"BINOMIALS 31 wpm","filename":"POL_31_BI.json"},{"display":"CHARACTERS 27 wpm","filename":"POL_27.json"},{"display":"WORDS 27 wpm","filename":"POL_27_WORDS.json"},{"display":"CHARACTERS 31 wpm","filename":"POL_31.json"},{"display":"WORDS 31 wpm","filename":"POL_31_WORDS.json"}]}');

/***/ })

}]);