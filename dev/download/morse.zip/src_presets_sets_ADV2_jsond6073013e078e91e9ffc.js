"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV2_json"],{

/***/ "./src/presets/sets/ADV2.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 30/30","filename":"ADV2BUF.json"},{"display":"Affixes","filename":"ADV2BUF.json"},{"display":"Familiarity Phrases","filename":"ADV2_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"ADV2_FAM_Sentences.json"},{"display":"Familiarity Spell","filename":"ADV2_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV2_FAM_WORDS.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Multi Words","filename":"ADV2_MW.json"},{"display":"Recognition - Spell","filename":"ADV2_REC_Spell.json"},{"display":"Recognition - Word","filename":"ADV2_REC_Word.json"}]}');

/***/ })

}]);