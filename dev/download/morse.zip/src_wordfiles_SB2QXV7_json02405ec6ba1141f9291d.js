"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV7_json"],{

/***/ "./src/wordfiles/SB2QXV7.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2QXV7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv59,","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);