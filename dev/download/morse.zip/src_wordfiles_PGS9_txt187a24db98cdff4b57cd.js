"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PGS9_txt"],{

/***/ "./src/wordfiles/PGS9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/PGS9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AGE RR ANT RPT GA SRI RPRT GE RST GN PSE SIG RAIN AGN RIG\n";

/***/ })

}]);