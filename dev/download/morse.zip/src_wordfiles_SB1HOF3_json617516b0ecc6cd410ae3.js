"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1HOF3_json"],{

/***/ "./src/wordfiles/SB1HOF3.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1HOF3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"hoflcdpgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);