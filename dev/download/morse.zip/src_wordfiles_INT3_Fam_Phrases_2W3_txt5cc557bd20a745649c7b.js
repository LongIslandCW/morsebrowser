"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_Fam_Phrases_2W3_txt"],{

/***/ "./src/wordfiles/INT3_Fam_Phrases_2W3.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/INT3_Fam_Phrases_2W3.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "THE BEST \r\nTHE BEST OF BOTH \r\nTHE BEST OF BOTH WORLDS \r\n{e|} \r\nHELLO, HOW \r\nHELLO, HOW ARE YOU \r\nHELLO, HOW ARE YOU THIS MORNING? \r\n{e|} \r\nTO ADD \r\nTO ADD INSULT TO \r\nTO ADD INSULT TO INJURY \r\n{e|} \r\nROLL OVER \r\nROLL OVER THAT BUMP \r\nROLL OVER THAT BUMP IN THE STREET \r\n{e|} \r\nWE DONT \r\nWE DONT SEE EYE \r\nWE DONT SEE EYE TO EYE \r\n";

/***/ })

}]);