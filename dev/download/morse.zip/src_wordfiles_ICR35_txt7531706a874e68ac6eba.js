"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR35_txt"],{

/***/ "./src/wordfiles/ICR35.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR35.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "IH5 \nIII \nIH5 \n5SI \nIES \nEES \n5SE \nEIS \nEE5 \nS55 \n5ES \nIHI \nISS \nIIE \nHIS \n5EE \nEEE \n55S \n5EI \n5SI \nB16 \nBBH \nBH1 \nHH6 \nHB1 \nB6B \nBBB \nHBH \n11H \n11H \nH61 \nH11 \nBBH \nB1B \n166\nB66 \n6HH \nH1B \n6HB \nHHH \nJBJ \nJBB \nJB1 \nW11 \n1WW \nJBB \nBBJ \nBW1 \nJ1J \nJWW \nJB1 \nB1W \nJ1W \nJBB \nWWW \nWBW \nJBW \nBJJ \nW1W \nJ11 \nU11 \nS61 \nS6U \nU16 \nUUI \nU66 \n666\n661\nIUU \nSSI \nI16 \nUI1 \n1SS \n6I1 \n1I6 \nI16 \n1I6 \nS1S \nSUS \n1SU \n44J \nBBV \nB4J \n4BV \nB4H \nHB4 \nVJB \n4BV \nVJ4 \nHVH \nHV4 \nVBH \nVBB \nJ4H \nBHH \nH4B \nBHH \nVB4 \nJHB \nHB4 \nUSU \nEST \nU6T \nUSS \nS6T \nUEE \nSSU \nESS \nU66 \nTT6 \nTST \n6TS \n6S6 \n6S6 \nE6T \nETS \nSTE \nTTU \nTUU \nVEB \nVBB \n4EE \nVV4 \nEEE \nVVE \n4BB \n4EB \nWVW \nEBW \nVBB \nV4E \nW4W \nBBE \nBB4 \n4V4 \nEBB \nVEV \nVVE \n4VE \n5H5 \nJJH \n5TI \nH5T \nHIT \nTHT \nJHH \n5TT \nJI5 \n5JT \n5IJ \nIIJ \nHIJ \nIIH \nIT5 \nJH5 \nH5J \nJTI \nT55 \nHHI \nHEU \nEUJ \nHHI \nEHI \nJIJ \nJEU \nHHJ \nIJU \nEJE \nHIU \nJEU \nUUE \nJHU \nHHU \nUIJ \nHUI \nHEH \nIHH \nHIJ \nIEH \nHWW \n6WH \nHDV \nVV6 \n66V \nVVH \n6HD \nHH6 \nHWV \nVD6 \nVVD \n6DW \nDVD \nBSB \nHHE \nEH5 \n5SS \nSSH \nS5H \nBBE \n55S \nESH \n5EH \nH5S \nHBH \nS5E \nBB5 \nBHE \nESE \n5SH \nBHE \nBSS \nEEE \n";

/***/ })

}]);