"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_05_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_05.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_05.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "African {consumer|} \r\n{|African consumer} \r\nconsult {eighth|} \r\n{|consult eighth} \r\nexpert {bucket|} \r\n{|expert bucket} \r\nneighbor {pregnancy|} \r\n{|neighbor pregnancy} \r\ncredit {tolerance|} \r\n{|credit tolerance} \r\nyourself {tunnel|} \r\n{|yourself tunnel} \r\nvegetable {likelihood|} \r\n{|vegetable likelihood} \r\nemission {official|} \r\n{|emission official} \r\nstring {homework|} \r\n{|string homework} \r\ndiscipline {creative|} \r\n{|discipline creative} ";

/***/ })

}]);