"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2407_txt"],{

/***/ "./src/wordfiles/IB2407.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2407.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL AR CA CO CT DE FL GA HI ID IL IN IA LA NE NH NC ND OH PA RI SC SD TN UT WA WI  \n";

/***/ })

}]);