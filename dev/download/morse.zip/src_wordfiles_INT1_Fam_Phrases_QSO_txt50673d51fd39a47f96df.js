"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/INT1_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/INT1_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "ANT \r\nANT IS \r\nANT IS A \r\n{e|} \r\nRIG \r\nRIG IS \r\nRIG IS THE \r\n{e|} \r\nTNX \r\nTNX FER \r\nTNX FER THE \r\n{e|} \r\nUR \r\nUR RST \r\nUR RST IS \r\n{e|} \r\nVY \r\nVY NICE \r\nVY NICE QSO \r\n{e|} \r\nWX \r\nWX IS \r\nWX IS VRY \r\n{e|} \r\nAGE \r\nAGE 58 \r\nAGE 58 YRS \r\n{e|} \r\nRETIRED \r\nRETIRED MATH \r\nRETIRED MATH TEACHER \r\n\r\n";

/***/ })

}]);