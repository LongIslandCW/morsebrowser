"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV5_txt"],{

/***/ "./src/wordfiles/SB2QXV5.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2QXV5.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "AL AR CA CO CT DE FL GA HI ID IL IN IA LA NE NV NH NC ND OH PA RI SC SD TN TX UT VT VA WA WV WI\n";

/***/ })

}]);