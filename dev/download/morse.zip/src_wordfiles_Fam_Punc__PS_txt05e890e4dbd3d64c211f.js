"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Punc__PS_txt"],{

/***/ "./src/wordfiles/Fam_Punc._PS.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/Fam_Punc._PS.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = ". \n{.|} \n{.|} \n{.|} \n. \n{|} \r\n, \r\n{,|} \r\n{,|} \r\n{,|} \r\n, \r\n{|} \r\n/ \n{/|} \n{/|} \n{/|} \n/ \n{|} \r\n? \n{?|} \n{?|} \n{?|} \n? \n{|} \r\n{B K|B K} \n{B K|} \n{B K|} \n{B K|} \n{B K|B K}  \n{|} \r\n{AR|AR} \n{AR|} \n{AR|} \n{AR|} \n{AR|AR} \n{|} \r\nBT \n{BT|} \n{BT|} \n{BT|} \nBT \n{|} \r\nSK \n{SK|} \n{SK|} \n{SK|} \nSK \n{|} \r\n. \n{.|} \n{.|} \n{.|} \n. \n{|} \n, \n{,|} \n{,|} \n{,|} \n, \n{|} \n/ \n{/|} \n{/|} \n{/|} \n/ \n{|} \n? \n{?|} \n{?|} \n{?|} \n? \n{|} \n{B K|B K} \n{B K|} \n{B K|} \n{B K|} \n{B K|B K}  \n{|} \n{AR|AR} \n{AR|} \n{AR|} \n{AR|} \n{AR|AR} \n{|} \nBT \n{BT|} \n{BT|} \n{BT|} \nBT \n{|} \nSK \n{SK|} \n{SK|} \n{SK|} \nSK \n{|} \n";

/***/ })

}]);