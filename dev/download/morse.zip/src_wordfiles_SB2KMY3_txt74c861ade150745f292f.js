"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY3_txt"],{

/***/ "./src/wordfiles/SB2KMY3.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2KMY3.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "ABT AGE AGN AM ANT BEEN BK BUG C CFM CLEAR CPI CPY CU CUAGN CUL CW DE DIPOLE DN DR EL ES FB FER FM FT GA GE GM GN GND GUD HAM HI HPE HR HW INFO K OK OM OP OT PSE PWR R RAIN RETIRED RFI RIG RPRT RPT RR RST RX SIG SKED SOLID SRI SSB SUN T TEMP TKS TU TX U UP UR W WID WIND WPM WUD YAGI YRS";

/***/ })

}]);