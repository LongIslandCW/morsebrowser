"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per6_txt"],{

/***/ "./src/wordfiles/per6.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per6.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "QSL ON ALL NAME HR IS SALLY RIG HR COLLINS 75S 3 <AR> K\n";

/***/ })

}]);