"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_08_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_08.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_08.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "wrap {use|} \r\n{|wrap use} \r\nwash {cheer|} \r\n{|wash cheer} \r\ndate {atop|} \r\n{|date atop} \r\nfour {brief|} \r\n{|four brief} \r\nfinal {say|} \r\n{|final say} \r\nbeing {cure|} \r\n{|being cure} \r\ntheme {ours|} \r\n{|theme ours} \r\nlower {game|} \r\n{|lower game} \r\nshut {key|} \r\n{|shut key} \r\nlast {lend|} \r\n{|last lend} ";

/***/ })

}]);