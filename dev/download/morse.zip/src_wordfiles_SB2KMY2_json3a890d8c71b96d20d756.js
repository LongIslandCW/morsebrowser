"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY2_json"],{

/***/ "./src/wordfiles/SB2KMY2.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2KMY2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);