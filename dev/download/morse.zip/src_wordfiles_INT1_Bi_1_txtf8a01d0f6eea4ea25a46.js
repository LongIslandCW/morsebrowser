"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_1_txt"],{

/***/ "./src/wordfiles/INT1_Bi_1.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_1.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "NICE AND EASY \r\nDAY AND NIGHT \r\nFIRST AND LAST \r\nKEY OR PADDLE \r\nACHES AND PAINS \r\nIDLE OR BUSY \r\nFAR AND AWAY \r\nGRIP IT AND RIP IT \r\nOPEN AND SHUT \r\nFAR AND WIDE \r\n\r\n";

/***/ })

}]);