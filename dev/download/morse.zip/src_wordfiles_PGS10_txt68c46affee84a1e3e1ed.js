"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PGS10_txt"],{

/***/ "./src/wordfiles/PGS10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/PGS10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "PIE RAG SIP PIN TAP PEA GAP PEG PIG GRIP NAP PAN PING GASP PAGE GRASP SPIN PAIN\n";

/***/ })

}]);