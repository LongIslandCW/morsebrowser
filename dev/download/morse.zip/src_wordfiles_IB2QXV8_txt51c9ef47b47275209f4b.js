"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV8_txt"],{

/***/ "./src/wordfiles/IB2QXV8.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2QXV8.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "AL AR CA CO CT DE FL GA HI ID IL IN IA LA NE NV NH NC ND OH PA RI SC SD TN TX UT VT VA WA WV WI\n";

/***/ })

}]);