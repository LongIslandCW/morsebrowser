"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_01_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_01.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_01.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "exchange {stimulate|} \r\n{|exchange stimulate} \r\nexecution {determine|} \r\n{|execution determine} \r\npurchase {independent|} \r\n{|purchase independent} \r\nprogramming {terribly|} \r\n{|programming terribly} \r\npersonnel {accomplish|} \r\n{|personnel accomplish} \r\ncalendar {presidential|} \r\n{|calendar presidential} \r\nunlikely {recession|} \r\n{|unlikely recession} \r\nprotection {efficiency|} \r\n{|protection efficiency} \r\nbirthday {pollution|} \r\n{|birthday pollution} \r\npositive {journalism|} \r\n{|positive journalism} ";

/***/ })

}]);