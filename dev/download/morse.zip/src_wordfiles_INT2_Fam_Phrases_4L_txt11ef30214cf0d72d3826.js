"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_Fam_Phrases_4L_txt"],{

/***/ "./src/wordfiles/INT2_Fam_Phrases_4L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT2_Fam_Phrases_4L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "TO \r\nTO ADD \r\nTO ADD INSULT \r\nTO ADD INSULT TO \r\n{<BT>|}\r\nITS \r\nITS BEEN \r\nITS BEEN A \r\nITS BEEN A HEAT \r\n{<BT>|}\r\nTO \r\nTO HIT \r\nTO HIT THE \r\nTO HIT THE NAIL \r\n{<BT>|}\r\nCAN \r\nCAN YOU \r\nCAN YOU SAIL \r\nCAN YOU SAIL ON \r\n{<BT>|}\r\nA \r\nA COIN \r\nA COIN TOSS \r\nA COIN TOSS CAN \r\n{<BT>|}\r\nYOU \r\nYOU CANT \r\nYOU CANT JUDGE \r\nYOU CANT JUDGE A \r\n\r\n\r\n";

/***/ })

}]);