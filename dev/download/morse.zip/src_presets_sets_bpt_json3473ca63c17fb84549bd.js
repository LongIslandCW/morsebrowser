"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_bpt_json"],{

/***/ "./src/presets/sets/bpt.json":
/*!***********************************!*\
  !*** ./src/presets/sets/bpt.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"BPT_Default_12.json"},{"display":"Default 15/12","filename":"BPT_Default_15.json"},{"display":"Random Groups 1-5","filename":"BPT_Random_1-5.json"},{"display":"VST","filename":"BPT_VST.json"},{"display":"Groups of 5","filename":"BPT_Groups_5.json"},{"display":"Inter-character Head Copy","filename":"BPT_ICHC.json"},{"display":"ICR","filename":"BPT_ICR.json"},{"display":"VET","filename":"BPT_VET.json"},{"display":"Instant Word Recognition","filename":"BPT_IWR.json"},{"display":"Progressive Word Building","filename":"BPT_PWG.json"},{"display":"Voice On & Spell On","filename":"BPT_Von_Son.json"},{"display":"Voice On & Spell Off","filename":"BPT_Von_Soff.json"}]}');

/***/ })

}]);