"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY9_json"],{

/***/ "./src/wordfiles/IB2KMY9.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2KMY9.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"kmyrea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);