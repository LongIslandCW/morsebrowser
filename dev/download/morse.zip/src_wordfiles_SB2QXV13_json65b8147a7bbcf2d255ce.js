"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV13_json"],{

/***/ "./src/wordfiles/SB2QXV13.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB2QXV13.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv59,kmy4028bkzj/16.<ar><sk><bt>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);