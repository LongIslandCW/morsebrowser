"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_2_Words_txt"],{

/***/ "./src/wordfiles/INT3_2 Words.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/INT3_2 Words.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "courage  arrest\r\ntrauma  receiver\r\nwrong  suburban\r\nsound  platform\r\nhandful  plant\r\ndemocracy  reference\r\nshark  pickup\r\ndrawer  vision\r\nsharply  collapse\r\nconscious  ribbon\r\nexistence  banana\r\nconsumer  culture\r\noffer  credit\r\ncrucial  prayer\r\nkneel  theme\r\nholiday  offering\r\ninstinct  railroad\r\nblack  claim\r\naffect  jewelry\r\nthread  afternoon\r\nmotivate  anyone\r\nvegetable  builder\r\nfeature  crack\r\nreverse  professor\r\ndivide  troubled\r\nevent  spoke\r\ncampus  trace\r\nhurricane  organized\r\nlaunch  where\r\nliver  close\r\ndetailed  charge\r\nalready  Islam\r\nactual  awareness\r\nSenate  pension\r\nscary  circuit\r\ncorrectly  motion\r\nterror  stranger\r\nsandwich  living\r\ntrick  freedom\r\nFrench  safely\r\nregard  stand\r\npatient  critic\r\ntoilet  press\r\nwidely  behavior\r\nemission  shape\r\nfight  liquid\r\nimage  thick\r\ndiagnosis  validity\r\nshock  superior\r\nbread  status\r\ncontext  quietly\r\nupset  encourage\r\nfirmly  thought\r\nexercise  casino\r\nvisible  lemon\r\nvacation  engine\r\nrocket  sphere\r\nstarter  momentum\r\nreliable  private\r\ndoorway  pretty\r\ndrunk  suffering\r\nsurely  powder\r\nseason  minority\r\nwhile  therapist\r\nhabitat  theology\r\novernight  their\r\nhonor  answer\r\nnightmare  recruit\r\nepidemic  exhibit\r\nencounter  faster\r\npromote  descend\r\nfield  charter\r\ndevote  patience\r\nfaculty  authorize\r\nexact  portrait\r\ndiagnose  through\r\nconvinced  decrease\r\ndoctor  total\r\ntrailer  curtain\r\nnormal  Democrat\r\nthreshold  uncle\r\nfound  survey\r\ncolor  subtle\r\nenormous  grateful\r\nswitch  standard\r\nresource  breathe\r\naccuse  request\r\nelderly  beyond\r\ntissue  wound\r\nsweater  weird\r\nmedium  label\r\nevery  probably\r\nevidence  conceive\r\nstanding  later\r\nancient  unless\r\nanywhere  music\r\nobvious  meanwhile\r\nplacement  divorce\r\nsurvive  donor\r\npromotion  matter \r\n\r\n\r\n";

/***/ })

}]);