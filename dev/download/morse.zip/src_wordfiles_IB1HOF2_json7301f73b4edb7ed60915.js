"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1HOF2_json"],{

/***/ "./src/wordfiles/IB1HOF2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1HOF2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"o","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);