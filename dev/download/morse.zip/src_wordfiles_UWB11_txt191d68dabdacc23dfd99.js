"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_UWB11_txt"],{

/***/ "./src/wordfiles/UWB11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/UWB11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "CUL BOB  \nWUD FLOW  \nCUD U  \nHW LOW  \nLOUD CW  \nCU DOC  \nCUD FOLD  \nFB BUD  \nWL HOWL\nWOLF HOWL  \nOLD BOWL  \nWHO WOULD  \nBOLD BOW\nDOC COULD  \nCOLD COD  \nFOUL BOWL  \nLOW CLOUD\n";

/***/ })

}]);