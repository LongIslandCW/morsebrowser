"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_1B_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_1B.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_1B.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "WY6IFI DE K3ZFT \r\nGA ES TNX FER CALL \r\nUR RST 599 5NN \r\nQTH TOPEKA, KS TOPEKA, KS \r\nNAME JACK JACK \r\nOK HW? AR WY6IFI DE K3ZFT K \r\nK3ZFT DE WY6IFI \r\nGA ES TNX FER RPRT \r\nUR RST 559 55N \r\nQTH ST LOUIS, MI ST LOUIS, MI \r\nNAME HALEY HALEY \r\nOK HW? AR K3ZFT DE WY6IFI K ";

/***/ })

}]);