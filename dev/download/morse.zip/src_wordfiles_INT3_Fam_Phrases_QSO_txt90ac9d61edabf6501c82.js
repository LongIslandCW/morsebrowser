"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/INT3_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/INT3_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "WX IS \r\nWX IS VRY NICE \r\nWX IS VRY NICE ES SUNNY \r\n{e|} \r\nVY NICE\r\nVY NICE QSO ON \r\nVY NICE QSO ON 17M BOB \r\n{e|} \r\nUR RST \r\nUR RST 599 5NN \r\nUR RST 599 5NN INTO DALLAS \r\n{e|} \r\nTNX FER \r\nTNX FER THE FB \r\nTNX FER THE FB QSO OM \r\n{e|} \r\nAGE 58 \r\nAGE 58 YRS BEEN \r\nAGE 58 YRS BEEN HAM FER  \r\n{e|} \r\nES HP \r\nES HP CUAGN 73 \r\nES HP CUAGN 73 <AR> N1CC \r\n\r\n\r\n";

/***/ })

}]);