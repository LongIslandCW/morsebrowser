"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2163_json"],{

/***/ "./src/wordfiles/IB2163.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2163.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"16","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);