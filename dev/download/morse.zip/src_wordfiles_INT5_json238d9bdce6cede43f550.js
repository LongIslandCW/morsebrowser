"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT5_json"],{

/***/ "./src/wordfiles/INT5.json":
/*!*********************************!*\
  !*** ./src/wordfiles/INT5.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);