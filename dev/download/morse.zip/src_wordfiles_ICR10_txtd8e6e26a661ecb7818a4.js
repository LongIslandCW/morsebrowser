"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR10_txt"],{

/***/ "./src/wordfiles/ICR10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);