"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Bug_Pro_json"],{

/***/ "./src/wordfiles/Bug_Pro.json":
/*!************************************!*\
  !*** ./src/wordfiles/Bug_Pro.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<AR><SK><BT>BK","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);