"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_28BK_txt"],{

/***/ "./src/wordfiles/BC2_FAM_28BK.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/BC2_FAM_28BK.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "2 \r\n8 \r\nBK \r\n8 \r\nBK \r\n2 \r\nBK \r\n2 \r\n8 \r\n2 \r\n8 \r\nBK \r\n";

/***/ })

}]);