"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_5_txt"],{

/***/ "./src/wordfiles/INT1_Bi_5.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_5.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "DOS AND DONTS \r\nPUSH AND PULL \r\nJOIN OR LEAVE \r\nNULL AND VOID \r\nBRIGHT AND EARLY \r\nSAFE AND SOUND \r\nBACK AND FORTH \r\nTWISTS AND TURNS \r\nCOME AND GO \r\nEAT AND DRINK \r\n";

/***/ })

}]);