"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1LCD3_json"],{

/***/ "./src/wordfiles/IB1LCD3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1LCD3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"lc","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);