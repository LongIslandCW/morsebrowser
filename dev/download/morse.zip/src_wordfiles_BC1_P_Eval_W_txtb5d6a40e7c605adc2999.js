"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_P_Eval_W_txt"],{

/***/ "./src/wordfiles/BC1_P_Eval_W.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/BC1_P_Eval_W.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "NICE RUB FOR BREW FOUR RUBE WEAR  DIGS TIN  HOPING  FOLD \r\n\r\nBOAR HEAR HOPING WHAT WHIP SHIFT CLING SPLIT GOLD  TUNE \r\n\r\nRIG PAINT FOUR AGE  HANGS CLEAR TAP GRASP BEEN TRAIN WIND \r\n\r\nEAT WET AIR TUNE SHOP DOCS GOLD BAIT RENT WHO FOUL \r\n\r\nFOLD BRAGS RAIN SUN NICE BUG WIND TEN SLIP WET WHO \r\n\r\nWIND SOLID DIPOLE RAIN BEEN FOR RING WATER CLUB  WHO \r\n\r\nSLIP SOLD FOG CLUB BOLD COULD WENT BURN BAIT SHOP \r\n\r\nFOG RAIN NICE FOUR RUBE BOAR HEAR WENT SLIP GOLD \r\n\r\nHOPING WHAT RAIN BEEN SNAP FOUL PEAS SUN NICE WIND \r\n\r\nPAINTS TIN WIRE CLEAR GROUP RUB HERO DIPOLE SUN  SHIFT ";

/***/ })

}]);