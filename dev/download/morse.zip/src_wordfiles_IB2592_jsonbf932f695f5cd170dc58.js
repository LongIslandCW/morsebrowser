"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2592_json"],{

/***/ "./src/wordfiles/IB2592.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2592.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"9","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);