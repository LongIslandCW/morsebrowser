"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1TIN1_json"],{

/***/ "./src/wordfiles/SB1TIN1.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1TIN1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"tin","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);