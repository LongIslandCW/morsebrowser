"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PGS8_txt"],{

/***/ "./src/wordfiles/PGS8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/PGS8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AR \nGA \n{IN|indiana} \nIA \nNE \nPA \nRI \nTN \nNT \nNS \nPE \n";

/***/ })

}]);