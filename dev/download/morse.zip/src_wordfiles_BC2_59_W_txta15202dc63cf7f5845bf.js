"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_59_W_txt"],{

/***/ "./src/wordfiles/BC2_59_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_59_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "RUN \r\nAGO \r\nOUR \r\nOLD \r\nWIN \r\nEAT \r\nBIT \r\nSEE \r\nELSE \r\nCOST \r\nPULL \r\nROLL \r\nSPOT \r\nEDGE \r\nLIFE \r\nTEST \r\nTREE \r\nPAIR \r\nHERE \r\nFACT \r\nSUCH \r\nFOUR \r\nHELP \r\nRAIN \r\nREAD \r\nGLAD \r\nCELL \r\nTHUS \r\nREAL \r\nSING \r\nRISE \r\nWILL \r\nDEEP \r\nFIRST \r\nRAISE \r\nBEGIN \r\nSTAND \r\nWOULD \r\nPRESS \r\nWHILE \r\nSHOUT \r\nGRASS \r\nCLOSE \r\nOCEAN \r\nSOUND \r\nWHICH \r\nSPEND \r\nRADIO \r\nBASIC \r\nCHART \r\n\r\n";

/***/ })

}]);