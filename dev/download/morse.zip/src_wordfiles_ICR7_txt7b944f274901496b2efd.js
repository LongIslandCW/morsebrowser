"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR7_txt"],{

/***/ "./src/wordfiles/ICR7.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR7.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);