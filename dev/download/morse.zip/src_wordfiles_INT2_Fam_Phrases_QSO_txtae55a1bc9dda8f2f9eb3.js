"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/INT2_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/INT2_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "UR \r\nUR RST \r\nUR RST 599 \r\nUR RST 599 5NN \r\n{<BT>|}\r\nRIG \r\nRIG {IC7300|I C 7 3 HUNDRED} \r\nRIG {IC7300|I C 7 3 HUNDRED} ES \r\nRIG {IC7300|I C 7 3 HUNDRED} ES PWR \r\n{<BT>|}\r\nNAME \r\nNAME HERE \r\nNAME HERE RICH \r\nNAME HERE RICH RICH \r\n{<BT>|}\r\nWX \r\nWX IS \r\nWX IS VRY \r\nWX IS VRY NICE \r\n{<BT>|}\r\nVY \r\nVY NICE \r\nVY NICE QSO \r\nVY NICE QSO ON ";

/***/ })

}]);