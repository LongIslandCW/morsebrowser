"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2732_txt"],{

/***/ "./src/wordfiles/IB2732.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2732.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "73 ABT AGE AGN ANT BEEN BUG C CALL CLEAR CPI CU CUAGN CUL CW DE DIPOLE DN DR EL ES FB FER FT GA GE GN GND GUD HI HPE HR HW HW? INFO OP OT PSE PWR R RAIN RETIRED RFI RIG RPRT RPT RR RST SIG SOLID SRI SSB SUN T TU U UP UR W WID WIND WPM WUD";

/***/ })

}]);