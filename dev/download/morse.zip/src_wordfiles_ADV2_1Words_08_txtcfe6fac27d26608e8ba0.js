"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_08_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_08.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_08.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "realistic {alongside|} \r\n{|realistic alongside} \r\nsurvival {dependent|} \r\n{|survival dependent} \r\nliterature {engineering|} \r\n{|literature engineering} \r\nflexibility {conception|} \r\n{|flexibility conception} \r\nsensitive {subtract|} \r\n{|sensitive subtract} \r\nconvention {computer|} \r\n{|convention computer} \r\nenvironment {carefully|} \r\n{|environment carefully} \r\nprosecutor {particularly|} \r\n{|prosecutor particularly} \r\nfrequency {surround|} \r\n{|frequency surround} \r\ndiagnose {productive|} \r\n{|diagnose productive} ";

/***/ })

}]);