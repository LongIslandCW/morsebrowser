"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ZJ8_json"],{

/***/ "./src/wordfiles/SB2ZJ8.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2ZJ8.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbzj/16.<ar><sk><bt>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);