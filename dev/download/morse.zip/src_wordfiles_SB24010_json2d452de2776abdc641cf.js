"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB24010_json"],{

/***/ "./src/wordfiles/SB24010.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB24010.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb4028bkzj/16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);