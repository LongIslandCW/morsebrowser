"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1TIN6_json"],{

/***/ "./src/wordfiles/IB1TIN6.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1TIN6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reauwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);