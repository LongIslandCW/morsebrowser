"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ARSKBT4_json"],{

/***/ "./src/wordfiles/IB2ARSKBT4.json":
/*!***************************************!*\
  !*** ./src/wordfiles/IB2ARSKBT4.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<BT>","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);