"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C4_txt"],{

/***/ "./src/wordfiles/SB2C4.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C4.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{W2LCW|w 2 l c w} {DE|from} {WB2UZE|w b 2 u z e} {FB|fine business} {CPY|copy} RICH {ES|and} {TNX|thanks} {FER|for} NICE {RPRT|report} \nRIG {IC7300|i c 7 3 0 0 } {ES|and} {PWR|power} 100 {W|watts} \n{ANT|antenna} DIPOLE UP 35 {FT|feet} \t\n{WX|weather}  RAIN {ES|and} TEMP 40 {F|fahrenheit}\nOK {HW?|how copy} {<AR>|end of message} {W2LCW|w 2 l c w} {DE|from} {WB2UZE|w b 2 u z e} {K|invitation to transmit} \n";

/***/ })

}]);