"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_16_W_txt"],{

/***/ "./src/wordfiles/BC2_16_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_16_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "AIR \r\nBED \r\nNOT \r\nFOR \r\nTHE \r\nARE \r\nRED \r\nICE \r\nAGE \r\nOUR \r\nEAT \r\nSON \r\nBIT \r\nOFF \r\nAGO \r\nCAT \r\nSHE \r\nFIG \r\nCELL  \r\nPORT \r\nHALF \r\nSONG \r\nCOST \r\nHOPE \r\nCALL \r\nBONE \r\nWISH \r\nTREE \r\nFEAR \r\nSTEP \r\nFINE \r\nIDEA \r\nLAST \r\nGLAD \r\nBALL \r\nIRON \r\nTHIS \r\nPOOR \r\nFIELD  \r\nPOUND \r\nCLEAN \r\nREACH \r\nCHIEF \r\nSTOOD \r\nORGAN \r\nGREAT \r\nPAINT \r\nNIGHT \r\nTRAIN \r\nSTATE \r\n\r\n";

/***/ })

}]);