"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_bc2_json"],{

/***/ "./src/presets/sets/bc2.json":
/*!***********************************!*\
  !*** ./src/presets/sets/bc2.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/10","filename":"BC2_Default.json"},{"display":"Random groups 1-3","filename":"BC2_Random_groups_1_3.json"},{"display":"VST","filename":"BC2_VST.json"},{"display":"Reverse VST","filename":"BC2_RVST.json"},{"display":"Groups of 5","filename":"BC2_Groups_of_5.json"},{"display":"Random groups 1-4","filename":"BC2_Random_groups_1_4.json"},{"display":"ICR","filename":"BC2_ICR.json"},{"display":"VET","filename":"BC2_VET.json"},{"display":"Reverse VET","filename":"BC2_RVET.json"},{"display":"Prosign Phrases","filename":"BC2_Prosign_Phrases.json"},{"display":"Instant Word Recognition","filename":"BC2_IWR.json"},{"display":"Sending Practice","filename":"BC2_Sending.json"},{"display":"Voice On & Spell On","filename":"BC2_Von_Son.json"},{"display":"Voice On & Spell Off","filename":"BC2_Von_Soff.json"}]}');

/***/ })

}]);