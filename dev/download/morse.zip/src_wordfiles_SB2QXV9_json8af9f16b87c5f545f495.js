"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV9_json"],{

/***/ "./src/wordfiles/SB2QXV9.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2QXV9.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv59,kmy40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);