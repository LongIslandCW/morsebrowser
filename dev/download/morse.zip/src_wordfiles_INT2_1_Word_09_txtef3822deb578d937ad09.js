"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_09_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_09.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_09.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "think {remark|} \r\n  {|think remark} \r\nsure {dead|} \r\n  {|sure dead} \r\nsame {succeed|} \r\n  {|same succeed} \r\ndoor {agenda|} \r\n  {|door agenda} \r\nteam {twelve|} \r\n  {|team twelve} \r\nadmit {measure|} \r\n  {|admit measure} \r\ntend {exist|} \r\n  {|tend exist} \r\nshould {nose|} \r\n  {|should nose} \r\nsimple {away|} \r\n  {|simple away} \r\nstuff {acid|} \r\n  {|stuff acid} ";

/***/ })

}]);