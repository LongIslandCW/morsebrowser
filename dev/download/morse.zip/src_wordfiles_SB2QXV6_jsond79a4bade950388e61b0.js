"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV6_json"],{

/***/ "./src/wordfiles/SB2QXV6.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2QXV6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);