"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per8_txt"],{

/***/ "./src/wordfiles/per8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "TNX FER NICE QSO CU AGN BEST 73 DE WA2AKV\n";

/***/ })

}]);