"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1Words_01_txt"],{

/***/ "./src/wordfiles/INT3_1Words_01.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT3_1Words_01.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "medium {ribbon|} \r\n{|medium ribbon} \r\nevery {collapse|} \r\n{|every collapse} \r\nevidence {vision|} \r\n{|evidence vision} \r\nstanding {pickup|} \r\n{|standing pickup} \r\nancient {reference|} \r\n{|ancient reference} \r\nanywhere {plant|} \r\n{|anywhere plant} \r\nobvious {platform|} \r\n{|obvious platform} \r\nplacement {suburban|} \r\n{|placement suburban} \r\nsurvive {receiver|} \r\n{|survive receiver} \r\npromotion {arrest|} \r\n{|promotion arrest} ";

/***/ })

}]);