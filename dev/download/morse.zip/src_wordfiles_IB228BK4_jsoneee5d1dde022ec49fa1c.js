"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK4_json"],{

/***/ "./src/wordfiles/IB228BK4.json":
/*!*************************************!*\
  !*** ./src/wordfiles/IB228BK4.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"BK","minWordSize":1,"maxWordSize":1,"ifstickySets":true,"practiceSeconds":60}');

/***/ })

}]);