"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS3_json"],{

/***/ "./src/wordfiles/IB1PGS3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PGS3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ps","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);