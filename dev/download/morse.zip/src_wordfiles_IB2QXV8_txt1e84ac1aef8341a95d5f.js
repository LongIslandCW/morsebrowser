"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV8_txt"],{

/***/ "./src/wordfiles/IB2QXV8.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2QXV8.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "AL \nAR\nCA\nCO\nCT\n{DE|delaware}\nFL\n{GA|georgia} \n{HI|hawaii} \n{ID|idaho}\nIL\n{IN|indiana}\nIA\n{LA|louisiana}\nNE\nNV\nNH\nNC\nND\n{OH|ohio} \nPA\nRI\nSC\nSD\nTN\nTX\nUT\nVT\nVA\nWA\nWV\nWI\n";

/***/ })

}]);