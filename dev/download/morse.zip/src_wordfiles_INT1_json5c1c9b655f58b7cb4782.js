"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_json"],{

/***/ "./src/wordfiles/INT1.json":
/*!*********************************!*\
  !*** ./src/wordfiles/INT1.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);