"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Letters_txt"],{

/***/ "./src/wordfiles/POL_Letters.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/POL_Letters.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "AAA \r\nBBB \r\nCCC \r\nDDD \r\nEEE \r\nFFF \r\nGGG \r\nHHH \r\nIII \r\nJJJ \r\nKKK \r\nLLL \r\nMMM \r\nNNN \r\nOOO \r\nPPP \r\nQQQ \r\nRRR \r\nSSS \r\nTTT \r\nUUU \r\nVVV \r\nWWW \r\nXXX \r\nYYY \r\nZZZ ";

/***/ })

}]);