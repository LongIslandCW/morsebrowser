"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1TIN3_json"],{

/***/ "./src/wordfiles/SB1TIN3.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1TIN3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"tinreauwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);