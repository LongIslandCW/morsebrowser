"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_3_txt"],{

/***/ "./src/wordfiles/Fam_Words - 3.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 3.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "way  \n{way |} \n{way |} \n{way |} \nway  \n{|} \r\nthere  \n{there |} \n{there |} \n{there |} \nthere  \n{|} \r\nfrom  \n{from |} \n{from |} \n{from |} \nfrom  \n{|} \r\nour  \n{our |} \n{our |} \n{our |} \nour  \n{|} \r\nmy  \n{my |} \n{my |} \n{my |} \nmy  \n{|} \r\nsee  \n{see |} \n{see |} \n{see |} \nsee  \n{|} \r\nany  \n{any |} \n{any |} \n{any |} \nany  \n{|} \r\nbe  \n{be |} \n{be |} \n{be |} \nbe  \n{|} \r\nget  \n{get |} \n{get |} \n{get |} \nget  \n{|} \r\nas  \n{as |} \n{as |} \n{as |} \nas  \n{|} \r\nit  \n{it |} \n{it |} \n{it |} \nit  \n{|} \r\nonly  \n{only |} \n{only |} \n{only |} \nonly  \n{|} \r\nfirst  \n{first |} \n{first |} \n{first |} \nfirst  \n{|} \r\nif  \n{if |} \n{if |} \n{if |} \nif  \n{|} \r\nat  \n{at |} \n{at |} \n{at |} \nat  \n{|} \r\na  \n{a |} \n{a |} \n{a |} \na  \n{|} \r\nthe  \n{the |} \n{the |} \n{the |} \nthe  \n{|} \r\nyou  \n{you |} \n{you |} \n{you |} \nyou  \n{|} \r\nout  \n{out |} \n{out |} \n{out |} \nout  \n{|} \r\nwill  \n{will |} \n{will |} \n{will |} \nwill  \n{|} \r\nwith  \n{with |} \n{with |} \n{with |} \nwith  \n{|} \r\nher  \n{her |} \n{her |} \n{her |} \nher  \n{|} \r\nwe  \n{we |} \n{we |} \n{we |} \nwe  \n{|} \r\nthink  \n{think |} \n{think |} \n{think |} \nthink  \n{|} \r\ntime  \n{time |} \n{time |} \n{time |} \ntime  \n{|} \r\n";

/***/ })

}]);