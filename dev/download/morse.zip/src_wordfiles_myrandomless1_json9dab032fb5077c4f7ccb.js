"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_myrandomless1_json"],{

/***/ "./src/wordfiles/myrandomless1.json":
/*!******************************************!*\
  !*** ./src/wordfiles/myrandomless1.json ***!
  \******************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abc","minWordSize":"3","maxWordSize":"3","words":20}');

/***/ })

}]);