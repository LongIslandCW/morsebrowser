"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_2-3W_Pt3_txt"],{

/***/ "./src/wordfiles/POL_2-3W_Pt3.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_2-3W_Pt3.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \nAND \nALL \nANY \nBBB \nBED \nBIT \nBOY \nCCC \nCOW \nCUT \nCQ \nDDD \nDAY \nDE \nDOT \nDWN \nEEE \nEGG \nELM \nEND \nFFF \nFOG \nFRY \nFOX \nGGG \nGUM \nGUY \nGYM \nHHH \nHAM \nHUG \nHOW \nIII \nITS \nICK \nICY \nJJJ \nJIG \nJUG \nKKK \nKEY \nKEG \nKIT \nLLL \nLAP \nLET \nLUG \nMMM \nMEN \nMIC \nMOP \nNNN \nNOT \nNUT \nNIL \nOOO \nOIL \nOLD \nOAK \nPPP \nPOP \nPUG \nPRO \nQQQ \nQSY \nQRS \nQSO \nRRR \nRIM \nROB \nRUG \nSSS \nSHE \nSET \nSAY \nTTT \nTHE \nTAR \nTEA \nTUG \nUUU \nUP \nUFO \nUMP \nVVV \nVET \nVEX \nVAN \nWWW \nWET \nWAG \nWAR \nXXX \nXYL \nYYY \nYET \nYUP \nYEP \nZZZ \nZAG \nZOO \nZAP \r\n";

/***/ })

}]);