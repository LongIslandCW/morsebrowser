"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR5_txt"],{

/***/ "./src/wordfiles/ICR5.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR5.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);