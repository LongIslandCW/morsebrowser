"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK4_txt"],{

/***/ "./src/wordfiles/SB228BK4.txt":
/*!************************************!*\
  !*** ./src/wordfiles/SB228BK4.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "OK HOWARD BTU BK BK FB RICH AGE 28 RETIRED HI HI BK BK FB ES TU FER INFO UR RIG ES ANT DOING FB WID GUD SIG HR BK BK ANT EFHW IN ATTIC BK";

/***/ })

}]);