"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2165_json"],{

/***/ "./src/wordfiles/IB2165.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2165.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);