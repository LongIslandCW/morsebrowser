"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_json"],{

/***/ "./src/wordfiles/ADV1.json":
/*!*********************************!*\
  !*** ./src/wordfiles/ADV1.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ABCD1234/,.<SK><AR>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);