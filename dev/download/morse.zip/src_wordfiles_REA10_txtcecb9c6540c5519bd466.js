"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_REA10_txt"],{

/***/ "./src/wordfiles/REA10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/REA10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "RUB BAR RAW FOR WAR ARE BREW FOUR RUBE WEAR BOAR HEAR BARE HOUR WAFER BEAR HERO WORE HARE FEAR BEER ROBE WHARF EURO\n";

/***/ })

}]);