"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1PGS3_json"],{

/***/ "./src/wordfiles/SB1PGS3.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1PGS3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"pgstinrea","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);