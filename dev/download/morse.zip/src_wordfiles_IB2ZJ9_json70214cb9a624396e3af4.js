"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ9_json"],{

/***/ "./src/wordfiles/IB2ZJ9.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2ZJ9.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"zj/eio","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);