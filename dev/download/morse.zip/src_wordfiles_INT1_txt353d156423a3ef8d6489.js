"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_txt"],{

/***/ "./src/wordfiles/INT1.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT1.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "a\nb\nc\nd\ne\nf\ng\nh\ni\nj\nk\nl\nm\nn\no\np\nq\nr\ns\nt\nu\nv\nw\nx\ny\nz\n";

/***/ })

}]);