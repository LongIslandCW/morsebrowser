"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV1_json"],{

/***/ "./src/presets/sets/ADV1.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 25/25","filename":"ADV1BUF.json"},{"display":"Affixes","filename":"ADV1_AFIX.json"},{"display":"Call Signs","filename":"ADV1_CS.json"},{"display":"Familiarity Phrases","filename":"ADV1_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"ADV1_FAM_Sentences.json"},{"display":"Familiarity Spell","filename":"ADV1_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV1_FAM_WORDS.json"},{"display":"Multi Words","filename":"ADV1_MW.json"},{"display":"Recognition - Spell","filename":"ADV1_REC_Spell.json"},{"display":"Recognition - Words","filename":"ADV1_Rec_Words.json"},{"display":"Speed Racing - Spell","filename":"SR_25_SPELL.json"},{"display":"Speed Racing - Words","filename":"SR_25_WORDS.json"},{"display":"Stories - 25","filename":"ADV_Stories_25.json"},{"display":"Stories - 30","filename":"ADV_Stories_30.json"},{"display":"TTR","filename":"ADVICR.json"}]}');

/***/ })

}]);