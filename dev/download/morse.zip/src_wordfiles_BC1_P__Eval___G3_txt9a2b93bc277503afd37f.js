"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_P__Eval___G3_txt"],{

/***/ "./src/wordfiles/BC1_P_ Eval _ G3.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC1_P_ Eval _ G3.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "EAB \r\nWPA \r\nGHS \r\nSRO \r\n{ORO|O R O} \r\nRSO \r\nCWN \r\n{GOF|G O F} \r\nFNR \r\n{HBI|H B I} \r\nTLD \r\n{IUH|I U H}";

/***/ })

}]);