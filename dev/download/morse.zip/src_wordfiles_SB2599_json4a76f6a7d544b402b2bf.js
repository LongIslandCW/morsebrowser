"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2599_json"],{

/***/ "./src/wordfiles/SB2599.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2599.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,kmy40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);