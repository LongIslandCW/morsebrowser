"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR3_txt"],{

/***/ "./src/wordfiles/ICR3.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR3.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A\nI\nAT\nIT\nNO\nTO\nAS\nSO\nOR\nAN\nON\nIN\nIS\n";

/***/ })

}]);