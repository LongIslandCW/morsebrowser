"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2406_txt"],{

/***/ "./src/wordfiles/IB2406.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2406.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "ADØWE AI4PL G4FON GØPOT WBØISG N4DTR WB4UTB WBØHOA AAØTIN AC4LCD ABØCD N4FOH NØCDL  \n";

/***/ })

}]);