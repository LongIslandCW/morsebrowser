"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2167_txt"],{

/***/ "./src/wordfiles/IB2167.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2167.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC GA BOB OP ALAN ANT DIPOLE UP 61 FT, PWR 1W HI HI, HPE CUAGN BOB, PSE RPT INFO, PSE RPT RIG ES ANT, PSE RPT CALL, PWR 1TT W  \n";

/***/ })

}]);