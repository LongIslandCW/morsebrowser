"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB25912_json"],{

/***/ "./src/wordfiles/SB25912.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB25912.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb59,kmy4028bkzj/16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);