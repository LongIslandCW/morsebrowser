"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_Com_json"],{

/***/ "./src/presets/sets/Com.json":
/*!***********************************!*\
  !*** ./src/presets/sets/Com.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"20 wpm","filename":"Com_test_Preset.json"}]}');

/***/ })

}]);