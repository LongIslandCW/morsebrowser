"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Word_03_txt"],{

/***/ "./src/wordfiles/INT3_1 Word_03.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT3_1 Word_03.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "promote {close|} \r\n{|promote close} \r\nfield {where|} \r\n{|field where} \r\ndevote {organized|} \r\n{|devote organized} \r\nfaculty {trace|} \r\n{|faculty trace} \r\nexact {spoke|} \r\n{|exact spoke} \r\ndiagnose {troubled|} \r\n{|diagnose troubled} \r\nconvinced {professor|} \r\n{|convinced professor} \r\ndoctor {crack|} \r\n{|doctor crack} \r\ntrailer {builder|} \r\n{|trailer builder} \r\nnormal {anyone|} \r\n{|normal anyone} ";

/***/ })

}]);