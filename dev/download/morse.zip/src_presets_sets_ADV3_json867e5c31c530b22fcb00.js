"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV3_json"],{

/***/ "./src/presets/sets/ADV3.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 35/35","filename":"ADV3BUF.json"},{"display":"Affixes","filename":"ADV3_AFIX.json"},{"display":"Call Signs","filename":"ADV3_CS.json"},{"display":"Familiarity Phrases","filename":"ADV3_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"ADV3_FAM_Sentences.json"},{"display":"Familiarity Spell","filename":"ADV3_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV3_FAM_WORDS.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Recognition - Spell","filename":"ADV3_REC_Spell.json"},{"display":"Recognition - Words","filename":"ADV3_REC_Words.json"},{"display":"TTR","filename":"ADVICR.json"},{"display":"Com 18/16 wpm","filename":"COM_1816.json"},{"display":"Com 20/16 wpm","filename":"COM_2016.json"},{"display":"Com 22/16 wpm","filename":"COM_2216.json"},{"display":"Com 25/16 wpm","filename":"COM_2516.json"},{"display":"Com 30/16 wpm","filename":"COM_3016.json"}]}');

/***/ })

}]);