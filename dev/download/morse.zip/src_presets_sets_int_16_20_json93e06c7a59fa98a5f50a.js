"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_int_16_20_json"],{

/***/ "./src/presets/sets/int_16_20.json":
/*!*****************************************!*\
  !*** ./src/presets/sets/int_16_20.json ***!
  \*****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 16/16","filename":"INT2_Default_16.json"},{"display":"Default 12/12","filename":"INT2_Default_12.json"},{"display":"Default 20/20","filename":"INT2_Default_20.json"},{"display":"Random Groups 1-5","filename":"INT2_Random_1-5.json"},{"display":"VST","filename":"INT2_VST.json"},{"display":"Groups of 5","filename":"INT2_Groups_5.json"},{"display":"Inter-character Head Copy","filename":"INT2_ICHC.json"},{"display":"ICR","filename":"INT2_ICR.json"},{"display":"VET","filename":"INT2_VET.json"},{"display":"Instant Word Recognition","filename":"INT2_IWR.json"},{"display":"Progressive Word Building","filename":"INT2_PWG.json"},{"display":"Voice On & Spell On","filename":"INT2_Von_Son.json"},{"display":"Voice On & Spell Off","filename":"INT2_Von_Soff.jsoff"}]}');

/***/ })

}]);