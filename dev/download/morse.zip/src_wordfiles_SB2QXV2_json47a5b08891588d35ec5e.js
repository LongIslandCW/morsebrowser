"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV2_json"],{

/***/ "./src/wordfiles/SB2QXV2.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2QXV2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"qxv","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);