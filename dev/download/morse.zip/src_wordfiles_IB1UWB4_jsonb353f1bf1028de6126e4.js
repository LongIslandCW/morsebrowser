"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1UWB4_json"],{

/***/ "./src/wordfiles/IB1UWB4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1UWB4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"b","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);