"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD8_txt"],{

/***/ "./src/wordfiles/LCD8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/LCD8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CT \n{ID|idaho} \nIL \n{IN|indiana} \nNC \nND \nSC \nSD \nTN \nNL \nNT \nNS \n";

/***/ })

}]);