"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY4_txt"],{

/***/ "./src/wordfiles/SB2KMY4.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2KMY4.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "MY RIG KNWD\nANT DIPOLE\nANT YAGI\nOK OM SOLID CPY\nSOLID CPI\nFB CATHY\nNAME MIKE\nNAME HOWARD\nNAME RICH\nBEEN HAM TWO YRS\nSRI OM\nMY RIG ICOM\nMY RIG YAESU\nMY RIG TEN TEC\nMY RIG BOAT ANCHOR\nMY KEY BUG\nNICE SIG OM\n";

/***/ })

}]);