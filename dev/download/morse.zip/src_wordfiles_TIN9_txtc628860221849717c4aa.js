"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN9_txt"],{

/***/ "./src/wordfiles/TIN9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/TIN9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "ABT ANT BEEN TU R RAIN RR UR EA RU EU U NW NR RU NET\n";

/***/ })

}]);