"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1REA3_json"],{

/***/ "./src/wordfiles/SB1REA3.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1REA3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reauwbhof","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);