"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Words_08_txt"],{

/***/ "./src/wordfiles/INT3_1 Words_08.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/INT3_1 Words_08.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "motivate {Democrat|} \r\n{|motivate Democrat} \r\nvegetable {curtain|} \r\n{|vegetable curtain} \r\nfeature {total|} \r\n{|feature total} \r\nreverse {decrease|} \r\n{|reverse decrease} \r\ndivide {through|} \r\n{|divide through} \r\nevent {portrait|} \r\n{|event portrait} \r\ncampus {authorize|} \r\n{|campus authorize} \r\nhurricane {patience|} \r\n{|hurricane patience} \r\nlaunch {charter|} \r\n{|launch charter} \r\nliver {descend|} \r\n{|liver descend} ";

/***/ })

}]);