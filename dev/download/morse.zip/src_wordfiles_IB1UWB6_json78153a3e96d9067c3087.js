"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1UWB6_json"],{

/***/ "./src/wordfiles/IB1UWB6.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1UWB6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"hoflcd","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);