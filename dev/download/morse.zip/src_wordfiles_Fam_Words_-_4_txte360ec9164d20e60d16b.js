"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_4_txt"],{

/***/ "./src/wordfiles/Fam_Words - 4.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 4.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "who  \n{who|} \n{who|} \n{who|} \nwho  \n{|} \r\ntheir  \n{their|} \n{their|} \n{their|} \ntheir  \n{|} \r\nwell  \n{well|} \n{well|} \n{well|} \nwell  \n{|} \r\ndo  \n{do|} \n{do|} \n{do|} \ndo  \n{|} \r\neven  \n{even|} \n{even|} \n{even|} \neven  \n{|} \r\nor  \n{or|} \n{or|} \n{or|} \nor  \n{|} \r\nbut  \n{but|} \n{but|} \n{but|} \nbut  \n{|} \r\nthat  \n{that|} \n{that|} \n{that|} \nthat  \n{|} \r\nwhich  \n{which|} \n{which|} \n{which|} \nwhich  \n{|} \r\ngive  \n{give|} \n{give|} \n{give|} \ngive  \n{|} \r\ntwo  \n{two|} \n{two|} \n{two|} \ntwo  \n{|} \r\nso  \n{so|} \n{so|} \n{so|} \nso  \n{|} \r\nhim  \n{him|} \n{him|} \n{him|} \nhim  \n{|} \r\nthis  \n{this|} \n{this|} \n{this|} \nthis  \n{|} \r\nyear  \n{year|} \n{year|} \n{year|} \nyear  \n{|} \r\nyour  \n{your|} \n{your|} \n{your|} \nyour  \n{|} \r\nthese  \n{these|} \n{these|} \n{these|} \nthese  \n{|} \r\nwant  \n{want|} \n{want|} \n{want|} \nwant  \n{|} \r\nthey  \n{they|} \n{they|} \n{they|} \nthey  \n{|} \r\nmake  \n{make|} \n{make|} \n{make|} \nmake  \n{|} \r\nand  \n{and|} \n{and|} \n{and|} \nand  \n{|} \r\nnew  \n{new|} \n{new|} \n{new|} \nnew  \n{|} \r\nbecause  \n{because|} \n{because|} \n{because|} \nbecause  \n{|} \r\ntake \n{take|} \n{take|} \n{take|} \ntake \n{|} \r\n\r\n\r\n";

/***/ })

}]);