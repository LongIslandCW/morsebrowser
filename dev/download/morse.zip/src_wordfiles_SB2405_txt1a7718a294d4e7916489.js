"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2405_txt"],{

/***/ "./src/wordfiles/SB2405.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2405.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "ADØWE AI4PL G4FON GØPOT WBØISG N4DTR WB4UTB WBØHOA AAØTIN AC4LCD ABØCD N4FOH NØCDL  \n";

/***/ })

}]);