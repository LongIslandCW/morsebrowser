"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per2_txt"],{

/***/ "./src/wordfiles/per2.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per2.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "V V \nCAKE\nCARD\nJUNK\nGOLD\n";

/***/ })

}]);