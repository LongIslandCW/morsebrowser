"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_06_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_06.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_06.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "although {conclude|} \r\n{|although conclude} \r\nimpressive {immigrant|} \r\n{|impressive immigrant} \r\nselection {inventory|} \r\n{|selection inventory} \r\narchitect {corruption|} \r\n{|architect corruption} \r\nmagazine {argument|} \r\n{|magazine argument} \r\ncontinuing {politically|} \r\n{|continuing politically} \r\nstructure {collapse|} \r\n{|structure collapse} \r\ndescribe {regulation|} \r\n{|describe regulation} \r\nweakness {position|} \r\n{|weakness position} \r\nautomobile {military|} \r\n{|automobile military} ";

/***/ })

}]);