"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV1_json"],{

/***/ "./src/wordfiles/SB2QXV1.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2QXV1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);