"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY8_txt"],{

/***/ "./src/wordfiles/IB2KMY8.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2KMY8.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "AL AK AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NH NM NY NC ND OH OK PA RI SC SD TN UT WA WI WY\r\n\r\n";

/***/ })

}]);