"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per10_txt"],{

/***/ "./src/wordfiles/per10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/per10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "6BHSH5\t\n1JB6J1\n6BHSH5\t\n";

/***/ })

}]);