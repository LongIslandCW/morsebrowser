"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK7_json"],{

/***/ "./src/wordfiles/SB228BK7.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB228BK7.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb28bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);