"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_07_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_07.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_07.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "Canadian {reliable|} \r\n{|Canadian reliable} \r\nactually {advocate|} \r\n{|actually advocate} \r\nprescription {partially|} \r\n{|prescription partially} \r\ncarbohydrate {interview|} \r\n{|carbohydrate interview} \r\nrecognition {occupation|} \r\n{|recognition occupation} \r\nmechanic {remember|} \r\n{|mechanic remember} \r\nblessing {highlight|} \r\n{|blessing highlight} \r\ncelebration {essential|} \r\n{|celebration essential} \r\nbrilliant {recognize|} \r\n{|brilliant recognize} \r\nbiography {consultant|} \r\n{|biography consultant} ";

/***/ })

}]);