"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_10_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_10.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_10.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "package {cheek|} \r\n  {|package cheek} \r\nfront {citizen|} \r\n  {|front citizen} \r\nsmile {anger|} \r\n  {|smile anger} \r\nplease {print|} \r\n  {|please print} \r\nAfrican {subject|} \r\n  {|African subject} \r\nnotice {father|} \r\n  {|notice father} \r\nscale {medium|} \r\n  {|scale medium} \r\nlack {slave|} \r\n  {|lack slave} \r\nsorry {track|} \r\n  {|sorry track} \r\nvision {similar|} \r\n  {|vision similar} ";

/***/ })

}]);