"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1UWB7_json"],{

/***/ "./src/wordfiles/IB1UWB7.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1UWB7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"uwbhoflcd","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);