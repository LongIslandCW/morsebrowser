"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY7_json"],{

/***/ "./src/wordfiles/SB2KMY7.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2KMY7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);