"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_INT3_json"],{

/***/ "./src/presets/sets/INT3.json":
/*!************************************!*\
  !*** ./src/presets/sets/INT3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 16/16","filename":"INT3_DEFAULT_16.json"},{"display":"Default 20/20","filename":"INT3_DEFAULT_20.json"},{"display":"Affixes","filename":"INT3BUF.json"},{"display":"Call Signs","filename":"INT3_CS.json"},{"display":"Familiarity Phrases","filename":"INT3_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"INT3_FAM_Sentences.json"},{"display":"Familiarity Spelling","filename":"INT3_FAM_Spell.json"},{"display":"Familiarity Words","filename":"INT3_FAM_Words.json"},{"display":"Multi Words","filename":"INT3_MW.json"},{"display":"Phrases","filename":"INT3_PHRASES.json"},{"display":"Recognition - Spell","filename":"INT3_REC_Spell.json"},{"display":"Recognition - Words","filename":"INT3_REC_Words.json"},{"display":"Sending Practice","filename":"INT3_SENDING.json"},{"display":"TTR","filename":"INT3_ICR.json"}]}');

/***/ })

}]);