"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS1_json"],{

/***/ "./src/wordfiles/IB1PGS1.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PGS1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"p","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);