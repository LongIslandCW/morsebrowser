"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_REA8_txt"],{

/***/ "./src/wordfiles/REA8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/REA8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AR \n{OH|ohio} \nWA \n";

/***/ })

}]);