"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK6_txt"],{

/***/ "./src/wordfiles/SB228BK6.txt":
/*!************************************!*\
  !*** ./src/wordfiles/SB228BK6.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "AL \nAR \nCA \nCO \nCT \n{DE|delaware} \nFL \n{GA|georgia} \n{HI|hawaii} \n{ID|idaho} \nID \nIL \n{IN|indiana} \nIA \n{IN|indiana} \nNE \nNH \nNC \nND \n{OH|ohio} \n{OR|oregon} \nPA \nRI \nSC \nSD \nTN \nUT \nWA \nWI \n";

/***/ })

}]);