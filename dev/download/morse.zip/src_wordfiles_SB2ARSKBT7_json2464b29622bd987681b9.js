"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ARSKBT7_json"],{

/***/ "./src/wordfiles/SB2ARSKBT7.json":
/*!***************************************!*\
  !*** ./src/wordfiles/SB2ARSKBT7.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb<ar><sk><bt>73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);