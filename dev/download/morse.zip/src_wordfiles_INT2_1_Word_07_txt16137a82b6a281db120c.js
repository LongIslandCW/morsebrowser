"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_07_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_07.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_07.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "quick {eight|} \r\n  {|quick eight} \r\nhome {auto|} \r\n  {|home auto} \r\nslip {adviser|} \r\n  {|slip adviser} \r\nbefore {salmon|} \r\n  {|before salmon} \r\ndress {whole|} \r\n  {|dress whole} \r\nequally {apple|} \r\n  {|equally apple} \r\ndepend {AIDS|} \r\n  {|depend AIDS} \r\nsound {path|} \r\n  {|sound path} \r\nangry {mess|} \r\n  {|angry mess} \r\nreal {memory|} \r\n  {|real memory} ";

/***/ })

}]);