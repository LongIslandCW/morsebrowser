"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_12_Letter_Words_txt"],{

/***/ "./src/wordfiles/12_Letter_Words.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/12_Letter_Words.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "complication\r\ndiscriminate\r\ncontribution\r\naccumulation\r\nconstituency\r\norganisation\r\ntransmission\r\ncontemporary\r\nprescription\r\ncompensation\r\nconservation\r\ndisagreement\r\nintelligence\r\nconversation\r\nconventional\r\nspokesperson\r\nconstitution\r\nintervention\r\nheadquarters\r\ncontinuation\r\nregistration\r\nannouncement\r\npresentation\r\nsatisfaction\r\nneighborhood\r\njurisdiction\r\nintroduction\r\nanticipation\r\ncircumstance\r\ndemonstrator\r\npresidential\r\nconsultation\r\nrelationship\r\nmanufacturer\r\nconservative\r\nintermediate\r\ncivilization\r\nreproduction\r\nprofessional\r\nconglomerate\r\nacquaintance\r\ninterference\r\narchitecture\r\nrefrigerator";

/***/ })

}]);