"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per3_txt"],{

/***/ "./src/wordfiles/per3.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per3.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "V V DIODE, APPLE, BASIS, SLASH /\n";

/***/ })

}]);