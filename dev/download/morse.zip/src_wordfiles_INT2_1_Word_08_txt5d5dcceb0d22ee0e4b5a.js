"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_08_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_08.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_08.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "after {mass|} \r\n  {|after mass} \r\nmarket {seize|} \r\n  {|market seize} \r\nalbum {sharp|} \r\n  {|album sharp} \r\nhang {shelter|} \r\n  {|hang shelter} \r\nassess {peer|} \r\n  {|assess peer} \r\nking {weekly|} \r\n  {|king weekly} \r\nface {sixth|} \r\n  {|face sixth} \r\nsuffer {bottom|} \r\n  {|suffer bottom} \r\nexpose {animal|} \r\n  {|expose animal} \r\nstop {thick|} \r\n  {|stop thick} \r\n";

/***/ })

}]);