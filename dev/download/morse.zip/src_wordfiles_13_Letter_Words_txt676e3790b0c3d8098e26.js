"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_13_Letter_Words_txt"],{

/***/ "./src/wordfiles/13_Letter_Words.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/13_Letter_Words.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "contradiction \r\nstrikebreaker \r\nenvironmental \r\ninappropriate \r\ncomprehensive \r\nentertainment \r\nunderstanding \r\nrevolutionary \r\nembarrassment \r\nqualification \r\nconcentration \r\nsupplementary \r\nconsideration \r\nconfrontation \r\nconstellation \r\ncommunication \r\npreoccupation \r\ndemonstration \r\ninvestigation \r\nconsciousness ";

/***/ })

}]);