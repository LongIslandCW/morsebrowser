"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_2_txt"],{

/***/ "./src/wordfiles/Fam_Words - 2.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 2.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "he  \n{he |} \n{he |} \n{he |} \nhe  \n{|} \r\nhow  \n{how |} \n{how |} \n{how |} \nhow  \n{|} \r\nby  \n{by |} \n{by |} \n{by |} \nby  \n{|} \r\ncould  \n{could |} \n{could |} \n{could |} \ncould  \n{|} \r\nhis  \n{his |} \n{his |} \n{his |} \nhis  \n{|} \r\nnot  \n{not |} \n{not |} \n{not |} \nnot  \n{|} \r\nno  \n{no |} \n{no |} \n{no |} \nno  \n{|} \r\nperson  \n{person |} \n{person |} \n{person |} \nperson  \n{|} \r\non  \n{on |} \n{on |} \n{on |} \non  \n{|} \r\nwork  \n{work |} \n{work |} \n{work |} \nwork  \n{|} \r\ngood  \n{good |} \n{good |} \n{good |} \ngood  \n{|} \r\nknow  \n{know |} \n{know |} \n{know |} \nknow  \n{|} \r\nwhen  \n{when |} \n{when |} \n{when |} \nwhen  \n{|} \r\nI  \n{I |} \n{I |} \n{I |} \nI  \n{|} \r\nlook  \n{look |} \n{look |} \n{look |} \nlook  \n{|} \r\ngo  \n{go |} \n{go |} \n{go |} \ngo  \n{|} \r\nday  \n{day |} \n{day |} \n{day |} \nday  \n{|} \r\ncome  \n{come |} \n{come |} \n{come |} \ncome  \n{|} \r\nover  \n{over |} \n{over |} \n{over |} \nover  \n{|} \r\nsay  \n{say |} \n{say |} \n{say |} \nsay  \n{|} \r\nto  \n{to |} \n{to |} \n{to |} \nto  \n{|} \r\nfor  \n{for |} \n{for |} \n{for |} \nfor  \n{|} \r\nabout  \n{about |} \n{about |} \n{about |} \nabout  \n{|} \r\nthem  \n{them |} \n{them |} \n{them |} \nthem  \n{|} \r\ncan  \n{can |} \n{can |} \n{can |} \ncan  \n{|} \r\n";

/***/ })

}]);