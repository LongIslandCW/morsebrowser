"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Word_09_txt"],{

/***/ "./src/wordfiles/INT3_1 Word_09.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT3_1 Word_09.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "existence {weird|} \r\n{|existence weird} \r\nconsumer {wound|} \r\n{|consumer wound} \r\noffer {beyond|} \r\n{|offer beyond} \r\ncrucial {request|} \r\n{|crucial request} \r\nkneel {breathe|} \r\n{|kneel breathe} \r\nholiday {standard|} \r\n{|holiday standard} \r\ninstinct {grateful|} \r\n{|instinct grateful} \r\nblack {subtle|} \r\n{|black subtle} \r\naffect {survey|} \r\n{|affect survey} \r\nthread {uncle|} \r\n{|thread uncle} ";

/***/ })

}]);