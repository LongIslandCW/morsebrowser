"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV4_txt"],{

/***/ "./src/wordfiles/SB2QXV4.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2QXV4.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "GA ES TNX FER CALL\nGE ES TNX FER RPRT\nTNX FER FB RPRT\nSOLID CPI RON\nQTH NR PHOENIX\nQTH PORTLAND\nWX RAIN ES WIND\nWX SUN ES NICE\nRIG FLEX\nRIG QSX\nRIG TEN TEC\nRIG TEN TEC\nRIG BOAT ANCHOR\nANT VERT\nNICE FIST OT\nNICE SIG\nWILL QRT NOW\nTNX FER FB QSO\nGUD DX ES HPE CUAGN SOCHO san  \n";

/***/ })

}]);