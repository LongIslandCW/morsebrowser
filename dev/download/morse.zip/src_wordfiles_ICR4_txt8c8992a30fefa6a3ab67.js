"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR4_txt"],{

/***/ "./src/wordfiles/ICR4.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR4.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);