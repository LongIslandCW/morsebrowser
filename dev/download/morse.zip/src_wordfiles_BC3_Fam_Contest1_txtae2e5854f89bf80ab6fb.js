"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Fam_Contest1_txt"],{

/***/ "./src/wordfiles/BC3_Fam_Contest1.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Fam_Contest1.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "UR 599 \r\nUR 599 TX NAME \r\nUR 599 TX NAME TOM SKCC \r\nUR 599 TX NAME TOM SKCC NR 9877 \r\n{e|} \r\nUR 359 \r\nUR 359 AZ NAME \r\nUR 359 AZ NAME MIKE SKCC \r\nUR 359 AZ NAME MIKE SKCC NR 8374 \r\n{e|} \r\nWB2UZE TNX \r\nWB2UZE TNX 359 359 \r\nWB2UZE TNX 359 359 BK TU \r\nWB2UZE TNX 359 359 BK TU 599 599 \r\n{e|} \r\nKB4QQJ TU \r\nKB4QQJ TU 2D KS \r\nKB4QQJ TU 2D KS RR TNX \r\nKB4QQJ TU 2D KS RR TNX 2D ME \r\n";

/***/ })

}]);