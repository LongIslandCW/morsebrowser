"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_1_txt"],{

/***/ "./src/wordfiles/Fam_Words - 1.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 1.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "some  \n{some|} \n{some|} \n{some|} \nsome  \n{|} \r\nthan  \n{than|} \n{than|} \n{than|} \nthan  \n{|} \r\nin  \n{in|} \n{in|} \n{in|} \nin  \n{|} \r\nnow  \n{now|} \n{now|} \n{now|} \nnow  \n{|} \r\none  \n{one|} \n{one|} \n{one|} \none  \n{|} \r\nback  \n{back|} \n{back|} \n{back|} \nback  \n{|} \r\nof  \n{of|} \n{of|} \n{of|} \nof  \n{|} \r\nall  \n{all|} \n{all|} \n{all|} \nall  \n{|} \r\nup  \n{up|} \n{up|} \n{up|} \nup  \n{|} \r\njust  \n{just|} \n{just|} \n{just|} \njust  \n{|} \r\nalso  \n{also|} \n{also|} \n{also|} \nalso  \n{|} \r\nwhat  \n{what|} \n{what|} \n{what|} \nwhat  \n{|} \r\nlike  \n{like|} \n{like|} \n{like|} \nlike  \n{|} \r\nthen  \n{then|} \n{then|} \n{then|} \nthen  \n{|} \r\nme  \n{me|} \n{me|} \n{me|} \nme  \n{|} \r\nits  \n{its|} \n{its|} \n{its|} \nits  \n{|} \r\nmost  \n{most|} \n{most|} \n{most|} \nmost  \n{|} \r\nafter  \n{after|} \n{after|} \n{after|} \nafter  \n{|} \r\nother  \n{other|} \n{other|} \n{other|} \nother  \n{|} \r\nwould  \n{would|} \n{would|} \n{would|} \nwould  \n{|} \r\nuse  \n{use|} \n{use|} \n{use|} \nuse  \n{|} \r\nus  \n{us|} \n{us|} \n{us|} \nus  \n{|} \r\nshe  \n{she|} \n{she|} \n{she|} \nshe  \n{|} \r\nhave  \n{have|} \n{have|} \n{have|} \nhave  \n{|} \r\nan  \n{an|} \n{an|} \n{an|} \nan  \n{|} \r\n";

/***/ })

}]);