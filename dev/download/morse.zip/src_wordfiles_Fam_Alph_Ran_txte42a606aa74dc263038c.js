"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Alph_Ran_txt"],{

/***/ "./src/wordfiles/Fam_Alph_Ran.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/Fam_Alph_Ran.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "Z \n{Z|} \n{Z|} \n{Z|} \nZ \r\n{|} \r\nQ \n{Q|} \n{Q|} \n{Q|} \nQ \r\n{|} \r\n D \n{D|} \n{D|} \n{D|} \nD \r\n{|} \r\nO \n{O|} \n{O|} \n{O|} \nO \r\n{|} \r\nX \n{X|} \n{X|} \n{X|} \nX \r\n{|} \r\nE \n{E|} \n{E|} \n{E|} \nE \r\n{|} \r\nY \n{Y|} \n{Y|} \n{Y|} \nY \r\n{|} \r\nJ \n{J|} \n{J|} \n{J|} \nJ \r\n{|} \r\n{R|R}  \n{R|} \n{R|} \n{R|} \n{R|R} \r\n{|} \r\nA \n{A|} \n{A|} \n{A|} \nA \r\n{|} \r\n{K|K} \n{K|} \n{K|} \n{K|} \n{K|K} \r\n{|} \r\nS \n{S|} \n{S|} \n{S|} \nS \r\n{|} \r\nP \n{P|} \n{P|} \n{P|} \nP \r\n{|} \r\n{F|F} \n{F|} \n{F|} \n{F|} \n{F|F} \r\n{|} \r\nM \n{M|} \n{M|} \n{M|} \nM \r\n{|} \r\nH \n{H|} \n{H|} \n{H|} \nH \r\n{|} \r\n{C|C} \n{C|} \n{C|} \n{C|} \n{C|C} \r\n{|} \r\n{W|W}  \n{W|} \n{W|} \n{W|} \n{W|W}  \r\n{|} \r\nG \n{G|} \n{G|} \n{G|} \nG \r\n{|} \r\n{T|T} \n{T|} \n{T|} \n{T|} \n{T|T} \r\n{|} \r\nU \n{U|} \n{U|} \n{U|} \nU \r\n{|} \r\nI \n{I|} \n{I|} \n{I|} \nI \r\n{|} \r\nV \n{V|} \n{V|} \n{V|} \nV \r\n{|} \r\n{N|N} \n{N|} \n{N|} \n{N|} \n{N|N} \r\n{|} \r\nB \n{B|} \n{B|} \n{B|} \nB \r\n{|} \r\nL \n{L|} \n{L|} \n{L|} \nL \r\n\r\n\r\n";

/***/ })

}]);