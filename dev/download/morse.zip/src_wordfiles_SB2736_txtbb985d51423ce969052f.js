"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2736_txt"],{

/***/ "./src/wordfiles/SB2736.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2736.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL \nAR \nCA \nCO \nCT \n{DE|delaware} \nFL \n{GA|georgia} \n{HI|hawaii} \n{ID|idaho} \nIL \n{IN|indiana} \nIA \n{LA|louisiana} \nNE \nNH \nNC \nND \n{OH|ohio} \n{OR|oregon} \nPA \nRI \nSC \nSD \nTN \nUT \nWA \nWI \n";

/***/ })

}]);