"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2405_txt"],{

/***/ "./src/wordfiles/SB2405.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2405.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AD0WE AI4PL G4FON G0POT WB0ISG N4DTR AB4NY K4MB KB4YM N0KM WB0KMF WB4UTB WB0HOA KB4RAN AA0TIN AC4LCD AB0CD WB4ERY N4FOH N0CDL";

/***/ })

}]);