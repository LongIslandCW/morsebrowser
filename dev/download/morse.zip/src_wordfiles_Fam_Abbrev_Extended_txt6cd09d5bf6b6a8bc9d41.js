"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Abbrev_Extended_txt"],{

/***/ "./src/wordfiles/Fam_Abbrev_Extended.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/Fam_Abbrev_Extended.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "WX \r\nGE \r\nAGN \r\n{HW?|how copy?} \r\n{MSG|Message} \r\n{QRQ|send faster} \r\nVERT \r\nPWR \r\nGN \r\n73 \r\nTX \r\nHR \r\nRX \r\n{TMW|Tomorrow} \r\n{XCVR|Transceiver} \r\nCW \r\n{RCVR|Receiver} \r\nYRS \r\n{SEZ|Says} \r\n{REF|reference} \r\n{C|celsius} \r\nFER \r\nDE \r\n{C|correct} \r\nGA \r\n{GG|Going} \r\n{OM|Old man} \r\nCFM \r\n{F|fahrenheit} \r\nABT \r\nCPY \r\n{CONDX|Conditions} \r\n{DN|Down} \r\nGUD \r\n{QRZ|who is calling} \r\n{VE|Understood} \r\nTEMP \r\nSIG \r\n{QSL|acknowledge receipt} \r\n{QRS|send slower} \r\nUR \r\nPSE \r\n{BT|Pause} \r\n{SED|Said} \r\n{AA|All after} \r\n{RIG|Radio} \r\nRST \r\n{NIL|Nothing} \r\n{OT|Old timer} \r\nRPRT \r\n{XMTR|Transmitter} \r\n{QSB|signals fading} \r\n{BUG|Semi automatic key} \r\nCUL \r\n{BCNU|be seeing you} \r\nVY \r\n{SSB|Single side band} \r\nDX \r\n559 \r\n{AS|Stand by} \r\n599 \r\n{HPE|Hope} \r\n{HV|Have} \r\nB4 \r\n{STN|Station} \r\n{CNT|Cant} \r\n5NN \r\nES \r\n{YR|Year} \r\n{CUM|Come} \r\n{OP|Operator} \r\n{AB|All before} \r\nTU \r\nFT \r\nTNX \r\n{EL|Element} \r\n{XYL|Wife} \r\n{SUM|Some} \r\n{CLG|Calling} \r\n{QSY|change frequency} \r\n{INFO|Info} \r\n{QTH|location}\r\n{R|Received} \r\n{LID|poor operator} \r\n{YL|Young lady} \r\n{BK|Break} \r\nSKED \r\nCUAGN \r\nRPT \r\n{WKG|Working} \r\n{CL|clear} \r\n{WRD|Word} \r\nGM \r\nFB \r\n{ADR|Address} \r\n{URS|Yours} \r\n{W|Watts} \r\n{GND|Ground} \r\n{SK|End of contact} \r\n{RCD|Received} \r\nHW \r\n{QRM|interference} \r\n{QRT|stop sending} \r\nWID \r\n{DIFF|Difference} \r\nCPI \r\n{NR|Number} \r\n{AR|End of message} \r\nSRI \r\nANT \r\n{WKD|Worked} \r\nCU \r\n{QRP|decrease power} \r\n{QRN|static} \r\nTKS \r\n{QSO|contact} \r\n{U|You} \r\n{TT|That}";

/***/ })

}]);