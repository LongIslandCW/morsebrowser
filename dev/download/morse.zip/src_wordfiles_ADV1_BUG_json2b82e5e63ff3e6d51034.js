"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_BUG_json"],{

/***/ "./src/wordfiles/ADV1_BUG.json":
/*!*************************************!*\
  !*** ./src/wordfiles/ADV1_BUG.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);