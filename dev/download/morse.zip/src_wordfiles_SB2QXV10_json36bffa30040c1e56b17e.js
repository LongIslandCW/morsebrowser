"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV10_json"],{

/***/ "./src/wordfiles/SB2QXV10.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB2QXV10.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv59,kmy4028bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);