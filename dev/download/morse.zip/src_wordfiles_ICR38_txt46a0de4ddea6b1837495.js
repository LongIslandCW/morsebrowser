"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR38_txt"],{

/***/ "./src/wordfiles/ICR38.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR38.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "SI =\n54 =\nE5 =\nE6 =\nE6 =\nHT =\n6J =\nSD =\nI1 =\n56 =\n1T =\nSI =\n6D =\nI1 =\nES =\nH5 =\n6B =\nBH =\nTI =\nI6 =\nI4 =\nDB =\n56 =\n5I =\n6D =\n1D =\nS6 =\n6J =\nD1 =\n5S =\nSH =\nST =\nSH =\nHT =\nES =\nVD =\nI1 =\nDJ =\n6B =\n6T =\nT5 =\nVT =\n56 =\nSV =\nSE =\n5B =\nS1 =\nHE =\nVB =\nSI =\nH6 =\n1H =\nSD =\nIE =\nVS =\n6H =\nEJ =\n5S =\nT1 =\nBH =\n1H =\n6S =\nIB =\nV4 =\n1E =\nSD =\nE6 =\n5J =\nHE =\nTS =\nT5 =\n15 =\nVH =\nTB =\n6S =\nSB =\n54 =\nHV =\n1I =\nE1 =\nE6 =\nE6 =\n6T =\n41 =\nT1 =\n4V =\nDJ =\n6H =\nD1 =\nE6 =\nSJ =\nHE =\n4D =\nIS =\nDT =\n64 =\n5T =\n6T =\nHB =\nIT =\n14 =\n6H =\nT5 =\nBI =\n4E =\nBE =\n41 =\nDJ =\n4D =\nV1 =\nDJ =\n66 =\nJJ =\n6S =\n4V =\nTV =\nTB =\nBJ =\nS5 =\nHS =\n5H =\nSH =\nVB =\n6B =\n5J =\nHI =\nIH =\nBB =\nDV =\nIV =\nDJ =\nSS =\nJ5 =\n4E =\nJ5 =\nHB =\nD4 =\nHH =\nBE =\nH6 =\n5J =\n65 =\nIS =\n64 =\n6J =\n1B =\nB1 =\nSD =\n6V =\n51 =\nDH =\nJJ =\nSV =\nJ6 =\n45 =\nTV =\nV6 =\n4D =\n6E =\nSB =\n45 =\nDJ =\nH6 =\nS5 =\n44 =\n6E =\nD5 =\n5V =\nDE =\nH1 =\n1B =\nDE =\n15 =\n4I =\nEE =\n6T =\nSD =\nIE =\nVS =\nV5 =\nVE =\n45 =\n6B =\nH5 =\n1D =\nT4 =\n56\n";

/***/ })

}]);