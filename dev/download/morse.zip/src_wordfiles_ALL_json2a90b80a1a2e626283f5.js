"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ALL_json"],{

/***/ "./src/wordfiles/ALL.json":
/*!********************************!*\
  !*** ./src/wordfiles/ALL.json ***!
  \********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890<sk><bt>/,.?<ar><bk>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);