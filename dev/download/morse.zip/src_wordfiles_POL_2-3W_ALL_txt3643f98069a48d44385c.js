"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_2-3W_ALL_txt"],{

/***/ "./src/wordfiles/POL_2-3W_ALL.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_2-3W_ALL.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \nAN \nAT \nAS \nAGE \nASK \nAND \nALL \nANY \nAGN \nAIR \nADD \nBBB \nBE \nBY \nBUT \nBET \nBOT \nBAT \nBED \nBIT \nBOY \nCCC \nCAN \nCAR \nCAP \nCAB \nCUL \nCRY \nCOW \nCUT \nCQ \nDDD \nDO \nDAY \nDID \nDIP \nDE \nDOT \nDWN \nEEE \nES \nEX \nEAR \nEAT \nEGO \nEYE \nEGG \nELM \nEND \nFFF \nFOR \nFER \nFIT \nFAT \nFAN \nFLU \nFOG \nFRY \nFOX \nFUN \nFIX \nGGG \nGO \nGET \nGIN \nGAS \nGAP \nGOT \nGUM \nGUY \nGYM \nHHH \nHE \nHER \nHIM \nHIS \nHAD \nHEN \nHAM \nHUG \nHOW \nHUB \nIII \nIF \nIT \nIN \nICE \nILL \nINK \nITS \nICK \nICY \nJJJ \nJET \nJAR \nJAB \nJAM \nJOG \nJOY \nJIG \nJUG \nKKK \nKIT \nKEG \nKEY \nKID \nKIN \nLLL \nLET \nLAB \nLAW \nLAG \nLEG \nLOT \nLAP \nLET \nLUG \nLOW \nLAD \nMMM \nME \nMY \nMAN \nMAP \nMAY \nMAD \nMEN \nMIC \nMOP \nMAT \nMUG \nMOM \nNNN \nNO \nNOW \nNEW \nNET \nNAB \nNIP \nNOT \nNUT \nNIL \nNAP \nOOO \nOR \nON \nOF \nOUT \nOUR \nONE \nOIL \nOLD \nOAK \nOHM \nOFF \nODD \nPPP \nPAT \nPET \nPAD \nPAN \nPAR \nPIE \nPOP \nPUG \nPRO \nPRY \nPUN \nPIG \nPIN \nPEG \nPEN \nQQQ \nQSO \nQRL \nQRS \nQSY \nRRR \nRUN \nRAN \nRAG \nRIB \nRAW \nRED \nRIM \nROB \nRUG \nRAY \nRIP \nSSS \nSO \nSON \nSKI \nSOB \nSUN \nSEE \nSHE \nSET \nSAY \nSAT \nSUM \nTTT \nTHE \nTO \nTWO \nTAG \nTAN \nTAB \nTAR \nTEA \nTUG \nTOP \nTRY \nTOE \nTOO \nUUU \nUS \nUP \nUMP \nUFO \nUSE \nVVV \nVAN \nVAT \nVET \nVAC \nVEX \nWWW \nWE \nWHO \nWEB \nWAY \nWHY \nWAS \nWET \nWAG \nWAR \nWOW \nXXX \nXYL \nYYY \nYES \nYET \nYOU \nYUP \nYUM \nYEP \nZZZ \nZIG \nZAG \nZEN \nZOO \nZAP \nZIP \nZAP\r\n";

/***/ })

}]);