"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_bc1_json"],{

/***/ "./src/presets/sets/bc1.json":
/*!***********************************!*\
  !*** ./src/presets/sets/bc1.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/8","filename":"BC1_Default.json"},{"display":"Random groups 1-3","filename":"BC1_Random_groups_1_3.json"},{"display":"VST","filename":"BC1_VST.json"},{"display":"Reverse VST","filename":"BC1_RVST.json"},{"display":"Groups of 5","filename":"BC1_Groups_of_5.json"},{"display":"ICR","filename":"BC1_ICR.json"},{"display":"VET","filename":"BC1_VET.json"},{"display":"Reverse VET","filename":"BC1_RVET.json"},{"display":"Familiarity Spelling","filename":"BC1_FAM_Spell.json"},{"display":"Sending Practice","filename":"BC2_Sending.json"},{"display":"Phrases – Voice Off","filename":"BC1_Phrases_Voff.json"},{"display":"Phrases – Voice On","filename":"BC1_Phrases_Von.json"},{"display":"Voice On & Spell Off","filename":"BC1_Von_Soff.json"},{"display":"Voice On & Spell On","filename":"BC1_Von_Son.json"},{"display":"Progress Evaluation","filename":"BC1_P_Eval.json"}]}');

/***/ })

}]);