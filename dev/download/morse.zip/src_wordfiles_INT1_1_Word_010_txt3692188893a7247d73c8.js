"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_010_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_010.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_010.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "drive {chef|} \r\n{|drive chef} \r\nhope {sure|} \r\n{|hope sure} \r\nlogic {equip|} \r\n{|logic equip} \r\nplay {yes|} \r\n{|play yes} \r\nnovel {only|} \r\n{|novel only} \r\ntrail {orbit|} \r\n{|trail orbit} \r\nsport {fear|} \r\n{|sport fear} \r\nski {taste|} \r\n{|ski taste} \r\nseek {tape|} \r\n{|seek tape} \r\nball {early|} \r\n{|ball early} ";

/***/ })

}]);