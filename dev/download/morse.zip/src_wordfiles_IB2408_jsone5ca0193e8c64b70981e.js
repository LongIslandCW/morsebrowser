"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2408_json"],{

/***/ "./src/wordfiles/IB2408.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2408.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"40anb","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);