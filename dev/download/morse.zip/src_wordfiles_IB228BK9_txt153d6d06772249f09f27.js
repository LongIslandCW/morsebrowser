"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK9_txt"],{

/***/ "./src/wordfiles/IB228BK9.txt":
/*!************************************!*\
  !*** ./src/wordfiles/IB228BK9.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "AL AK AR CA CO CT DE FL GA HI ID IL IN IA KS LA NE NV NH NM NC ND OH PA RI SC SD TN UT WA WI\n";

/***/ })

}]);