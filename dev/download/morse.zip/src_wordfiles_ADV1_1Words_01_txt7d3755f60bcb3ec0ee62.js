"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_01_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_01.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_01.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "coastal {content|} \r\n{|coastal content} \r\nfamiliar {expect|} \r\n{|familiar expect} \r\nvolume {steadily|} \r\n{|volume steadily} \r\nfifteen {ourselves|} \r\n{|fifteen ourselves} \r\ndefinitely {rescue|} \r\n{|definitely rescue} \r\nsecond {plenty|} \r\n{|second plenty} \r\npopulation {tobacco|} \r\n{|population tobacco} \r\nextended {hockey|} \r\n{|extended hockey} \r\ncompletely {matter|} \r\n{|completely matter} \r\nCatholic {provider|} \r\n\r\n{|Catholic provider} \r\n";

/***/ })

}]);