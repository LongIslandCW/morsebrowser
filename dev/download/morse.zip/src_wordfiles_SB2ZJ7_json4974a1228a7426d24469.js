"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ZJ7_json"],{

/***/ "./src/wordfiles/SB2ZJ7.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2ZJ7.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbzj/16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);