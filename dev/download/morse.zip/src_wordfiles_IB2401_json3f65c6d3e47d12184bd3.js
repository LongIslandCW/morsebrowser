"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2401_json"],{

/***/ "./src/wordfiles/IB2401.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2401.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"4","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);