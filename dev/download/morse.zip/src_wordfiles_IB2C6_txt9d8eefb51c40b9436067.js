"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C6_txt"],{

/***/ "./src/wordfiles/IB2C6.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C6.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "W2LCW DE WB0JRH OK RICH TNX FER FB QSO \nES HP CUAGN 73 <AR> W2LCW DE WB0JRH TU <SK>\n";

/***/ })

}]);