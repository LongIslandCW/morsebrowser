"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV_json"],{

/***/ "./src/presets/sets/ADV.json":
/*!***********************************!*\
  !*** ./src/presets/sets/ADV.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 25/25","filename":"ADVBUF.json"},{"display":"Sentences","filename":"ADVBUF.json"},{"display":"Prefixes","filename":"ADVBUF.json"},{"display":"Suffixes","filename":"ADVBUF.json"},{"display":"2 Words","filename":"ADV2WB.json"},{"display":"3 Words","filename":"ADV3WB.json"},{"display":"4 Words","filename":"ADV4WB.json"},{"display":"5 Words","filename":"ADV5WB.json"}]}');

/***/ })

}]);