"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_N_json"],{

/***/ "./src/wordfiles/Fam_N.json":
/*!**********************************!*\
  !*** ./src/wordfiles/Fam_N.json ***!
  \**********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"1234567890","minWordSize":1,"maxWordSize":1,"practiceSeconds":120}');

/***/ })

}]);