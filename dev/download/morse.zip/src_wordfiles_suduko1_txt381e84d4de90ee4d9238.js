"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_suduko1_txt"],{

/***/ "./src/wordfiles/suduko1.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/suduko1.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "7 8 9 6 1 2 4 0 5 3\n0 3 5 2 1 4 7 9 6 8\n6 2 9 7 4 5 1 0 8 3\n1 8 3 5 0 9 4 2 7 6\n3 4 8 6 1 5 7 2 9 0\n7 2 9 3 6 5 1 0 8 4\n0 9 4 5 2 7 1 6 3 8\n5 2 0 7 9 8 1 6 4 3\n0 2 5 6 9 1 7 3 8 4\n5 2 6 8 7 0 4 9 1 3\n";

/***/ })

}]);