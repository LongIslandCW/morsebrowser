"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD10_txt"],{

/***/ "./src/wordfiles/LCD10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/LCD10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "CLING DIP LIP SLIP LID DIT SLID LIST PINT DIGS PIG SPLIT PIN PIT LIPS DING\n";

/***/ })

}]);