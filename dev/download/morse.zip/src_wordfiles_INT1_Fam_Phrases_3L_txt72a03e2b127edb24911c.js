"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Fam_Phrases_3L_txt"],{

/***/ "./src/wordfiles/INT1_Fam_Phrases_3L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT1_Fam_Phrases_3L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "IT \r\nIT COSTS \r\nIT COSTS A \r\n{<BT>|}\r\nHE \r\nHE ATE  \r\nHE ATE VERY \r\n{<BT>|}\r\nTHE \r\nTHE LAST \r\nTHE LAST TIME \r\n{<BT>|}\r\nCALL \r\nCALL IT \r\nCALL IT A \r\n{<BT>|}\r\nITS \r\nITS FINE \r\nITS FINE JUST \r\n{<BT>|}\r\nLET \r\nLET HIM \r\nLET HIM OFF \r\n{<BT>|}\r\nLET \r\nLET THE \r\nLET THE DOG \r\n{<BT>|}\r\nROLL \r\nROLL OVER \r\nROLL OVER THAT \r\n\r\n\r\n";

/***/ })

}]);