"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_SOTA_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_SOTA.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_SOTA.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "K4LJI GA 599 5NN AR BK \r{<BT>|} \r\nBK RR UR 259 259 ON W6/CC036 BK \r{<BT>|} \r\nKG7 GM 359 35N IL BK \r{<BT>|} \r\nBK TNX FER S2S 73 DE N0TME E E \r{<BT>|} \r\nA7BZ GE 579 57N WI IN K10368 \r{<BT>|} \r\nAC5BC GA 249 24N TX PARK? \r{<BT>|} \r\nUR 599 5NN CO REF? \r{<BT>|} \r\nBK RR UR 599 5NN ON W7O/CS157 BK \r{<BT>|} \r\nKV1G GA 339 339 MD IN K1369 \r{<BT>|} \r\nBK RR PARK K10368 K10368 BK \r{<BT>|} \r\nP2P DE AA8DPJ \r{<BT>|} \r\nAV0V GA 479 47N NV \r{<BT>|} \r\nUR 599 5NN ON W0C/FR087 BK \r{<BT>|} \r\nAK2Z GA 5NN 5NN PA \r{<BT>|} \r\nN1CC GA 579 579 AZ K1623 \r{<BT>|} \r\nBK RR UR 559 55N ON W6/CC002 BK \r{<BT>|} \r\nN1RC GA 357 357 LA \r{<BT>|} \r\nK2KCC GA 599 5NN NV REF? \r{<BT>|} \r\nKV1G GA 429 42N ON W2/GC002 \r{<BT>|} \r\nUR 579 57N TX \r{<BT>|} \r\nNG0EV GA 379 37N VA PARK? \r{<BT>|} \r\nS2S DE WB5GKI \r{<BT>|} \r\nWZ0F GE 579  57N NC \r{<BT>|} \r\nN8CT GA 249 24NN NY IN K2554 \r{<BT>|} \r\nBK RR UR 379 379 ON W4T/RV023 BK \r\r\n\r\r\n ";

/***/ })

}]);