"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Word_06_txt"],{

/***/ "./src/wordfiles/INT3_1 Word_06.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT3_1 Word_06.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "regard {pretty|} \r\n{|regard pretty} \r\npatient {private|} \r\n{|patient private} \r\ntoilet {momentum|} \r\n{|toilet momentum} \r\nwidely {sphere|} \r\n{|widely sphere} \r\nemission {engine|} \r\n{|emission engine} \r\nfight {lemon|} \r\n{|fight lemon} \r\nimage {casino|} \r\n{|image casino} \r\ndiagnosis {thought|} \r\n{|diagnosis thought} \r\nshock {encourage|} \r\n{|shock encourage} \r\nbread {quietly|} \r\n{|bread quietly} ";

/***/ })

}]);