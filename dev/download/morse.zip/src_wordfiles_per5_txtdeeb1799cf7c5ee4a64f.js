"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per5_txt"],{

/***/ "./src/wordfiles/per5.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per5.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "RR TNX FER CALL UR RST 348 348 QTH NR AUSTIN, TX <AR> BK\n";

/***/ })

}]);