"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SUFFIX_txt"],{

/***/ "./src/wordfiles/SUFFIX.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SUFFIX.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "ING USING RATING MAKING \r\nION SECTION ACTION EDUCATION \r\nENT RECENT DEPARTMENT PERCENT \r\n\r\n";

/***/ })

}]);