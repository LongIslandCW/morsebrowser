"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Words_txt"],{

/***/ "./src/wordfiles/POL_Words.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/POL_Words.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "\nAAA \nAN \nAT \nAND \nALL \n\nBBB \nBE \nBY \nBUT \nBACK \n\nCCC \nCAN \nCAR \nCAP \nCAB \n\nDDD \nDO \nDAY \nDOT \n\nEEE \nEAR \nEAT \nEASY \nEACH \n\nFFF \nFOR \nFER \nFIT \nFAT \n\nGGG \nGO \nGAS \nGAP \nGOT \n\nHHH \nHE \nHER \nHIS \nHAD \n\nIII \nICE \nILL \nINK \n\nJJJ \nJET \nJAR \nJAB \nJAM \n\nKKK \nKIT \nKEG \nKEY \n \nLLL \nLET \nLAB \nLAG \nLAP \n\nMMM \nME \nMY \nMAN \nMAP \n\nNNN \nNO \nNOW \nNEW \nNET \n\nOOO \nOR \nOUT \nONE \n\nPPP \nPAT \nPAD \nPAN \nPAR \n\nQQQ \nQSO \nQRL \nQRS \nQSY \n\nRRR \nRUN \nRAN \nRAG \nRIB \n\nSSS \nSO \nSON \nSUN \nSEE \nSET \nSAY \nSAT \n\nTTT \nTO \nTWO \nTAG \nTAN \nTAB \n\nUUU \nUS \nUP \nUSE \n\nVVV \nVAN \nVAT \nVET \n\nWWW \nWE \nWAY \nWHO \n\nXXX \nXYL \n\nYYY \nYES \nYET \nYEP \n\nZZZ \nZIG \nZAG \nZEN \nZAP \n\n\n\nAAA \nAN \nAT \nAND \nALL \n\nBBB \nBE \nBY \nBUT \nBACK \n\nCCC \nCAN \nCAR \nCAP \nCAB \n\nDDD \nDO \nDAY \nDOT \n\nEEE \nEAR \nEAT \nEASY \nEACH \n\nFFF \nFOR \nFER \nFIT \nFAT \n\nGGG \nGO \nGAS \nGAP \nGOT \n\nHHH \nHE \nHER \nHIS \nHAD \n\nJJJ \nJET \nJAR \nJAB \nJAM \n\nKKK \nKIT \nKEG \nKEY \n \nLLL \nLET \nLAB \nLAG \nLAP \n\nMMM \nME \nMY \nMAN \nMAP \n\nNNN \nNO \nNOW \nNEW \nNET \n\nOOO \nOR \nOUT \nONE \n\nPPP \nPAT \nPAD \nPAN \nPAR \n\nQQQ \nQSO \nQRL \nQRS \nQSY \n\nRRR \nRUN \nRAN \nRAG \nRIB \n\nSSS \nSO \nSON \nSUN \nSEE \nSET \nSAY \nSAT \n\nTTT \nTO \nTWO \nTAG \nTAN \nTAB \n\nUUU \nUS \nUP \nUSE \n\nVVV \nVAN \nVAT \nVET \n\nWWW \nWE \nWAY \nWHO \n\nXXX \nXYL \n\nYYY \nYES \nYET \nYEP \n\nZZZ \nZIG \nZAG \nZEN \nZAP \n";

/***/ })

}]);