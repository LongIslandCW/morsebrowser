"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_Fam_Phrases_4L_txt"],{

/***/ "./src/wordfiles/INT3_Fam_Phrases_4L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT3_Fam_Phrases_4L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "WHY \r\nWHY DONT\r\nWHY DONT WE \r\nWHY DONT WE JUST\r\n{e|} \r\nSPEAK \r\nSPEAK OF \r\nSPEAK OF THE \r\nSPEAK OF THE DEVIL\r\n{e|} \r\nCAN \r\nCAN YOU \r\nCAN YOU SAIL \r\nCAN YOU SAIL ON \r\n{e|} \r\nGIVE \r\nGIVE SOMEONE \r\nGIVE SOMEONE THE \r\nGIVE SOMEONE THE COLD \r\n{e|} \r\nLET \r\nLET THE \r\nLET THE DOG \r\nLET THE DOG RUN \r\nLET THE DOG RUN OUT \r\n{e|} \r\nHE \r\nHE ATE  \r\nHE ATE VERY \r\nHE ATE VERY WELL \r\n\r\n\r\n";

/***/ })

}]);