"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK3_json"],{

/***/ "./src/wordfiles/IB228BK3.json":
/*!*************************************!*\
  !*** ./src/wordfiles/IB228BK3.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"28","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);