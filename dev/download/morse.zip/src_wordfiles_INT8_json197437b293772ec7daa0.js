"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT8_json"],{

/***/ "./src/wordfiles/INT8.json":
/*!*********************************!*\
  !*** ./src/wordfiles/INT8.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<AR><SK><BT>BK","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);