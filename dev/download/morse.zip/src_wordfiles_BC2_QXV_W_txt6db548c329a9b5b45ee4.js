"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_QXV_W_txt"],{

/***/ "./src/wordfiles/BC2_QXV_W.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/BC2_QXV_W.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "QUE \r\nVIC \r\nGAS \r\nUSE \r\nFUN \r\nAGO \r\nBAT \r\nACT \r\nBAR \r\nCOW \r\nXRAY \r\nQUIT \r\nQUID \r\nWHAT \r\nALSO \r\nCOST \r\nFAST \r\nIDEA \r\nBOAT \r\nRIDE \r\nSOON \r\nROSE \r\nLOUD \r\nSAIL \r\nCALL \r\nWING \r\nLIVE \r\nLINE \r\nSHOE \r\nWIFE \r\nWAVE \r\nTHAN \r\nEXTRA \r\nQUICK \r\nQUIET \r\nQUITE \r\nEQUAL \r\nEQUIP \r\nSHAPE \r\nWHICH \r\nCOVER \r\nHEARD \r\nVALUE \r\nVISIT \r\nSTATE \r\nPAPER \r\nBLOOD \r\nFAVOR \r\nBEGAN \r\nWOULD \r\n\r\n";

/***/ })

}]);