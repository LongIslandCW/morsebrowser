"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR18_txt"],{

/***/ "./src/wordfiles/ICR18.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR18.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "KY0IK/P \nSX24BYE \nDJ9JM/P \nNG6NE/P \nDJ7HU/P \nKE8OD/P \nSN2016SP \nDL4WR/P \nNQ8DE/P \nSX24DAU \nSN2013ZQ \nKQ6NK/P \nSX24BQV \nNA9MV/P \nNH0HL/P \nSN2017ET \nDJ2TW/P \nSN2010TQ \nI3ZIW/P \nDL1EP/P \nSX24RJJ \nNS4NU/P \nI4YKF/P \nDL8TD/P \nDJ2UC/P \nW3LQ/QRP \nDJ6FI/P \nW6CH/QRP \nDL2TK/P \nI6ZFX/P \nDJ0MB/P \nI2HQM/P \nDJ4CM/P \nI1STE/P \nW8KL/QRP \nI4GUY/P \nDL8HN/P \nKW1ET/P \nDJ8DK/P \nW1HN/QRP \nSN2019FO \nDJ9AF/P \nSX24VWU \nKL5WJ/P \nDJ7UH/P \nDL2WO/P \nI3KBL/P \nDJ6EB/P \nW8XA/QRP \nDJ9NL/P \nSN2019GI \nKB4YG/P \nI6YRG/P \nI4LEE/P \nKP2LH/P \nI4IEH/P \nKM7NF/P \nSN2019HF \nNK3RO/P \nKX1WR/P \nNP0WY/P \nNS3XZ/P \nDL0UN/P \nDJ2PX/P \nDJ3FU/P \nDJ0FC/P \nNL0VG/P \nDJ4YY/P \nI6TAJ/P \nSX24OAL \nKC7GG/P \nSX24DZK \nDJ6NQ/P \nNR0BK/P \nI5RSM/P \nKG2GC/P \nDL7QU/P \nDL2TR/P \nI1UNY/P \nKL4YR/P \nDJ0ZN/P \nSN2017PL \nDJ1VV/P \nKW4HD/P \nNO4LD/P \nI0KPK/P \nSX24RAW \nSN2016XR \nDL9XM/P \nSN2012KR \nSX24UIE \nDJ1IM/P \nKF0VT/P \nSX24RZT \nW1NM/QRP \nW6EJ/QRP \nKB9OR/P \nNO8HF/P \n\n";

/***/ })

}]);