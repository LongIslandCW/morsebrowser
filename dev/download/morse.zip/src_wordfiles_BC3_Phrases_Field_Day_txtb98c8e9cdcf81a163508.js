"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_Field_Day_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_Field_Day.txt":
/*!*************************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_Field_Day.txt ***!
  \*************************************************/
/***/ ((module) => {

module.exports = "WC3L TU 4F {OH|ohio} \r\n{<BT>|} \r\nK3VB TU 2E {WMA|westerm Massaachusetts}\r\n{<BT>|} \r\nKT5WZL TU 2E {WTX|west texas} \r\n{<BT>|} \r\nN9RXF TU 1A IA \r\n{<BT>|} \r\nWO2X TU 2E MS \r\n{<BT>|} \r\nK0GNB TU 10A MO \r\n{<BT>|} \r\nKK2X TU 2B {GA|georga} \r\n{<BT>|} \r\n{A7SH|A 7 S H} TU 4C KS \r\n{<BT>|} \r\n{A6TO|A 6 T O } TU 1E UT \r\n{<BT>|} \r\nK3SR TU 1A {ORG|orange county} ";

/***/ })

}]);