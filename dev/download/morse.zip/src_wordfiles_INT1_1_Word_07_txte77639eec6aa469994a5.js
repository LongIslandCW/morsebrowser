"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_07_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_07.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_07.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "add {wrong|} \r\n{|add wrong} \r\nhand {build|} \r\n{|hand build} \r\ndoor {laugh|} \r\n{|door laugh} \r\ntear {the|} \r\n{|tear the} \r\nscene {store|} \r\n{|scene store} \r\nadmit {tea|} \r\n{|admit tea} \r\nhelp {loose|} \r\n{|help loose} \r\ngrant {gang|} \r\n{|grant gang} \r\ndown {hug|} \r\n{|down hug} \r\nbut {swing|} \r\n{|but swing} ";

/***/ })

}]);