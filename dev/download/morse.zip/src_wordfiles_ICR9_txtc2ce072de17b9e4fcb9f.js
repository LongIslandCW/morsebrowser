"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR9_txt"],{

/***/ "./src/wordfiles/ICR9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);