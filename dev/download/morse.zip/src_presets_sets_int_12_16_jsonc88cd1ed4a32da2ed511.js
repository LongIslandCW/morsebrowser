"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_int_12_16_json"],{

/***/ "./src/presets/sets/int_12_16.json":
/*!*****************************************!*\
  !*** ./src/presets/sets/int_12_16.json ***!
  \*****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"BC1_Default.json"},{"display":"Default 16/16","filename":"BC1_Random_groups_1-3.json"},{"display":"Random Groups 1-5","filename":"BC1_VST.json"},{"display":"VST","filename":"BC1_Groups_of_5.json"},{"display":"Groups of 5","filename":"BC1_ICR.json"},{"display":"Inter-character Head Copy","filename":"BC1_VET.json"},{"display":"ICR","filename":"BC1_Von_Son.json"},{"display":"VET","filename":"BC1_Von_Soff.json"},{"display":"Instant Word Recognition","filename":"BC1_Phrases_Voff.json"},{"display":"Progressive Word Building","filename":"BC1_Phrases_Von.json"},{"display":"Voice On & Spell On","filename":"Randy_Test.json"},{"display":"Voice On & Spell Off","filename":"Randy_Test.json"}]}');

/***/ })

}]);