"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2167_txt"],{

/***/ "./src/wordfiles/IB2167.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2167.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC GA BOB OP MIKE ANT DIPOLE UP 61 FT <BT> PWR 1W HI HI <BT> HPE CUAGN BOB <BT> PSE RPT INFO <BT> PSE RPT RIG ES ANT <BT> PSE RPT CALL <BT> PWR 1TT W\n";

/***/ })

}]);