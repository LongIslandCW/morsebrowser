"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK8_txt"],{

/***/ "./src/wordfiles/IB228BK8.txt":
/*!************************************!*\
  !*** ./src/wordfiles/IB228BK8.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "W2ITT I2RTF K2UPS K2LCW KC2RTE N2DEE N2GSL N2PPI W2NDG W8KO W2LCW WA2AKV WB2KWC N8KMU WB8KMY WB8WUB WB8FOM KB8ERA AB8TMM AC8LL AB8DU WB8FAR\n";

/***/ })

}]);