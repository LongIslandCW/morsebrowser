"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS4_json"],{

/***/ "./src/wordfiles/IB1PGS4.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1PGS4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"g","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);