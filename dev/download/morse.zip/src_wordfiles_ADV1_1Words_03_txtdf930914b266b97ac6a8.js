"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_03_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_03.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_03.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "beauty {casualty|} \r\n{|beauty casualty} \r\nregulator {lifestyle|} \r\n{|regulator lifestyle} \r\ncandle {testing|} \r\n{|candle testing} \r\ndiversity {faculty|} \r\n{|diversity faculty} \r\nstable {absorb|} \r\n{|stable absorb} \r\nmetaphor {require|} \r\n{|metaphor require} \r\nmedicine {similarity|} \r\n{|medicine similarity} \r\nhonestly {scheme|} \r\n{|honestly scheme} \r\ninvestor {initiate|} \r\n{|investor initiate} \r\nsupplier {innovative|} \r\n{|supplier innovative}";

/***/ })

}]);