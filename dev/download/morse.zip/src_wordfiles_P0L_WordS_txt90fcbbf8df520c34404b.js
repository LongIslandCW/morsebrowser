"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_P0L_WordS_txt"],{

/***/ "./src/wordfiles/P0L_WordS.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/P0L_WordS.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "AAA \r\nAN \r\nAT \r\nAND \r\nALL \r\n\r\nBBB \r\nBE \r\nBY \r\nBUT \r\nBACK \r\n\r\nCCC \r\nCAN \r\nCAR \r\nCAP \r\nCAB \r\n\r\nDDD \r\nDO \r\nDAY \r\nDOT \r\n\r\nEEE \r\nEAR \r\nEAT \r\nEASY \r\nEACH \r\n\r\nFFF \r\nFOR \r\nFER \r\nFIT \r\nFAT \r\n\r\nGGG \r\nGO \r\nGAS \r\nGAP \r\nGOT \r\n\r\nHHH \r\nHE \r\nHER \r\nHIS \r\nHAD \r\n\r\nJJJ \r\nJET \r\nJAR \r\nJAB \r\nJAM \r\n\r\nKKK \r\nKIT \r\nKEG \r\nKEY \r\n \r\nLLL \r\nLET \r\nLAB \r\nLAG \r\nLAP \r\n\r\nMMM \r\nME \r\nMY \r\nMAN \r\nMAP \r\n\r\nNNN \r\nNO \r\nNOW \r\nNEW \r\nNET \r\n\r\nOOO \r\nOR \r\nOUT \r\nONE \r\n\r\nPPP \r\nPAT \r\nPAD \r\nPAN \r\nPAR \r\n\r\nQQQ \r\nQSO \r\nQRL \r\nQRS \r\nQSY \r\n\r\nRRR \r\nRUN \r\nRAN \r\nRAG \r\nRIB \r\n\r\nSSS \r\nSO \r\nSON \r\nSUN \r\nSEE \r\nSET \r\nSAY \r\nSAT \r\n\r\nTTT \r\nTO \r\nTWO \r\nTAG \r\nTAN \r\nTAB \r\n\r\nUUU \r\nUS \r\nUP \r\nUSE \r\n\r\nVVV \r\nVAN \r\nVAT \r\nVET \r\n\r\nWWW \r\nWE \r\nWAY \r\nWHO \r\n\r\nXXX \r\nXYL \r\n\r\nYYY \r\nYES \r\nYET \r\nYEP \r\n\r\nZZZ \r\nZIG \r\nZAG \r\nZEN \r\nZAP \r\n";

/***/ })

}]);