"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Words_45_txt"],{

/***/ "./src/wordfiles/POL_Words_45.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_Words_45.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \r\nARCH \r\nAPPLE \r\nABLE \r\nAMPLE \r\n\r\nBBB \r\nBEND \r\nBLAZE \r\nBOAT \r\nBRAG \r\n\r\n\r\n";

/***/ })

}]);