"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C5_txt"],{

/***/ "./src/wordfiles/SB2C5.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C5.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{W2LCW|w 2 l c w} {DE|from} {W2JSJ|w 2 j s j} OK JOHN SOLID {CPY|copy} \nAGE 58 {YRS|years}\t\nBEEN HAM {FER|for} 30 {YRS|years}\nRETIRED TEACHER\nOK {HW?|how copy} {<AR>|end of message} {W2LCW|w 2 l c w} {DE|from} {W2JSJ|w 2 j s j} {K|invitation to transmit} \n";

/***/ })

}]);