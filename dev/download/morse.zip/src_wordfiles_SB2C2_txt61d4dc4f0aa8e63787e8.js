"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C2_txt"],{

/***/ "./src/wordfiles/SB2C2.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C2.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{<AR>|end of message} {<BT>|pause} {<SK>|end of contact} 599 73 5NN {ABT|about} AGE {AGN|again} AM {ANT|antenna} {B4|before} BEEN {BK|break} BUG {C|celsius} CALL {CFM|confirm} CLEAR {CPI|copy} {CPY|copy} CQ {CU|see you} {CUAGN|see you again} {CUL|see you later} CW {DE|from} DIPOLE {DN|down} {DR|dear} {DX|foreign countries} {EL|element} {ES|and} {FB|fine business} {FER|for} FM {FT|feet} {GA|good afternoon} {GE|good evening} {GM|good morning} {GN|good night} {GND|ground} {GUD|good} HAM HI {HPE|hope} {HR|here} {HW|how} {HW?|how copy} INFO {K|invitation to transmit} OK {OM|old man} {OP|operator} {OT|old timer} {PSE|please} {PWR|power} {QRM|transmission is being interfered with} {QRN|troubled by static} {QRP|decrease power} {QRQ|send faster} {QRS|send slower} {QRT|stop sending} {QRZ|who is calling} {QSB|signals fading} {QSL|acknowledge receipt} {QSO|communicate with} {QSY|change to another frequency} {QTH|location} {R|roger} RAIN RETIRED RFI RIG {RPRT|report} {RPT|report} {RR|roger roger} RST {RX|receiver} {SIG|signal} {SKED|schedule} SOLID {SRI|sorry} SSB SUN {T|zero} {TEMP|temperature} {TKS|thanks} {TNX|thanks} {TU|thank you} {TX|transmitter} {U|you} UP {UR|your} {VERT|vertical} {VY\\very} {W|watts} {WID|with} WIND {WPM|words per minute} {WUD|would} {WX|weather} YAGI {YRS|years}\n";

/***/ })

}]);