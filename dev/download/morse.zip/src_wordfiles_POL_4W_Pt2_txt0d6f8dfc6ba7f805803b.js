"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_4W_Pt2_txt"],{

/***/ "./src/wordfiles/POL_4W_Pt2.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/POL_4W_Pt2.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "AAA \r\nACID \r\nARTS \r\nAXLE \r\nBBB \r\nBENT \r\nBABY \r\nBRAG \r\nCCC \r\nCAKE \r\nCALL \r\nCHIP \r\nDDD \r\nDECK \r\nDOCK \r\nDART \r\nEEE \r\nEAST \r\nEASY \r\nEARN \r\nFFF \r\nFACE \r\nFACT \r\nFAIR \r\nGGG \r\nGAIN \r\nGREW \r\nGALE \r\nHHH \r\nHAZE \r\nHOAX \r\nHERS \r\nIII \r\nICON \r\nIDLY \r\nIRON \r\nJJJ \r\nJOIN \r\nJETS \r\nJAIL \r\nKKK \r\nKIND \r\nKNEW \r\nKEEP \r\nLLL \r\nLACK \r\nLOOP \r\nLEAP \r\nMMM \r\nMILE \r\nMEET \r\nMAZE \r\nNNN \r\nNAIL \r\nNEED \r\nNOOK \r\nOOO \r\nONLY \r\nONCE \r\nOKAY \r\nPPP \r\nPILL \r\nPUFF \r\nPAIR \r\nQQQ \r\nQUIT \r\nQSO \r\nQRL \r\nRRR \r\nRACE \r\nRUST \r\nRAFT \r\nSSS \r\nSCAR \r\nSENT \r\nSALT \r\nTTT \r\nTAKE \r\nTHIS \r\nTHAN \r\nUUU \r\nUSER \r\nUGLY \r\nUPON \r\nVVV \r\nVOLT \r\nVIEW \r\nVIAL \r\nWWW \r\nWILL \r\nWHEN \r\nWALL \r\nXXX \r\nXCVR \r\nXMAS \r\nXBOX \r\nYYY \r\nYAWN \r\nYARN \r\nYOGA \r\nZZZ \r\nZING \r\nZOOS \r\nZANY \r\n";

/***/ })

}]);