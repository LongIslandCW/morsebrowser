"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_LN_json"],{

/***/ "./src/wordfiles/ADV1_LN.json":
/*!************************************!*\
  !*** ./src/wordfiles/ADV1_LN.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);