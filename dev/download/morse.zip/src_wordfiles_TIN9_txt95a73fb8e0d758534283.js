"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN9_txt"],{

/***/ "./src/wordfiles/TIN9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/TIN9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "BUT NEW EAT WET AIR TUNE TUNER TIN WIRE WENT BURN TEN ART WATER TRAIN NUT BAIT RENT\n";

/***/ })

}]);