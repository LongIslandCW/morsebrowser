"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV3_Fam_Phrases_2W4L_txt"],{

/***/ "./src/wordfiles/ADV3_Fam_Phrases_2W4L.txt":
/*!*************************************************!*\
  !*** ./src/wordfiles/ADV3_Fam_Phrases_2W4L.txt ***!
  \*************************************************/
/***/ ((module) => {

module.exports = "NOW TO \r\nNOW TO KILL TWO \r\nNOW TO KILL TWO BIRDS WITH \r\nNOW TO KILL TWO BIRDS WITH ONE STONE \r\n{e|} \r\nLET THE \r\nLET THE CAT OUT \r\nLET THE CAT OUT OF THE \r\nLET THE CAT OUT OF THE PAPER BAG \r\n{e|} \r\nWHO PUT \r\nWHO PUT THE ELEPHANT \r\nWHO PUT THE ELEPHANT IN THE \r\nWHO PUT THE ELEPHANT IN THE DINNING ROOM \r\n{e|} \r\nITS TOO \r\nITS TOO LATE TO \r\nITS TOO LATE TO EAT OUT \r\nITS TOO LATE TO EAT OUT AGAIN TONIGHT \r\n{e|} \r\nNOW GET \r\nNOW GET A TASTE \r\nNOW GET A TASTE OF YOUR \r\nNOW GET A TASTE OF YOUR OWN MEDICINE \r\n{e|} \r\nITS BEEN \r\nITS BEEN A HEAT \r\nITS BEEN A HEAT WAVE THIS \r\nITS BEEN A HEAT WAVE THIS LAST YEAR ";

/***/ })

}]);