"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_POL_json"],{

/***/ "./src/presets/sets/POL.json":
/*!***********************************!*\
  !*** ./src/presets/sets/POL.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"CHARACTERS Flow Rate 1","filename":"POL_27.json"},{"display":"CHARACTERS Flow Rate 2","filename":"POL_31.json"},{"display":"WORDS/PHRASES 2X Flow Rate 1","filename":"POL_3-4L_Words_Long_27.json"},{"display":"WORDS/PHRASES 2X Flow Rate 2","filename":"POL_3-4L_Words_Long_31.json"},{"display":"WORDS/PHRASES 3X Flow Rate 1","filename":"POL_27_WORDS.json"},{"display":"WORDS/PHRASES 3X Flow Rate 2","filename":"POL_31_WORDS.json"},{"display":"3 WORD PHRASES CW-VOICE-CW Flow Rate 1","filename":"POL_3W_Phrases_CVC_27.json"},{"display":"3 WORD PHRASES CW-VOICE-CW Flow Rate 2","filename":"POL_3W_Phrases_CVC_31.json"},{"display":"BINOMIALS Flow Rate 1","filename":"POL_27_BI.json"},{"display":"BINOMIALS Flow Rate 2","filename":"POL_31_BI.json"},{"display":"SENDING ALPHABET Flow Rate 1","filename":"POL_27_SA.json"},{"display":"SENDING ALPHABET Flow Rate 2","filename":"POL_31_SA.json"},{"display":"SENDING NUMBERS Flow Rate 1","filename":"POL_27_SN.json"},{"display":"SENDING NUMBERS Flow Rate 2","filename":"POL_31_SN.json"},{"display":"SENDING WORDS/PHRASES Flow Rate 1","filename":"POL_27_HS.json"},{"display":"SENDING WORDS/PHRASES Flow Rate 2","filename":"POL_31_HS.json"},{"display":"SENTENCES CW-VOICE-CW Flow Rate 1","filename":"POL_SENT_27.json"},{"display":"SENTENCES CW-VOICE-CW Flow Rate 2","filename":"POL_SENT_31.json"},{"display":"SUFFIXES Flow Rate 1","filename":"POL_27_SUF.json"},{"display":"SUFFIXES Flow Rate 2","filename":"POL_31_SUF.json"},{"display":"VOICE AFTER WORDS Flow Rate 1","filename":"POL_27_VA.json"},{"display":"VOICE AFTER WORDS Flow Rate 2","filename":"POL_31_VA.json"}]}');

/***/ })

}]);