"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ZJ4_txt"],{

/***/ "./src/wordfiles/SB2ZJ4.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2ZJ4.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "OP ALAN NICE TO CUAGN BOB\nOP ROB\nRIG TEN TEC ES ANT DIPOLE\nRIG TEN TEC\nNICE RIG\nUR BOAT ANCHOR FB WID GUD SIG  \n";

/***/ })

}]);