"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_1A_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_1A.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_1A.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "\r\nWX2L DE AB5TN \r\nGE ES TNX FER CALL \r\nUR RST 359 359 \r\nQTH DALLAS, TX DALLAS, TX \r\nNAME TOM TOM \r\nOK HW? WX2L DE AB5TN K \r\nAB5TN DE WX2L \r\nGE ES TNX FER RPRT \r\nUR RST 459 45N \r\nQTH ORLANDO, FL ORLANDO, FL \r\nNAME MARISA MARISA \r\nOK HW? AB5TN DE WX2L K \r\n\r\n";

/***/ })

}]);