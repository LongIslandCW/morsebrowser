"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_P_Eval_Words_txt"],{

/***/ "./src/wordfiles/BC2_P_Eval_Words.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC2_P_Eval_Words.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "SOLID TX KEY PWR NICE YAESU ICOM QTH FB JIG ZAP VERT \r\nANT FB DIPOLE CPI GRAZE HW JAKE QRM STN XYL ZIP TU VIC \r\nQRZ YAESU VERTICAL BROWN DIPOLE CFM GUD HW JAKE XYL \r\nWX FORGE VERT BACK CPY XYL JIM QRZ HW AGN UR SOLID \r\nVERTICAL BUG SKED FRESH JOHN METER XYL QRZ WHIP YOU ";

/***/ })

}]);