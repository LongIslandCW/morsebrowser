"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1PGS1_json"],{

/***/ "./src/wordfiles/SB1PGS1.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1PGS1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"pgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);