"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per4_txt"],{

/***/ "./src/wordfiles/per4.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per4.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CQ CQ DE LIWC CLUB INTERVAL TRAMPOLINE CORSAIR <AR> BK\n";

/***/ })

}]);