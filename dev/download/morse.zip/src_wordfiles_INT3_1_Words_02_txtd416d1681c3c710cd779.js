"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Words_02_txt"],{

/***/ "./src/wordfiles/INT3_1 Words_02.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/INT3_1 Words_02.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "threshold {afternoon|} \r\n{|threshold afternoon} \r\nfound {jewelry|} \r\n{|found jewelry} \r\ncolor {claim|} \r\n{|color claim} \r\nenormous {railroad|} \r\n{|enormous railroad} \r\nswitch {offering|} \r\n{|switch offering} \r\nresource {theme|} \r\n{|resource theme} \r\naccuse {prayer|} \r\n{|accuse prayer} \r\nelderly {credit|} \r\n{|elderly credit} \r\ntissue {culture|} \r\n{|tissue culture} \r\nsweater {banana|} \r\n{|sweater banana} ";

/***/ })

}]);