"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Student_Practice_txt"],{

/***/ "./src/wordfiles/Student_Practice.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/Student_Practice.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "r\n";

/***/ })

}]);