"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_4A_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_4A.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_4A.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "OK JERRY TNX FER FB QSO \r\nES HP CUAGN 73 AR \r\nK7YWX DE W6TDP TU SK \r\nOK MIKE TNX FER FB QSO \r\nES HP CUAGN 73 AR ";

/***/ })

}]);