"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/INT2_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/INT2_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "UR \r\nUR RST \r\nUR RST 599 \r\nUR RST 599 5NN \r\n{e|} \r\nRIG \r\nRIG IC7300 \r\nRIG IC7300 ES \r\nRIG IC7300 ES PWR \r\n{e|} \r\nNAME \r\nNAME HERE \r\nNAME HERE RICH \r\nNAME HERE RICH RICH \r\n{e|} \r\nWX \r\nWX IS \r\nWX IS VRY \r\nWX IS VRY NICE \r\n{e|} \r\nVY \r\nVY NICE \r\nVY NICE QSO \r\nVY NICE QSO ON ";

/***/ })

}]);