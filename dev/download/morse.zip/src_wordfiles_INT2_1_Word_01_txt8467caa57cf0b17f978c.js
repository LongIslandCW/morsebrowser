"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_01_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_01.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_01.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "forest {second|} \r\n  {|forest second} \r\nodds {vaccine|} \r\n  {|odds vaccine} \r\nsigh {mouse|} \r\n  {|sigh mouse} \r\nbreath {length|} \r\n  {|breath length} \r\ncool {spouse|} \r\n  {|cool spouse} \r\ncloset {virus|} \r\n  {|closet virus} \r\njunior {subsidy|} \r\n  {|junior subsidy} \r\nbroken {ring|} \r\n  {|broken ring} \r\nbelief {from|} \r\n  {|belief from} \r\nouter {recipe |} \r\n  {|outer recipe } ";

/***/ })

}]);