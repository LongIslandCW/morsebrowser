"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_P_Eval_Sent_txt"],{

/***/ "./src/wordfiles/BC2_P_Eval_Sent.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/BC2_P_Eval_Sent.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "JACK AMAZED A FEW GIRLS BY DROPPING THE ANTIQUE ONYX VASE. \r\nWE PROMPTLY JUDGED ANTIQUE IVORY BUCKLES FOR THE NEXT PRIZE. \r\nJINXED WIZARDS PLUCK IVY FROM THE BIG QUILT. \r\nCRAZY FREDERICKA BOUGHT MANY VERY EXQUISITE OPAL JEWELS. \r\nTHE EXODUS OF JAZZY PIGEONS IS CRAVED BY SQUEAMISH WALKERS. \r\nWHENEVER THE BLACK FOX JUMPED, THE SQUIRREL GAZED SUSPICIOUSLY. \r\nTHE HUGE SPHINX OF BLACK QUARTZ, JUDGE MY VOW NOW. \r\nHOW QUICKLY CAN THE DAFT JUMPING ZEBRAS VEX ME? \r\nHEAVY WHITE BOXES PERFORM QUICK WALTZES AND JIGS FOR ME. ";

/***/ })

}]);