"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Bi_2_txt"],{

/***/ "./src/wordfiles/INT1_Bi_2.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_Bi_2.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "LO AND BEHOLD \r\nSPIT AND POLISH \r\nSTOP AND GO \r\nRAIN OR SHINE \r\nPROS AND CONS \r\nIFS AND BUTS \r\nLOUD AND CLEAR \r\nVERY OR VARY \r\nHOT AND COLD \r\nMAN AND WIFE \r\n";

/***/ })

}]);