"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_INT2_json"],{

/***/ "./src/presets/sets/INT2.json":
/*!************************************!*\
  !*** ./src/presets/sets/INT2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"INT2_DEFAULT_12.json"},{"display":"Default 16/16","filename":"INT2_Default_16.json"},{"display":"Familiarity Phrases","filename":"INT2_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"INT2_FAM_Sentences.json"},{"display":"Familiarity Spelling","filename":"INT2_FAM_Spell.json"},{"display":"Familiarity Words","filename":"INT2_FAM_Words.json"},{"display":"ICR","filename":"INT2_ICR.json"},{"display":"Phrases","filename":"INT2_PHRASES.json"},{"display":"Recognition - Spell","filename":"INT2_REC_Spell.json"},{"display":"Recognition - Words","filename":"INT2_REC_Words.json"},{"display":"Sending Practice","filename":"INT2_SENDING.json"}]}');

/***/ })

}]);