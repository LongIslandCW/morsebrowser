"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_02_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_02.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_02.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "necessarily {darkness|} \r\n{|necessarily darkness} \r\nstriking {facilitate|} \r\n{|striking facilitate} \r\ncriticize {required|} \r\n{|criticize required} \r\ninsurance {currently|} \r\n{|insurance currently} \r\npublicly {optimistic|} \r\n{|publicly optimistic} \r\nconnection {institution|} \r\n{|connection institution} \r\nwherever {practitioner|} \r\n{|wherever practitioner} \r\ncontainer {controversy|} \r\n{|container controversy} \r\nsyndrome {somewhat|} \r\n{|syndrome somewhat} \r\nseriously {experimental|} \r\n{|seriously experimental} ";

/***/ })

}]);