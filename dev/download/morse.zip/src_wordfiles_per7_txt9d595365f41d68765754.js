"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per7_txt"],{

/***/ "./src/wordfiles/per7.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per7.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "QRX 5 QRX 5 STBY PHONE CALL SRI ARBK\n";

/***/ })

}]);