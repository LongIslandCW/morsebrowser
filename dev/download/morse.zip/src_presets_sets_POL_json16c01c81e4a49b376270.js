"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_POL_json"],{

/***/ "./src/presets/sets/POL.json":
/*!***********************************!*\
  !*** ./src/presets/sets/POL.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"CHARACTERS Flow Rate 1","filename":"POL_27.json"},{"display":"WORDS Flow Rate 1","filename":"POL_27_WORDS.json"},{"display":"BINOMIALS Flow Rate 1","filename":"POL_27_BI.json"},{"display":"CHARACTERS Flow Rate 2","filename":"POL_31.json"},{"display":"WORDS Flow Rate 2","filename":"POL_31_WORDS.json"},{"display":"BINOMIALS Flow Rate 2","filename":"POL_31_BI.json"},{"display":"SENDING ALPHABET Flow Rate 1","filename":"POL_27_SA.json"},{"display":"SENDING NUMBERS Flow Rate 1","filename":"POL_27_SN.json"},{"display":"SENDING ALPHABET Flow Rate 2","filename":"POL_31_SA.json"},{"display":"SENDING NUMBERS Flow Rate 2","filename":"POL_31_SN.json"}]}');

/***/ })

}]);