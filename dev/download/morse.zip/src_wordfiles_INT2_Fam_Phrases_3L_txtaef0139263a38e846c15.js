"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_Fam_Phrases_3L_txt"],{

/***/ "./src/wordfiles/INT2_Fam_Phrases_3L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT2_Fam_Phrases_3L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "WE \r\nWE DONT \r\nWE DONT SEE \r\n{e|} \r\nITS \r\nITS FINE \r\nITS FINE JUST \r\n{e|} \r\nONCE \r\nONCE IN \r\nONCE IN A \r\n{e|} \r\nTEN \r\nTEN CENTS \r\nTEN CENTS WONT \r\n{e|} \r\nROLL \r\nROLL OVER \r\nROLL OVER THAT \r\n{e|} \r\nWHEN \r\nWHEN PIGS \r\nWHEN PIGS FLY \r\n{e|} \r\nA \r\nA PIECE \r\nA PIECE OF\r\n{e|} \r\nHE \r\nHE ATE  \r\nHE ATE VERY \r\n{e|} \r\nCALL \r\nCALL IT \r\nCALL IT A ";

/***/ })

}]);