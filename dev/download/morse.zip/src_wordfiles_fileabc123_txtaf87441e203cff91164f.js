"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_fileabc123_txt"],{

/***/ "./src/wordfiles/fileabc123.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/fileabc123.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "it works, time to celebrate";

/***/ })

}]);