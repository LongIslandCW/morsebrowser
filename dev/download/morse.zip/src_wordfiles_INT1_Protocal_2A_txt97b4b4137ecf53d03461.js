"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_2A_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_2A.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_2A.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "OK DELANEY FB ES TNX FER RPRT \r\nRIG FT 857D ES PWR 250W \r\nANT YAGI UP 50 FT \r\nWX RAINING ES TEMP 59F \r\nOK HW? AR N8GQ DE NW9IW K \r\nOK PAUL TNX FER INFO \r\nRIG IC 7100 ES PWR 500W \r\nANT EFHW UP 30 FT \r\nWX CLEAR ES TEMP 43F \r\nOK PAUL HW? AR NW9IW DE N8GQ K ";

/***/ })

}]);