"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_2_Words_txt"],{

/***/ "./src/wordfiles/INT2_2 Words.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/INT2_2 Words.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "package  cheek\r\nfront  citizen\r\nsmile  anger\r\nplease  print\r\nAfrican  subject\r\nnotice  father\r\nscale  medium\r\nlack  slave\r\nsorry  track\r\nvision  similar\r\nthink  remark\r\nsure  dead\r\nsame  succeed\r\ndoor  agenda\r\nteam  twelve\r\nadmit  measure\r\ntend  exist\r\nshould  nose\r\nsimple  away\r\nstuff  acid\r\nafter  mass\r\nmarket  seize\r\nalbum  sharp\r\nhang  shelter\r\nassess  peer\r\nking  weekly\r\nface  sixth\r\nsuffer  bottom\r\nexpose  animal\r\nstop  thick\r\nquick  eight\r\nhome  auto\r\nslip  adviser\r\nbefore  salmon\r\ndress  whole\r\nequally  apple\r\ndepend  AIDS\r\nsound  path\r\nangry  mess\r\nreal  memory\r\ncoach  year\r\nquickly  media\r\nextent  advance\r\nphoto  outside\r\nleading  body\r\nmayor  also\r\ntruck  prime\r\nmajor  supply\r\nlibrary  target\r\nrequest  create\r\nrest  await\r\noccur  hope\r\never  welcome\r\nprofit  cloth\r\ncentral  excited\r\nnurse  cabin\r\nwell  blue\r\nscream  clean\r\nmystery  rapid\r\nmoon  lawsuit\r\njudge  burst\r\nscore  lightly\r\ndecade  hold\r\ngame  porch\r\nheavily  senior\r\naccuse  German\r\nsave  vitamin\r\nearth  sell\r\nlower  execute\r\nsuch  knee\r\nlead  battery\r\nrefer  emerge\r\nbond  suit\r\nlook  welfare\r\neach  lake\r\ndrag  sense\r\nchild  manual\r\nmember  prior\r\npenalty  towel\r\nbear  extreme\r\nentry  exhibit\r\nillness  chicken\r\nspread  shot\r\ndate  bell\r\nyell  proceed\r\nfrozen  fire\r\nretain  studio\r\nEnglish  throat\r\nfight  doll\r\ndirty  minimal\r\nforest  second\r\nodds  vaccine\r\nsigh  mouse\r\nbreath  length\r\ncool  spouse\r\ncloset  virus\r\njunior  subsidy\r\nbroken  ring\r\nbelief  from\r\nouter  recipe \r\n\r\n\r\n";

/***/ })

}]);