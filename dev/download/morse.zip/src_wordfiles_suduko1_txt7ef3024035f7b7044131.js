"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_suduko1_txt"],{

/***/ "./src/wordfiles/suduko1.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/suduko1.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "3  8  5  1  4  6  7  2  9  0\n\n";

/***/ })

}]);