"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_06_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_06.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_06.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "tough {nasty|} \r\n{|tough nasty} \r\nlist {cover|} \r\n{|list cover} \r\nshot {while|} \r\n{|shot while} \r\nsight {tour|} \r\n{|sight tour} \r\nabuse {burst|} \r\n{|abuse burst} \r\ntreat {same|} \r\n{|treat same} \r\ndid {pile|} \r\n{|did pile} \r\njury {loop|} \r\n{|jury loop} \r\nbend {care|} \r\n{|bend care} \r\nearn {sheer|} \r\n{|earn sheer} ";

/***/ })

}]);