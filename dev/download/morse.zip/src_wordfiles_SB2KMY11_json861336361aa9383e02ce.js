"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY11_json"],{

/***/ "./src/wordfiles/SB2KMY11.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB2KMY11.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy4028bkzj/16.<ar><sk><bt>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);