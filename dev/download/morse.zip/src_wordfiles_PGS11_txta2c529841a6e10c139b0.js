"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PGS11_txt"],{

/***/ "./src/wordfiles/PGS11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/PGS11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "PATS AGE  \nANT RPRT  \nGN GREG  \nAGN PSE\nSRI PSE AGN  \nGE PETE  \nRR RST  \nAGE AGN\nSIG RPRT PSE  \nGA PAGE  \nRR RIG  \nRPT RST PSE\nSNAP PEAS  \nSNAG PIES  \nPRINT PENS  \nPARENTS GASP\nPAINT PANS  \nSPIN PETS  \nEAT GRAPES  \nPEN PAGE\nPETER GRINS  \nNATE SANG  \nPATS PAINTS  \nPIRATES RING\n";

/***/ })

}]);