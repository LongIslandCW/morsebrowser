"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2164_txt"],{

/***/ "./src/wordfiles/SB2164.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2164.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC GA BOB OP ALAN ANT DIPOLE UP 61 FT, PWR 1W HI HI, HPE CUAGN BOB, PSE RPT INFO, PSE RPT RIG ES ANT, PSE RPT CALL, PWR 1TT W  \n";

/***/ })

}]);