"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C6_txt"],{

/***/ "./src/wordfiles/SB2C6.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C6.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{W2LCW|w 2 l c w} {DE|from} {WB0JRH|w b 0 j r h} OK RICH {TNX|thanks} {FER|for} {FB|fine business} {QSO|contact} \n{ES|and} {HP|hope} {CUAGN|see you again} 73 {<AR>|end of message} {W2LCW|w 2 l c w} {DE|from} {WB0JRH|w b 0 j r h} {TU|thank you} {<SK>|end of contact} \n";

/***/ })

}]);