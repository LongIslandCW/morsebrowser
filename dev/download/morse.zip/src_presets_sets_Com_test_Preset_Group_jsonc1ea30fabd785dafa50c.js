"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_Com_test_Preset_Group_json"],{

/***/ "./src/presets/sets/Com_test_Preset_Group.json":
/*!*****************************************************!*\
  !*** ./src/presets/sets/Com_test_Preset_Group.json ***!
  \*****************************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"20 wpm","filename":"Com_test_Preset.json"}]}');

/***/ })

}]);