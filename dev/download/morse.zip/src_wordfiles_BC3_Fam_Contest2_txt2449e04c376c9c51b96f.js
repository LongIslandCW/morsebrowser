"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Fam_Contest2_txt"],{

/***/ "./src/wordfiles/BC3_Fam_Contest2.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Fam_Contest2.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "UR {579|5 7 9} \r\nUR {579|5 7 9} {TX|texas} NAME \r\nUR {579|5 7 9} {TX|texas} NAME JOE SKCC {NR|number} {3749|3 7 4 9} \r\n{<BT>|}\r\nUR 5NN AZ \r\nUR 5NN AZ NAME TIM \r\nUR 5NN AZ NAME TIM SKCC {NR|number} {8273|8 2 7 3} \r\n{<BT>|}\r\nN1CC TNX \r\nN1CC TNX {559|5 5 9} BK \r\nN1CC TNX {559|5 5 9} BK TU 73 {AB4TX|A B 4 T X} SOTA \r\n{<BT>|}\r\nQTH {OH|OHIO} \r\nQTH {OH|OHIO} NAME KEN \r\nQTH {OH|OHIO} NAME KEN BK LICW {NR|number} {2791|2 7 9 1} ";

/***/ })

}]);