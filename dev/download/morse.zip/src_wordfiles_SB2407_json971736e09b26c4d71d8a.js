"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2407_json"],{

/***/ "./src/wordfiles/SB2407.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2407.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);