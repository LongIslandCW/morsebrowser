"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR8_txt"],{

/***/ "./src/wordfiles/ICR8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);