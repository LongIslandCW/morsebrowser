"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_1Words_09_txt"],{

/***/ "./src/wordfiles/ADV2_1Words_09.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV2_1Words_09.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "atmosphere {immediately|} \r\n{|atmosphere immediately} \r\nrecipient {withdraw|} \r\n{|recipient withdraw} \r\nvaluable {publication|} \r\n{|valuable publication} \r\nexperience {courtroom|} \r\n{|experience courtroom} \r\ncurrency {magnetic|} \r\n{|currency magnetic} \r\nreceiver {complete|} \r\n{|receiver complete} \r\nhelicopter {disappear|} \r\n{|helicopter disappear} \r\ncharacterize {strategic|} \r\n{|characterize strategic} \r\ntelephone {resident|} \r\n{|telephone resident} \r\nthoroughly {forehead|} \r\n{|thoroughly forehead} ";

/***/ })

}]);