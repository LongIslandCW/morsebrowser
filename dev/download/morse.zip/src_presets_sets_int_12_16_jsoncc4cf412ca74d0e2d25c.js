"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_int_12_16_json"],{

/***/ "./src/presets/sets/int_12_16.json":
/*!*****************************************!*\
  !*** ./src/presets/sets/int_12_16.json ***!
  \*****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"INT_Default_12.json"},{"display":"Default 16/16","filename":"INT_Default_16.json"},{"display":"Random Groups 1-5","filename":"INT_Random_1_5.json"},{"display":"VST","filename":"INT_VST.json"},{"display":"Groups of 5","filename":"INT_Groups_5.json"},{"display":"Inter-character Head Copy","filename":"INT_ICHC.json"},{"display":"ICR","filename":"INT_ICR.json"},{"display":"VET","filename":"INT_VET.json"},{"display":"Instant Word Recognition","filename":"INT_IWR.json"},{"display":"Progressive Word Building","filename":"INT_PWG.json"},{"display":"Voice On & Spell On","filename":"INT_Von_ Son.json"},{"display":"Voice On & Spell Off","filename":"INT_Von_ Soff.json"}]}');

/***/ })

}]);