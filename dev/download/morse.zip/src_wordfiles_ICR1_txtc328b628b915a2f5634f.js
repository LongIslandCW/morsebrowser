"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR1_txt"],{

/***/ "./src/wordfiles/ICR1.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR1.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "E A R I O T N S C L\n";

/***/ })

}]);