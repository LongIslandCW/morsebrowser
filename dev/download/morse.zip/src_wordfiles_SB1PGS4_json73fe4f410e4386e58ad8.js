"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1PGS4_json"],{

/***/ "./src/wordfiles/SB1PGS4.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1PGS4.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"pgstinreauwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);