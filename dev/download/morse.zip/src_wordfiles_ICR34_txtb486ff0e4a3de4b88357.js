"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR34_txt"],{

/***/ "./src/wordfiles/ICR34.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR34.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "a foregone conclusion\na place for everything and everything in its place\nabsolute power corrupts absolutely\ncompassion fatigue\nelementary my dear watson\nforegone conclusion\nforewarned is forearmed\ngeneration x\nincluding, but not limited to\nkeep your nose to the grindstone\npull yourself up by your bootstraps\nthe dow jones industrial average\nit is not surprising that\nthis is all things considered\ndon’t take it personally\nan ounce of prevention is worth a pound of cure\neverything comes to those who wait\nmoderation in all things\nmoney is not everything\npossession is nine tenths of the law\nprevention is better than cure\nthe shoemakers son always goes barefoot\nthere is no accounting for tastes\nyou cant unscramble eggs\ncleanliness is next to godliness\ngrandfather clock\nin an interesting condition\npolitically correct\nbe represented in ascii text\nnot be represented in ascii\ncan not be represented in\nthat cannot be represented\nfamiliarity breeds contempt\nfirst impressions\nopportunity knocks\na sledgehammer to crack a nut\naccidentally on purpose\nbeat swords into ploughshares\nfreezing temperatures\ngenius is 1 percent inspiration and 99 percent perspiration\npomp and circumstance\nprepositional phrases\nthe food and drug administration\nprocrastination is the thief of time\n\n";

/***/ })

}]);