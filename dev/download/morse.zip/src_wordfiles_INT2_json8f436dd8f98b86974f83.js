"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_json"],{

/***/ "./src/wordfiles/INT2.json":
/*!*********************************!*\
  !*** ./src/wordfiles/INT2.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"1234567890","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);