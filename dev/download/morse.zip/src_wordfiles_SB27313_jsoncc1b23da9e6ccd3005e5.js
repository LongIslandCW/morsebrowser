"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB27313_json"],{

/***/ "./src/wordfiles/SB27313.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB27313.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv59,kmy4028bkzj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);