"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C3_txt"],{

/***/ "./src/wordfiles/SB2C3.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C3.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "W2LCW {DE|from} K2UPS {GE|good evening} {ES|and} {TNX|thanks} {FER|for} CALL\t\n{UR|your} RST {599|five nine nine} {5NN|five nine nine} \n{QTH|location} LONG ISLAND, NY LONG ISLAND, NY\nNAME RICH RICH\nOK {HW?|how copy} {<AR>|end of message} W2LCW {DE|from} K2UPS\n";

/***/ })

}]);