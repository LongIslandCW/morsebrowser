"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_P_Eval_Words_txt"],{

/***/ "./src/wordfiles/BC2_P_Eval_Words.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC2_P_Eval_Words.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "SOLID \r\nTX \r\nKEY \r\nPWR \r\nNICE \r\nYAESU \r\nICOM \r\nQTH \r\nFB \r\nJIG \r\nZAP \r\nVERT \r\nANT \r\nFB \r\nDIPOLE \r\nCPI \r\nGRAZE \r\nHW \r\nJAKE \r\nQRM \r\nSTN \r\nXYL \r\nZIP \r\nTU \r\nVIC \r\nQRZ \r\nYAESU \r\nVERTICAL \r\nBROWN \r\nDIPOLE \r\nCFM \r\nYOUR \r\nGUD \r\nHW \r\nJAKE \r\nXYL \r\nWX \r\nFORGE \r\nVERT \r\nBACK \r\nCPY \r\nXYL \r\nJIM \r\nQRZ \r\nHW \r\nAGN \r\nUR \r\nSOLID \r\nVERTICAL \r\nBUG \r\nSKED \r\nFRESH \r\nJOHN \r\nMETER \r\nXYL \r\nQRZ \r\nWHIP \r\nYOU \r\n";

/***/ })

}]);