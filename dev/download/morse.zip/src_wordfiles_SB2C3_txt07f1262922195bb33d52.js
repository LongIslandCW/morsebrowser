"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C3_txt"],{

/***/ "./src/wordfiles/SB2C3.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C3.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{W2LCW|w 2 l c w} {DE|from} {K2UPS|k 2 u p s} {GE|good evening} {ES|and} {TNX|thanks} {FER|for} CALL\t\n{UR|your} {RST|r s t} {599|five nine nine} {5NN|five nine nine} \n{QTH|location} LONG ISLAND, {NY|new york} LONG ISLAND, {NY|new york}\nNAME RICH RICH\nOK {HW?|how copy} {<AR>|end of message} {W2LCW|w 2 l c w} {DE|from} {K2UPS|k 2 u p s}\n";

/***/ })

}]);