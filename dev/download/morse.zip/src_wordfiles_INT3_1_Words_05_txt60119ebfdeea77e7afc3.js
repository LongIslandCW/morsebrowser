"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Words_05_txt"],{

/***/ "./src/wordfiles/INT3_1 Words_05.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/INT3_1 Words_05.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "context {status|} \r\n{|context status} \r\nupset {superior|} \r\n{|upset superior} \r\nfirmly {validity|} \r\n{|firmly validity} \r\nexercise {thick|} \r\n{|exercise thick} \r\nvisible {liquid|} \r\n{|visible liquid} \r\nvacation {shape|} \r\n{|vacation shape} \r\nrocket {behavior|} \r\n{|rocket behavior} \r\nstarter {press|} \r\n{|starter press} \r\nreliable {critic|} \r\n{|reliable critic} \r\ndoorway {stand|} \r\n{|doorway stand} ";

/***/ })

}]);