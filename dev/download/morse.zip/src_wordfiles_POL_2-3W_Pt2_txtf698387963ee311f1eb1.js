"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_2-3W_Pt2_txt"],{

/***/ "./src/wordfiles/POL_2-3W_Pt2.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_2-3W_Pt2.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \nAGE \nASK \nADD \nBBB \nBET \nBOT \nBAT \nCCC \nCAB \nCUL \nCRY \nDDD \nDIP \nDE \nDOT \nEEE \nEAT \nEGO \nEYE \nFFF \nFAT \nFAN \nFLU \nGGG \nGAS \nGAP \nGOT \nHHH \nHIS \nHAD \nHEN \nIII \nICE \nILL \nINK \nJJJ \nJAM \nJOG \nJOY \nKKK \nKEG \nKID \nKIN \nLLL \nLAG \nLEG \nLOT \nMMM \nMAP \nMAY \nMAD \nNNN \nNET \nNAB \nNIP \nOOO \nOUT \nOUR \nONE \nPPP \nPAN \nPAR \nPIE \nQQQ \nQRL \nQRS \nQSY \nRRR \nRIB \nRAW \nRED \nSSS \nSOB \nSUN \nSEE \nTTT \nTAG \nTAN \nTAB \nUUU \nUMP \nUFO \nUSE \nVVV \nVAC \nVEX \nWWW \nWAY \nWHY \nWAS \nXXX \nXYL \nYYY \nYUP \nYUM \nYEP \nZZZ \nZOO \nZAP \nZIP \r\n";

/***/ })

}]);