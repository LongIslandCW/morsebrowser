"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB24014_json"],{

/***/ "./src/wordfiles/SB24014.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB24014.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb4028bkzj/16.<ar><sk><bt>73?qxv59.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);