"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2405_txt"],{

/***/ "./src/wordfiles/IB2405.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2405.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "ANT DIPOLE UP 40 FT <BT> AGE 40 <BT> NICE TO CU AGN ON 40 <BT> NICE SIG ON 40 <BT> AD0WE DE AI4PL <BT> G0POT DE WB0ISG GA MIKE NICE SIG ON 40\n";

/***/ })

}]);