"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Punc__PS_txt"],{

/***/ "./src/wordfiles/Fam_Punc._PS.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/Fam_Punc._PS.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = ". \n{.|} \n{.|} \n{|} \r\n,\n{,|} \n{,|} \n{|} \r\n/ \n{/|} \n{/|} \n{|} \r\n? \n{?|} \n{?|} \n{|} \r\nB K \n{B K|} \n{B K|} \n{|} \r\nAR \n{AR|} \n{AR|} \n{|} \r\nBT \n{BT|} \n{BT|} \n{|} \r\nSK \n{SK|} \n{SK|} \n{|} \r\n. \n{.|} \n{.|} \n{|} \r\n,\r\n{,|} \n{,|} \n{|} \r\n/ \n{/|} \n{/|} \n{|} \r\n? \n{?|} \n{?|} \n{|} \r\nB K \n{B K|} \n{B K|} \n{|} \r\nAR \n{AR|} \n{AR|} \n{|} \r\nBT \n{BT|} \n{BT|} \n{|} \r\nSK \n{SK|} \n{SK|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);