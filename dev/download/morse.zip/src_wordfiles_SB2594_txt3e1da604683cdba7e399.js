"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2594_txt"],{

/***/ "./src/wordfiles/SB2594.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2594.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AB5TN DE N5DR GA TOM <BT> SOLID CPI <BT> UR RST 599 5NN <BT> ATLANTA, GA <BT> ORLANDO, FL <BT> SEATTLE, WA <BT> WASHINGTON, DC <BT> CHICAGO, IL <BT> BOISE, ID <BT> DALLAS, TX <BT> NR SFO, CA <BT> AGE 59 <BT> WIND ES RAIN <BT> RETIRED COP <BT> RETIRED AIRLINE PILOT <BT> RIG KNWD <BT> PWR 5W";

/***/ })

}]);