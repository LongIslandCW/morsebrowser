"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_B1B2_json"],{

/***/ "./src/wordfiles/B1B2.json":
/*!*********************************!*\
  !*** ./src/wordfiles/B1B2.json ***!
  \*********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy59,qxv73?<AR><SK><BT>16.zj/28BK40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);