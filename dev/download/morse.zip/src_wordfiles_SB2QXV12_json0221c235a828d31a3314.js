"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV12_json"],{

/***/ "./src/wordfiles/SB2QXV12.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB2QXV12.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv59,kmy4028bkzj/16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);