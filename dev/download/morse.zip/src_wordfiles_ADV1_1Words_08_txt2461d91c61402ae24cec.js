"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_08_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_08.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_08.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = " action {pioneer|} \r\n{|action pioneer} \r\ntransport {impressive|} \r\n{|transport impressive} \r\nemploy {common|} \r\n{|employ common} \r\ndistract {builder|} \r\n{|distract builder} \r\nlongtime {doorway|} \r\n{|longtime doorway} \r\nrather {peasant|} \r\n{|rather peasant} \r\ngovernor {healthy|} \r\n{|governor healthy} \r\nsurgeon {instead|} \r\n{|surgeon instead} \r\nutility {warmth|} \r\n{|utility warmth} \r\nsettle {gathering|} \r\n{|settle gathering} ";

/***/ })

}]);