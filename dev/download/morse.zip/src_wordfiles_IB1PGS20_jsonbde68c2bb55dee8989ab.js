"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1PGS20_json"],{

/***/ "./src/wordfiles/IB1PGS20.json":
/*!*************************************!*\
  !*** ./src/wordfiles/IB1PGS20.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"sp","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);