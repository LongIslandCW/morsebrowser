"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD11_txt"],{

/***/ "./src/wordfiles/LCD11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/LCD11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "GN LINDI  \nSTN SIGN  \nGL CLINT  \nSPLIT STN \nSIG DIPS  \nPIGS SPIT  \nCLIP PINS \nSPIN DITS  \nSPLIT LIPS  \nPINT LIDS  \nLINDI SINGS\nGIN PINTS  \nCLINT SLID  \nPIG LINT  \nTIN CLIPS\nTIPS CLING  \nITS LINT  \nNIL PICS  \nSPLIT TIPS\nSIT SID  \nSIGN CLIP  \nPICS LIST  \nSIP PINTS\n";

/***/ })

}]);