"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_FAM_KMY_txt"],{

/***/ "./src/wordfiles/BC2_FAM_KMY.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC2_FAM_KMY.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "K \r\nM \r\nY \r\nM \r\nY \r\nK \r\nY \r\nK \r\nM \r\nK \r\nM \r\nY \r\n";

/***/ })

}]);