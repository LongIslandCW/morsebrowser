"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1LCD2_json"],{

/***/ "./src/wordfiles/IB1LCD2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1LCD2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"c","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);