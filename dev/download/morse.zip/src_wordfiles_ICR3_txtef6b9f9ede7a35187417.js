"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR3_txt"],{

/***/ "./src/wordfiles/ICR3.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR3.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A I AT IT NO TO AS SO OR AN ON IN IS\n";

/***/ })

}]);