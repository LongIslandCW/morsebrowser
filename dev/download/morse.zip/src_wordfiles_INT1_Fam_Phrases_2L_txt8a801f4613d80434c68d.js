"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Fam_Phrases_2L_txt"],{

/***/ "./src/wordfiles/INT1_Fam_Phrases_2L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT1_Fam_Phrases_2L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "YOU \r\nYOU WIN \r\n{<BT>|}\r\nVERY \r\nVERY NICE \r\n{<BT>|}\r\nHow \r\nHOW ARE \r\n{<BT>|}\r\nCALL \r\nCALL IT \r\n{<BT>|}\r\nBEST \r\nBEST OF \r\n{<BT>|}\r\nWHY \r\nWHY DONT \r\n{<BT>|}\r\nWE \r\nWE JUST \r\n{<BT>|}\r\nNO \r\nNO PAIN \r\n{<BT>|}\r\nWE \r\nWE DONT \r\n{<BT>|}\r\nEAT \r\nEAT NOW \r\n{<BT>|}\r\nTEN \r\nTEN CENTS \r\n{<BT>|}\r\nGET \r\nGET A \r\n{<BT>|}\r\nROLL \r\nROLL OVER \r\n";

/***/ })

}]);