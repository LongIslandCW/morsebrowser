"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR12_txt"],{

/***/ "./src/wordfiles/ICR12.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR12.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);