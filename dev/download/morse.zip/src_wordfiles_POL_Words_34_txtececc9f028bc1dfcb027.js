"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Words_34_txt"],{

/***/ "./src/wordfiles/POL_Words_34.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_Words_34.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \r\nANT \r\nARCH \r\nAPT \r\nABLE \r\n\r\nBBB \r\nBAT \r\nBOAT \r\nBEND \r\nBUN \r\n\r\n\r\n";

/***/ })

}]);