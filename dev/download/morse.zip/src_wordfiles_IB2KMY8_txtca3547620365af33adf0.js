"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY8_txt"],{

/***/ "./src/wordfiles/IB2KMY8.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2KMY8.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "AL \r\nAK\r\nAR\r\nCA\r\nCO\r\nCT\r\n{DE|delaware}\r\nDC\r\nFL\r\n{GA|georgia} \r\n{HI|hawaii} \r\n{ID|idaho}\r\nIL\r\n{IN|indiana} \r\nIA\r\nKS\r\nKY \r\n{LA|louisiana}\r\n{ME|maine}\r\nMD\r\nMA\r\nMI\r\nMN\r\nMS\r\nMO\r\nMT\r\nNE\r\nNH\r\nNM\r\nNY\r\nNC\r\nND\r\n{OH|ohio} \r\n{OK|oklahoma} \r\nPA\r\nRI\r\nSC\r\nSD\r\nTN\r\nUT\r\nWA\r\nWI\r\nWY\r\n\r\n";

/***/ })

}]);