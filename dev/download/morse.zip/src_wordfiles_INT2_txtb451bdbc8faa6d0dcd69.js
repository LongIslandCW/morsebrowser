"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_txt"],{

/***/ "./src/wordfiles/INT2.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT2.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "1\n2\n3\n4\n5\n6\n7\n8\n9\n0\n";

/***/ })

}]);