"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2405_txt"],{

/***/ "./src/wordfiles/IB2405.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2405.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "ANT DIPOLE UP 4Ø FT\nAGE 4Ø\nNICE TO CU AGN ON 4Ø\nNICE SIG ON 4Ø\nADØWE DE AI4PL\nGØPOT DE WBØISG\n";

/***/ })

}]);