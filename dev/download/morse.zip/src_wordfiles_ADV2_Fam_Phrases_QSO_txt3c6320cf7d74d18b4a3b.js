"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/ADV2_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/ADV2_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "UR RST \r\nUR RST {459|4 5 9} WID \r\nUR RST {459|4 5 9} WID SOME QSB \r\nUR RST {459|4 5 9} WID SOME QSB AND QRN \r\n{<BT>|}\r\nHR NAME \r\nHR NAME HANS QTH \r\nHR NAME HANS QTH BONN {GER|GERMANY} \r\nHR NAME HANS QTH BONN {GER|GERMANY} RIG {IC729|I C 7 2 9} \r\n{<BT>|}\r\nANT IS \r\nANT IS VERT ES \r\nANT IS VERT ES RIG FT101 \r\nANT IS VERT ES RIG FT101 WORKS WELL \r\n{<BT>|}\r\nHR ANT \r\nHR ANT IS LONG \r\nHR ANT IS LONG WIRE ES \r\nHR ANT IS LONG WIRE ES RIG {IC7300|I C 7 3 HUNDRED} \r\n{<BT>|}\r\nWX SNOWING \r\nWX SNOWING ES VY \r\nWX SNOWING ES VY COLD ES \r\nWX SNOWING ES VY COLD ES TEMP 15F \r\n\r\n";

/***/ })

}]);