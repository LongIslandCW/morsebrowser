"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_2-3W_Pt4_txt"],{

/***/ "./src/wordfiles/POL_2-3W_Pt4.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_2-3W_Pt4.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \r\nAGN \r\nAIR \r\nADD \r\nBBB \r\nBUT \r\nBOT \r\nBIT \r\nCCC \r\nCAP \r\nCUL \r\nCUT \r\nDDD \r\nDID \r\nDE \r\nDOT \r\nEEE \r\nEAR \r\nEGO \r\nELM \r\nFFF \r\nFIT \r\nFUN \r\nFIX \r\nGGG \r\nGIN \r\nGAP \r\nGUY \r\nHHH \r\nHER \r\nHAD \r\nHUB \r\nIII \r\nIN \r\nILL \r\nICK \r\nJJJ \r\nJAB \r\nJOG \r\nJUG \r\nKKK \r\nKEY \r\nKIN \r\nKID \r\nLLL \r\nLAW \r\nLOW \r\nLAD \r\nMMM \r\nMAT \r\nMUG \r\nMOM \r\nNNN \r\nNOW \r\nNOT \r\nNAP \r\nOOO \r\nOHM \r\nOFF \r\nODD \r\nPPP \r\nPRY \r\nPUN \r\nPIG \r\nQQQ \r\nQRL \r\nQRY \r\nQRS \r\nRRR \r\nRAG \r\nRAY \r\nRIP \r\nSSS \r\nSKI \r\nSAT \r\nSUM \r\nTTT \r\nTHE \r\nTOP \r\nTRY \r\nTOE \r\nUUU \r\nUSE \r\nUMP \r\nUSE \r\nVVV \r\nVAT \r\nVAC \r\nVEX \r\nWWW \r\nWHO \r\nWAS \r\nWOW \r\nXXX \r\nXYL \r\nYYY \r\nYUM \r\nYUP \r\nYOU \r\nZZZ \r\nZOO \r\nZEN \r\nZIP \r\n";

/***/ })

}]);