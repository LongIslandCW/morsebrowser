"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per10_txt"],{

/***/ "./src/wordfiles/per10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/per10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "VV\n6BH\nSH5\t\n1JB\n6J1\n6BH\nSH5\t\n";

/***/ })

}]);