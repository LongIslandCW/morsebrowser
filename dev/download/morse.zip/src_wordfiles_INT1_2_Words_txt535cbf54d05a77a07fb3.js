"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_2_Words_txt"],{

/***/ "./src/wordfiles/INT1_2 Words.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/INT1_2 Words.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "rate  sorry  {|} \r\nscale  hard  {|} \r\nlean  win  {|} \r\nsheet  minor  {|} \r\nfire  they  {|} \r\nsuch  what  {|} \r\npay  wait  {|} \r\ntheir  dark  {|} \r\nfavor  drum  {|} \r\nyou  lift  {|} \r\nsharp  press  {|} \r\nseem  like  {|} \r\ncore  dam  {|} \r\nten  bless  {|} \r\nlucky  ease  {|} \r\nthis  cast  {|} \r\nblack  labor  {|} \r\nclaim  whale  {|} \r\nfor  above  {|} \r\nburn  sail  {|} \r\nand  prime  {|} \r\nhave  brain  {|} \r\ncold  star  {|} \r\ntie  faint  {|} \r\nyet  mount  {|} \r\nwith  leap  {|} \r\npanel  realm  {|} \r\nhouse  study  {|} \r\nthat  cave  {|} \r\nhis  array  {|} \r\ngoal  unite  {|} \r\nwalk  help  {|} \r\nbag  worth  {|} \r\naware  able  {|} \r\nseat  rifle  {|} \r\ncook  talk  {|} \r\ngirl  strip  {|} \r\ntrip  lack  {|} \r\njudge  alone  {|} \r\nwho  rage  {|} \r\nfully  donor  {|} \r\nshoe  tale  {|} \r\nlive  cross  {|} \r\nskin  porch  {|} \r\nabout  dip  {|} \r\nforce  below  {|} \r\nbill  act  {|} \r\ndiet  grade  {|} \r\nboy  toe  {|} \r\ntool  mark  {|} \r\ntough  nasty  {|} \r\nlist  cover  {|} \r\nshot  while  {|} \r\nsight  tour  {|} \r\nabuse  burst  {|} \r\ntreat  same  {|} \r\ndid  pile  {|} \r\njury  loop  {|} \r\nbend  care  {|} \r\nearn  sheer  {|} \r\nadd  wrong  {|} \r\nhand  build  {|} \r\ndoor  laugh  {|} \r\ntear  the  {|} \r\nscene  store  {|} \r\nadmit  tea  {|} \r\nhelp  loose  {|} \r\ngrant  gang  {|} \r\ndown  hug  {|} \r\nbut  swing  {|} \r\nwrap  use  {|} \r\nwash  cheer  {|} \r\ndate  atop  {|} \r\nfour  brief  {|} \r\nfinal  say  {|} \r\nbeing  cure  {|} \r\ntheme  ours  {|} \r\nlower  game  {|} \r\nshut  key  {|} \r\nlast  lend  {|} \r\noff  lead  {|} \r\nlot  ash  {|} \r\ntip  camp  {|} \r\ntrial  dumb  {|} \r\nlimb  unity  {|} \r\nplead  male  {|} \r\ngiven  rise  {|} \r\ncup  ride  {|} \r\nmask  proud  {|} \r\nreal  thumb  {|} \r\ndrive  chef  {|} \r\nhope  sure  {|} \r\nlogic  equip  {|} \r\nplay  yes  {|} \r\nnovel  only  {|} \r\ntrail  orbit  {|} \r\nsport  fear  {|} \r\nski  taste  {|} \r\nseek  tape  {|} \r\nball  early  {|} \r\n\r\n\r\n";

/***/ })

}]);