"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_SOTA_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_SOTA.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_SOTA.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "{K4LJI|K 4 L J I} GA 599 5NN AR BK  \r{<BT>|} \r\nBK RR UR {259|2 9 9} {259|2 9 9} ON {W6/CC036|W 6 / C C 0 3 6} BK  \r{<BT>|} \r\n{KG7MEX|K G 7 M E X } GM {359|3 5 9} {35N|3 5 9} IL BK  \r{<BT>|} \r\nBK TNX FER S2S 73 DE {N0TMM|N 0 T M M} E E  \r{<BT>|} \r\n{A7BZ|A 7 B Z} GE {579 |5 7 9} {57N |5 7 9} WI IN {K10368|K 1 0 3 6 8}  \r{<BT>|} \r\nAC5BC GA {249|2 4 9} {24N|2 4 9} {TX|texas} PARK?  \r{<BT>|} \r\nUR 599 5NN CO REF?  \r{<BT>|} \r\nBK RR UR 599 5NN ON {W7O/CS157|W 7 O /C S 1 5 7} BK  \r{<BT>|} \r\nKV1G GA {339|3 3 9} {339|3 3 9} MD IN {K1369|K 1 3 6 9}  \r{<BT>|} \r\nBK RR PARK { K10368|K 1 0 3 6 8} { K10368|K 1 0 3 6 8} BK  \r{<BT>|} \r\nP2P DE {AA8DPJ|A A 8 D P J}  \r{<BT>|} \r\nAV0V GA {479|4 7 9} {47N|4 7 9} NV  \r{<BT>|} \r\nUR 599 5NN ON {W0C/FR087|W 0 C / F R 0 8 7} BK  \r{<BT>|} \r\nAK2Z GA 5NN 5NN PA  \r{<BT>|} \r\nN1CC GA {579|5 7 9}  {579|5 7 9}AZ {K1623|K 1 6 2 3}    \r{<BT>|} \r\nBK RR UR {559|5 5 9}  {55N|5 5 9}ON{ W6/CC002|W 6 / C C 0 0 2} BK  \r{<BT>|} \r\nN1RC GA {357|3 5 7} {357|3 5 7} LA  \r{<BT>|} \r\nK2KCC GA 599 5NN NV REF?  \r{<BT>|} \r\nKV1G GA {429|4 2 9} {42N|4 2 9} ON {W2/GC002|W 2 / G C 0 0 2}  \r{<BT>|} \r\nUR {579|5 7 9} {57N|5 7 9} {TX|texas}  \r{<BT>|} \r\n{NG0EV|N G 0 E V} GA {379|3 7 9} {37n|3 7 9} VA PARK?  \r{<BT>|} \r\nS2S DE {WB5GKI|W B 5 G K I}  \r{<BT>|} \r\nWZ0F GE {579|5 7 9} {57N|5 7 9} NC  \r{<BT>|} \r\nN8CT GA {249|2 4 9} {24N|2 4 9} NY IN {K2554|K 2 5 5 4}   \r{<BT>|} \r\nBK RR UR {379|3 7 9} {379|3 7 9} ON {W4T/RV023|W 4 T / R V 0 2 3} BK  \r\r\n\r\r\n ";

/***/ })

}]);