"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ALL_GROUP5_json"],{

/***/ "./src/wordfiles/ALL_GROUP5.json":
/*!***************************************!*\
  !*** ./src/wordfiles/ALL_GROUP5.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890<sk><bt>/,.?<ar><bk>","minWordSize":5,"maxWordSize":5,"practiceSeconds":120}');

/***/ })

}]);