"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_FAM_HOF_txt"],{

/***/ "./src/wordfiles/BC1_FAM_HOF.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC1_FAM_HOF.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "H \r\nO \r\nF \r\nO \r\nF \r\nH \r\nF \r\nH \r\nO \r\nH \r\nO \r\nF \r\n";

/***/ })

}]);