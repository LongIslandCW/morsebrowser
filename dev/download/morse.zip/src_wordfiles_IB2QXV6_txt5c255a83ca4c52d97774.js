"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV6_txt"],{

/***/ "./src/wordfiles/IB2QXV6.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2QXV6.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "ABT AGE AGN ANT BEEN BUG C CALL CLEAR CPI CU CUAGN CUL CW DE DIPOLE DN DR DX EL ES FB FER FT GA GE GN GND GUD HI HPE HR HW INFO OP OT PSE PWR QSO QTH R RAIN RETIRED RFI RIG RPRT RPT RR RST RX SIG SOLID SRI SSB SUN T TKS TNX TU TX U UP UR VERT W WID WIND WUD WX YAGI YRS\n";

/***/ })

}]);