"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/ADV1_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/ADV1_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "W2LCW DE \r\nW2LCW DE K2UPS GE \r\nW2LCW DE K2UPS GE ES TNX \r\nW2LCW DE K2UPS GE ES TNX FER CALL \r\n{e|} \r\nNAME RICH \r\nNAME RICH RICH OK\r\nNAME RICH RICH OK HW? <AR> \r\nNAME RICH RICH OK HW? <AR> AB5TN DE N1CC \r\n{e|} \r\nVY NICE \r\nVY NICE QSO ON \r\nVY NICE QSO ON 17M BOB \r\nVY NICE QSO ON 17M BOB, CUL OM \r\n{e|} \r\nWX IS \r\nWX IS VRY NICE \r\nWX IS VRY NICE ES SUNNY \r\nWX IS VRY NICE ES SUNNY WID A BREEZE \r\n{e|} \r\nAGE 58 \r\nAGE 58 YRS BEEN \r\nAGE 58 YRS BEEN HAM FER \r\nAGE 58 YRS BEEN HAM FER 30 YRS \r\n{e|} \r\n";

/***/ })

}]);