"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK5_txt"],{

/***/ "./src/wordfiles/SB228BK5.txt":
/*!************************************!*\
  !*** ./src/wordfiles/SB228BK5.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "W2ITT I2RTF K2UPS K2LCW KC2RTE N2DEE N2GSL N2PPI W2NDG W8KO W2LCW WA2AKV WB2KWC N8KMU WB8KMY WB8WUB WB8FOM KB8ERA AB8TMM AC8LL AB8DU WB8FAR";

/***/ })

}]);