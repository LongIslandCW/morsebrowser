"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV3_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/ADV3_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/ADV3_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "OP IS \r\nOP IS JOHN ES \r\nOP IS JOHN ES ON HOLIDAY \r\nOP IS JOHN ES ON HOLIDAY IN FRANCE \r\nOP IS JOHN ES ON HOLIDAY IN FRANCE WID XYL \r\n{<BT>|}\r\nRIG IS \r\nRIG IS {IC735|i c 7 3 5} ES \r\nRIG IS {IC735|i c 7 3 5} ES ANT DIPOLE \r\nRIG IS {IC735|i c 7 3 5} ES ANT DIPOLE PWR ABT \r\nRIG IS {IC735|i c 7 3 5} ES ANT DIPOLE PWR ABT 5 {W|watts) {QRP|q r p} \r\n{<BT>|}\r\nQTH LONDON \r\nQTH LONDON WX WARM \r\nQTH LONDON WX WARM ES SUNNY \r\nQTH LONDON WX WARM ES SUNNY PSE QSL \r\nQTH LONDON WX WARM ES SUNNY PSE QSL VIA BURO \r\n{<BT>|}\r\nHR NAME \r\nHR NAME IS ANNE \r\nHR NAME IS ANNE ES QTH \r\nHR NAME IS ANNE ES QTH IS DALLAS \r\nHR NAME IS ANNE ES QTH IS DALLAS {TX|texas} USA ";

/***/ })

}]);