"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_14_Letter_Words_txt"],{

/***/ "./src/wordfiles/14_Letter_Words .txt":
/*!********************************************!*\
  !*** ./src/wordfiles/14_Letter_Words .txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "constitutional \r\ninfrastructure \r\nrecommendation \r\ncharacteristic \r\nrehabilitation \r\nsuperintendent \r\nadministration \r\nidentification \r\ncorrespondence \r\nresponsibility \r\nrepresentative \r\ndisappointment \r\ndiscrimination ";

/***/ })

}]);