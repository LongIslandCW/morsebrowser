"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_suduko1_txt"],{

/***/ "./src/wordfiles/suduko1.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/suduko1.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "3  8  5  1  4  6  7  2  9  0\n4  8  2  3  7  1  5  6  9  0\n2  6  7  3  9  1  5  0  4  8\n6  1  5  0  8  3  4  2  7  9\n1  9  8  3  4  2  6  7  0  5\n1  0  8  4  2  7  9  3  5  6\n8  5  7  3  9  4  2  6  1  0\n5  8  7  3  2  6  1  4  9  0\n7  2  9  3  6  0  4  8  1  5\n5  1  8  4  7  9  2  6  0  3\n";

/***/ })

}]);