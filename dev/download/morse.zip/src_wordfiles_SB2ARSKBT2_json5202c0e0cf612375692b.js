"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ARSKBT2_json"],{

/***/ "./src/wordfiles/SB2ARSKBT2.json":
/*!***************************************!*\
  !*** ./src/wordfiles/SB2ARSKBT2.json ***!
  \***************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"<ar> <sk> <bt>","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);