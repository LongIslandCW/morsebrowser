"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per1_txt"],{

/***/ "./src/wordfiles/per1.txt":
/*!********************************!*\
  !*** ./src/wordfiles/per1.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "TAG\nZIP\nMAY\n";

/***/ })

}]);