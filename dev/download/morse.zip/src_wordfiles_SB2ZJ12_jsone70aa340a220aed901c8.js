"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ZJ12_json"],{

/***/ "./src/wordfiles/SB2ZJ12.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2ZJ12.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbzj/16.<ar><sk><bt>73?qxv59,kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);