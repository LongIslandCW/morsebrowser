"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Words_10_txt"],{

/***/ "./src/wordfiles/INT3_1 Words_10.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/INT3_1 Words_10.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "courage {matter |} \r\n{|courage matter } \r\ntrauma {donor|} \r\n{|trauma donor} \r\nwrong {divorce|} \r\n{|wrong divorce} \r\nsound {meanwhile|} \r\n{|sound meanwhile} \r\nhandful {music|} \r\n{|handful music} \r\ndemocracy {unless|} \r\n{|democracy unless} \r\nshark {later|} \r\n{|shark later} \r\ndrawer {conceive|} \r\n{|drawer conceive} \r\nsharply {probably|} \r\n{|sharply probably} \r\nconscious {label|} \r\n{|conscious label} ";

/***/ })

}]);