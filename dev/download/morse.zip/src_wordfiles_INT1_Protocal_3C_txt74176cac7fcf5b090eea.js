"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Protocal_3C_txt"],{

/***/ "./src/wordfiles/INT1_Protocal_3C.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/INT1_Protocal_3C.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "OK ERVIN GUD CPY \r\nBEEN HAM 4 YRS \r\nAGE HR 20 YRS \r\nWRK AS ENGINEER \r\nOK ERVIN HW? AR N9TA DE W5YO K \r\nOK JANE GUD CPY \r\nBEEN HAM 7 YRS \r\nAGE HR 27 YRS \r\nWRK AS TRUCK DRIVER \r\nOK JANE HW? AR W5YO DE N9TA K ";

/***/ })

}]);