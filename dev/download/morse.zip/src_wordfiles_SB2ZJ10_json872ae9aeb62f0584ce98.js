"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ZJ10_json"],{

/***/ "./src/wordfiles/SB2ZJ10.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2ZJ10.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbzj/16.<ar><sk><bt>73?qxv","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);