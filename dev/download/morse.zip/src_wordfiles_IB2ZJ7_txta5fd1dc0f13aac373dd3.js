"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ7_txt"],{

/***/ "./src/wordfiles/IB2ZJ7.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2ZJ7.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "OP JIM NICE TO CUAGN JOE <BT> OP JOHN <BT> RIG KNWD ES ANT DIPOLE <BT> RIG TEN TEC <BT> NICE RIG <BT> UR BOAT ANCHOR FB WID GUD SIG <BT> WUD LIKE ONE HI HI\n";

/***/ })

}]);