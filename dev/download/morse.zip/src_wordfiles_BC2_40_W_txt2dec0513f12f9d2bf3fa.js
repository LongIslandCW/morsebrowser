"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_40_W_txt"],{

/***/ "./src/wordfiles/BC2_40_W.txt":
/*!************************************!*\
  !*** ./src/wordfiles/BC2_40_W.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "ADD \r\nTOO \r\nBUT \r\nCOW \r\nOLD \r\nFOR \r\nHER \r\nTWO \r\nBIT \r\nFREE \r\nSOON \r\nPOOR \r\nSOFT \r\nWIFE \r\nBALL \r\nFULL \r\nSNOW \r\nPULL \r\nTALL \r\nSTOP \r\nSTEP \r\nTHUS \r\nOPEN \r\nGONE \r\nREAD \r\nBASE \r\nEASE \r\nBIRD \r\nCORN \r\nWING \r\nBAND \r\nFIRE \r\nBEAR \r\nSONG \r\nGUESS \r\nSTART \r\nSLEEP \r\nSPEED \r\nRADIO \r\nGRAND \r\nCAUSE \r\nRANGE \r\nSHALL \r\nOTHER \r\nPAINT \r\nGROUP \r\nROUND \r\nREACH \r\nNIGHT \r\nLAUGH \r\n\r\n";

/***/ })

}]);