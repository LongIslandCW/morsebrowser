"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY12_json"],{

/***/ "./src/wordfiles/SB2KMY12.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB2KMY12.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy4028bkzj/16.<ar><sk><bt>73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);