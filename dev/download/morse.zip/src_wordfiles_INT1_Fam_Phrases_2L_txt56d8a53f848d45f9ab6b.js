"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_Fam_Phrases_2L_txt"],{

/***/ "./src/wordfiles/INT1_Fam_Phrases_2L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/INT1_Fam_Phrases_2L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "YOU \r\nYOU WIN \r\n{e|} \r\nVERY \r\nVERY NICE \r\n{e|} \r\nHow \r\nHOW ARE \r\n{e|} \r\nCALL \r\nCALL IT \r\n{e|} \r\nBEST \r\nBEST OF \r\n{e|} \r\nWHY \r\nWHY DONT \r\n{e|} \r\nWE \r\nWE JUST \r\n{e|} \r\nNO \r\nNO PAIN \r\n{e|} \r\nWE \r\nWE DONT \r\n{e|} \r\nEAT \r\nEAT NOW \r\n{e|} \r\nTEN \r\nTEN CENTS \r\n{e|} \r\nGET \r\nGET A \r\n{e|} \r\nROLL \r\nROLL OVER \r\n";

/***/ })

}]);