"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_02_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_02.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_02.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "entry {exhibit|} \r\n  {|entry exhibit} \r\nillness {chicken|} \r\n  {|illness chicken} \r\nspread {shot|} \r\n  {|spread shot} \r\ndate {bell|} \r\n  {|date bell} \r\nyell {proceed|} \r\n  {|yell proceed} \r\nfrozen {fire|} \r\n  {|frozen fire} \r\nretain {studio|} \r\n  {|retain studio} \r\nEnglish {throat|} \r\n  {|English throat} \r\nfight {doll|} \r\n  {|fight doll} \r\ndirty {minimal|} \r\n  {|dirty minimal} ";

/***/ })

}]);