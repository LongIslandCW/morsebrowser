"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Punc__PS_txt"],{

/***/ "./src/wordfiles/Fam_Punc._PS.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/Fam_Punc._PS.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = ". \r\n{.|} \r\n{.|} \r\n{|} \r\n,\r\n{,|} \r\n{,|} \r\n{|} \r\n/ \r\n{/|} \r\n{/|} \r\n{|} \r\n? \r\n{?|} \r\n{?|} \r\n{|} \r\n{B K|B K} \r\n{B K|} \r\n{B K|} \r\n{|} \r\n{AR|AR} \r\n{AR|} \r\n{AR|} \r\n{|} \r\nBT \r\n{BT|} \r\n{BT|} \r\n{|} \r\nSK \r\n{SK|} \r\n{SK|} \r\n{|} \r\n. \r\n{.|} \r\n{.|} \r\n{|} \r\n,\r\n{,|} \r\n{,|} \r\n{|} \r\n/ \r\n{/|} \r\n{/|} \r\n{|} \r\n? \r\n{?|} \r\n{?|} \r\n{|} \r\n{B K|B K} \r\n{B K|} \r\n{B K|} \r\n{|} \r\n{AR|AR} \r\n{AR|} \r\n{AR|} \r\n{|}\r\nBT \r\n{BT|} \r\n{BT|} \r\n{|} \r\nSK \r\n{SK|} \r\n{SK|} \r\n{|} \r\n\r\n\r\n";

/***/ })

}]);