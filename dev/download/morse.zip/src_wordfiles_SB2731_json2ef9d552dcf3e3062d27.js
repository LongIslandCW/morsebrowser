"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2731_json"],{

/***/ "./src/wordfiles/SB2731.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2731.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);