"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2737_txt"],{

/***/ "./src/wordfiles/IB2737.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2737.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "73 ES HP CUAGN <BT> HW? <BT> AC3D DE N3GE <BT> AGE 37 <BT> ANT DIPOLE UP 73 FT <BT> ANT EFHW UP 37 FT <BT> ANT WIRE IN ATTIC <BT> AGE 73 RETIRED DOCTOR <BT> PSE RPT RIG ES ANT? <BT> OP FLIP <BT> RIG TEN TEC <BT> SOLID SIG HR <BT> COLD ES RAIN 3 C <BT> CUL DR SOCHO";

/***/ })

}]);