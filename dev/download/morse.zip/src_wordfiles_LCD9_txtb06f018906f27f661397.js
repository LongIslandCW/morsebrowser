"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD9_txt"],{

/***/ "./src/wordfiles/LCD9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/LCD9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CPI DN GN GND SIG STN LID GL NIL\n";

/***/ })

}]);