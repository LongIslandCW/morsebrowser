"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT7_txt"],{

/***/ "./src/wordfiles/INT7.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT7.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "some \nthan \nin \nnow \none \nback \nof \nall \nup \njust \nalso \nwhat \nlike \nthen \nme \nits \nmost \nafter \nother \nwould \nuse \nus \nshe \nhave \nan \nhe \nhow \nby \ncould \nhis \nnot \nno \nperson \non \nwork \ngood \nknow \nwhen \nI \nlook \ngo \nday \ncome \nover \nsay \nto \nfor \nabout \nthem \ncan \ninto \nway \nthere \nfrom \nour \nmy \nsee \nany \nbe \nget \nas \nit \nonly \nfirst \nif \nat \na \nthe \nyou \nout \nwill \nwith \nher \nwe \nthink \ntime \nwho \ntheir \nwell \ndo \neven \nor \nbut \nthat \nwhich \ngive \ntwo \nso \nhim \nthis \nyear \nyour \nthese \nwant \nthey \nmake \nand \nnew \nbecause \ntake\n";

/***/ })

}]);