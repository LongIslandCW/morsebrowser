"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_02_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_02.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_02.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "sharp {press|} \r\n{|sharp press} \r\nseem {like|} \r\n{|seem like} \r\ncore {dam|} \r\n{|core dam} \r\nten {bless|} \r\n{|ten bless} \r\nlucky {ease|} \r\n{|lucky ease} \r\nthis {cast|} \r\n{|this cast} \r\nblack {labor|} \r\n{|black labor} \r\nclaim {whale|} \r\n{|claim whale} \r\nfor {above|} \r\n{|for above} \r\nburn {sail|} \r\n{|burn sail} ";

/***/ })

}]);