"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_PREFIX_txt"],{

/***/ "./src/wordfiles/PREFIX.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/PREFIX.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "PRO  PRODUCTS PRODUCT PROGRAM \r\nCON CONTACT CONTROL CONTENT \r\nCOM COMPANY COMMENTS COMMUNITY \r\n";

/***/ })

}]);