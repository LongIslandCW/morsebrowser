"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ZJ2_json"],{

/***/ "./src/wordfiles/SB2ZJ2.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2ZJ2.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"zj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);