"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK7_txt"],{

/***/ "./src/wordfiles/IB228BK7.txt":
/*!************************************!*\
  !*** ./src/wordfiles/IB228BK7.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "OK HOWARD BTU BK \nBK FB RICH AGE 28 RETIRED HI HI BK \nBK FB ES TU FER INFO UR RIG ES ANT DOING FB WID GUD SIG HR BK \nBK ANT EFHW IN ATTIC BK\n";

/***/ })

}]);