"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2738_json"],{

/***/ "./src/wordfiles/SB2738.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2738.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);