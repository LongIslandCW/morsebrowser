"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT12_txt"],{

/***/ "./src/wordfiles/INT12.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/INT12.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "able \nage \nal \nance \nant \nar \nate \nation \ncy \nen \nence \ner \nery \ness \nest \nful \nible \nic \ning \nion \nish \nist \ntion \nive \nless \nly \nment \nness \nor \nous \n\n";

/***/ })

}]);