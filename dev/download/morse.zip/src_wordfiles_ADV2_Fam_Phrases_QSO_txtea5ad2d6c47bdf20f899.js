"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/ADV2_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/ADV2_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "UR RST \r\nUR RST 459 WID \r\nUR RST 459 WID SOME QSB \r\nUR RST 459 WID SOME QSB AND QRN \r\n{e|} \r\nHR NAME \r\nHR NAME HANS QTH \r\nHR NAME HANS QTH BONN GER \r\nHR NAME HANS QTH BONN GER RIG IC729 \r\n{e|} \r\nANT IS \r\nANT IS VERT ES \r\nANT IS VERT ES RIG FT101 \r\nANT IS VERT ES RIG FT101 WORKS WELL \r\n{e|} \r\nHR ANT \r\nHR ANT IS LONG \r\nHR ANT IS LONG WIRE ES \r\nHR ANT IS LONG WIRE ES RIG IC7300 \r\n{e|} \r\nWX SNOWING \r\nWX SNOWING ES VY \r\nWX SNOWING ES VY COLD ES \r\nWX SNOWING ES VY COLD ES TEMP 25F \r\n\r\n";

/***/ })

}]);