"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ICR_json"],{

/***/ "./src/presets/sets/ICR+.json":
/*!************************************!*\
  !*** ./src/presets/sets/ICR+.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Spell 12 wpm","filename":"ICR+_12.json"},{"display":"Words 12 wpm","filename":"Bug_12_Words.json"},{"display":"Spell 16 wpm","filename":"Bug_16.json"},{"display":"Words 16 wpm","filename":"Bug_16_Words.json"},{"display":"Spell 18 wpm","filename":"Bug_18.json"},{"display":"Words 18 wpm","filename":"Bug_18_Words.json"},{"display":"Spell 20 wpm","filename":"Bug_20.json"},{"display":"Words 20 wpm","filename":"Bug_20_Words.json"}]}');

/***/ })

}]);