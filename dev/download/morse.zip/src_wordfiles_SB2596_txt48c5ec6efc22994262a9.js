"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2596_txt"],{

/***/ "./src/wordfiles/SB2596.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2596.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL AR CA CO CT DE FL GA HI ID IL IN IA LA NE NH NC ND OH PA RI SC SD TN UT WA WI";

/***/ })

}]);