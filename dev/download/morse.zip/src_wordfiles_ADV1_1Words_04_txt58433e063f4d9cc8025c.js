"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_1Words_04_txt"],{

/***/ "./src/wordfiles/ADV1_1Words_04.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/ADV1_1Words_04.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "nonprofit {dispute|} \r\n{|nonprofit dispute} \r\nedition {provide|} \r\n{|edition provide} \r\nsuccessful {present|} \r\n{|successful present} \r\nadvocate {prisoner|} \r\n{|advocate prisoner} \r\nsurely {subtle|} \r\n{|surely subtle} \r\nnature {toilet|} \r\n{|nature toilet} \r\nplanning {stimulate|} \r\n{|planning stimulate} \r\nthrough {unique|} \r\n{|through unique} \r\nsocially {reception|} \r\n{|socially reception} \r\npoetry {picture|} \r\n{|poetry picture} ";

/***/ })

}]);