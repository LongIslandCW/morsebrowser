"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT2_1_Word_03_txt"],{

/***/ "./src/wordfiles/INT2_1 Word_03.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT2_1 Word_03.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "lead {battery|} \r\n  {|lead battery} \r\nrefer {emerge|} \r\n  {|refer emerge} \r\nbond {suit|} \r\n  {|bond suit} \r\nlook {welfare|} \r\n  {|look welfare} \r\neach {lake|} \r\n  {|each lake} \r\ndrag {sense|} \r\n  {|drag sense} \r\nchild {manual|} \r\n  {|child manual} \r\nmember {prior|} \r\n  {|member prior} \r\npenalty {towel|} \r\n  {|penalty towel} \r\nbear {extreme|} \r\n  {|bear extreme} ";

/***/ })

}]);