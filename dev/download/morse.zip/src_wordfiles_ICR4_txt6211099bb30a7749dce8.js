"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR4_txt"],{

/***/ "./src/wordfiles/ICR4.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR4.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A I AT IT NO TO AS SO OR AN ON IN IS ANT TOE ONE RAT SAT EAT SIT CAR ACE CAT OAR SET ARE SEE ACT TAN RAN EEL NOR TIN ATE CAN OIL ILL LOT COT NOT TEN LIE ALL ITS\n";

/***/ })

}]);