"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_4W_Pt1_txt"],{

/***/ "./src/wordfiles/POL_4W_Pt1.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/POL_4W_Pt1.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "AAA \r\nALSO \r\nASAP \r\nABLE \r\nBBB \r\nBACK \r\nBUCK \r\nBELT \r\nCCC \r\nCITY \r\nCART \r\nCOME \r\nDDD \r\nDROP \r\nDONE \r\nDAHS \r\nEEE \r\nEVEN \r\nECHO \r\nEACH \r\nFFF \r\nFROM \r\nFOUR \r\nFLAG \r\nGGG \r\nGOOD \r\nGIVE \r\nGRIP \r\nHHH \r\nHELP \r\nHAVE \r\nHILL \r\nIII \r\nINTO \r\nIDOL \r\nIDLE \r\nJJJ \r\nJUMP \r\nJUST \r\nJADE \r\nKKK \r\nKNOW \r\nKICK \r\nKITE \r\nLLL \r\nLIKE \r\nLIST \r\nLOOK \r\nMMM \r\nMOON \r\nMAKE \r\nMOST \r\nNNN \r\nNEST \r\nNONE \r\nNAME \r\nOOO \r\nOVER \r\nOATH \r\nOPEN \r\nPPP \r\nPARK \r\nPAID \r\nPAGE \r\nQQQ \r\nQUAD \r\nQUIP \r\nQUIZ \r\nRRR \r\nROCK \r\nRENT \r\nRAID \r\nSSS \r\nSOME \r\nSEEM \r\nSAFE \r\nTTT \r\nTHEY \r\nTHAT \r\nTIME \r\nUUU \r\nUSED \r\nUNIT \r\nURGE \r\nVVV \r\nVERY \r\nVAIN \r\nVENT \r\nWWW \r\nWITH \r\nWORD \r\nWANT \r\nXXX \r\nXYL \r\nXRAY \r\nXCVR \r\nYYY \r\nYAGI \r\nYEAR \r\nYOUR \r\nZZZ \r\nZONE \r\nZEAL \r\nZULU \r\n";

/***/ })

}]);