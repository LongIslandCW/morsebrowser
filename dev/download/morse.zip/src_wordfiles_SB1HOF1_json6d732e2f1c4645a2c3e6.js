"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1HOF1_json"],{

/***/ "./src/wordfiles/SB1HOF1.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1HOF1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"hof","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);