"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_01_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_01.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_01.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "rate {sorry|} \r\n{|rate sorry} \r\nscale {hard|} \r\n{|scale hard} \r\nlean {win|} \r\n{|lean win} \r\nsheet {minor|} \r\n{|sheet minor} \r\nfire {they|} \r\n{|fire they} \r\nsuch {what|} \r\n{|such what} \r\npay {wait|} \r\n{|pay wait} \r\ntheir {dark|} \r\n{|their dark} \r\nfavor {drum|} \r\n{|favor drum} \r\nyou {lift|} \r\n{|you lift} ";

/***/ })

}]);