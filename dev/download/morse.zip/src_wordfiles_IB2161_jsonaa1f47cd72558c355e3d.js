"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2161_json"],{

/***/ "./src/wordfiles/IB2161.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2161.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"1","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);