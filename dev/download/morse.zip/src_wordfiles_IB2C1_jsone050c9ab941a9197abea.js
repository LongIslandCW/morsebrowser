"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C1_json"],{

/***/ "./src/wordfiles/IB2C1.json":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2C1.json ***!
  \**********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy59,qxv73?<AR><SK><BT>16.zj/28BK40","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);