"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_configs_POL_Random_Sen_1x_CV_27_json"],{

/***/ "./src/presets/configs/POL_Random_Sen_1x_CV_27.json":
/*!**********************************************************!*\
  !*** ./src/presets/configs/POL_Random_Sen_1x_CV_27.json ***!
  \**********************************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"morseSettings":[{"key":"wpm","value":27,"comment":null},{"key":"fwpm","value":27,"comment":null},{"key":"xtraWordSpaceDits","value":"1","comment":null},{"key":"volume","value":"4","comment":null},{"key":"stickySets","value":"BK","comment":null},{"key":"ifStickySets","value":false,"comment":null},{"key":"syncWpm","value":"true","comment":null},{"key":"hideList","value":true,"comment":null},{"key":"showRaw","value":true,"comment":null},{"key":"autoCloseLessonAccordian","value":true,"comment":null},{"key":"customGroup","value":"","comment":null},{"key":"showExpertSettings","value":"true","comment":null},{"key":"voiceEnabled","value":true,"comment":null},{"key":"voiceSpelling","value":false,"comment":null},{"key":"voiceThinkingTime","value":"1.25","comment":null},{"key":"voiceAfterThinkingTime","value":"0","comment":null},{"key":"voiceVolume","value":10,"comment":null},{"key":"voiceLastOnly","value":false,"comment":null},{"key":"voiceRecap","value":false,"comment":null},{"key":"speakFirst","value":false,"comment":null},{"key":"numberOfRepeats","value":0,"comment":null},{"key":"speakFirstAdditionalWordspaces","value":0,"comment":null},{"key":"keepLines","value":true,"comment":null},{"key":"syncSize","value":true,"comment":null},{"key":"overrideSize","value":false,"comment":null},{"key":"overrideSizeMin","value":"2","comment":null},{"key":"overrideSizeMax","value":"2","comment":null},{"key":"cardSpace","value":"2","comment":"AKA cardWait"},{"key":"miscSettingsAccordionOpen","value":"false","comment":null},{"key":"speedInterval","value":false,"comment":null},{"key":"intervalTimingsText","value":"","comment":null},{"key":"intervalWpmText","value":"","comment":null},{"key":"intervalFwpmText","value":"","comment":null},{"key":"voiceBufferMaxLength","value":1,"comment":null},{"key":"isShuffledSet","value":true,"comment":null},{"key":"shuffleIntraGroup","value":false,"comment":null}]}');

/***/ })

}]);