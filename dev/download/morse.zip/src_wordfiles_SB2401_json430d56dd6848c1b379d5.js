"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2401_json"],{

/***/ "./src/wordfiles/SB2401.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2401.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);