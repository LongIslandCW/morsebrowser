"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_per11_txt"],{

/***/ "./src/wordfiles/per11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/per11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "4VV4SH\nJW7Z8Z\nCYHV45\n4VV4SH\n";

/***/ })

}]);