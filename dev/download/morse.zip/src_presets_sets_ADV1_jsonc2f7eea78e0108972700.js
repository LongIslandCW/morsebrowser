"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV1_json"],{

/***/ "./src/presets/sets/ADV1.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 25/25","filename":"ADV1BUF.json"},{"display":"Affixes","filename":"ADV1BUF.json"},{"display":"Familiarity Phrases","filename":"ADV1_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"ADV1_FAM_Sentences.json"},{"display":"Familiarity Spell","filename":"ADV1_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV1_FAM_WORDS.json"},{"display":"ICR","filename":"ADVICR.json"}]}');

/***/ })

}]);