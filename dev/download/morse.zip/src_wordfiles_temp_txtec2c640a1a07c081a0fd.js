"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_temp_txt"],{

/***/ "./src/wordfiles/temp.txt":
/*!********************************!*\
  !*** ./src/wordfiles/temp.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "TKS \r\n{TKS|} \r\n{TKS|} \r\n{TKS|} \r\n{TKS|} \r\n{TKS|} \r\n{TKS|} \r\n{|} ";

/***/ })

}]);