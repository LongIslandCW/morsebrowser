"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Words_34_txt"],{

/***/ "./src/wordfiles/POL_Words_34.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_Words_34.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \r\nALSO \r\nARCH \r\nACID \r\nABLE \r\n\r\nBBB \r\nBRAG \r\nBOAT \r\nBEND \r\nBELT \r\n\r\n\r\n";

/***/ })

}]);