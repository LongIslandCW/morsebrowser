"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2739_txt"],{

/***/ "./src/wordfiles/IB2739.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2739.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL AK AR CA CO CT DE FL GA HI ID IL IN IA KS LA NE NV NH NM NC ND OH PA RI SC SD TN UT WA WI";

/***/ })

}]);