"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_UWB8_txt"],{

/***/ "./src/wordfiles/UWB8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/UWB8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CO \nFL \n{OH|ohio} \n";

/***/ })

}]);