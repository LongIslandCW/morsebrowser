"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_myfile2_txt"],{

/***/ "./src/wordfiles/myfile2.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/myfile2.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "this is the second file";

/***/ })

}]);