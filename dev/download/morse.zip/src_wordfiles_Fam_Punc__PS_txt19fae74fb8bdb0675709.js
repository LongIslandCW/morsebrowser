"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Punc__PS_txt"],{

/***/ "./src/wordfiles/Fam_Punc._PS.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/Fam_Punc._PS.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = ". , / ? B K AR BT SK . , / ? B K AR BT SK ";

/***/ })

}]);