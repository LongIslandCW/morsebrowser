"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_configs_BC1_Von__Son_json"],{

/***/ "./src/presets/configs/BC1_Von_ Son.json":
/*!***********************************************!*\
  !*** ./src/presets/configs/BC1_Von_ Son.json ***!
  \***********************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"morseSettings":[{"key":"wpm","value":"12","comment":null},{"key":"fwpm","value":"8","comment":null},{"key":"ditFrequency","value":600,"comment":null},{"key":"dahFrequency","value":600,"comment":null},{"key":"preSpace","value":"0","comment":null},{"key":"xtraWordSpaceDits","value":"1","comment":null},{"key":"volume","value":"7","comment":null},{"key":"stickySets","value":"BK","comment":null},{"key":"ifStickySets","value":false,"comment":null},{"key":"syncWpm","value":false,"comment":null},{"key":"syncFreq","value":true,"comment":null},{"key":"hideList","value":true,"comment":null},{"key":"showRaw","value":false,"comment":null},{"key":"autoCloseLessonAccordian","value":false,"comment":null},{"key":"cardFontPx","value":"38","comment":null},{"key":"customGroup","value":"","comment":null},{"key":"showExpertSettings","value":"true","comment":null},{"key":"voiceEnabled","value":true,"comment":null},{"key":"voiceSpelling","value":true,"comment":null},{"key":"voiceThinkingTime","value":"0.75","comment":null},{"key":"voiceAfterThinkingTime","value":0,"comment":null},{"key":"voiceVolume","value":10,"comment":null},{"key":"voiceLastOnly","value":false,"comment":null},{"key":"keepLines","value":false,"comment":null},{"key":"syncSize","value":false,"comment":null},{"key":"overrideSize","value":false,"comment":null},{"key":"overrideSizeMin","value":"3","comment":null},{"key":"overrideSizeMax","value":"3","comment":null},{"key":"cardSpace","value":0,"comment":"AKA cardWait"},{"key":"hapticAccordionOpen","value":false,"comment":null},{"key":"miscSettingsAccordionOpen","value":"false","comment":null},{"key":"speedInterval","value":false,"comment":null},{"key":"intervalTimingsText","value":"","comment":null},{"key":"intervalWpmText","value":"","comment":null},{"key":"intervalFwpmText","value":"","comment":null}]}');

/***/ })

}]);