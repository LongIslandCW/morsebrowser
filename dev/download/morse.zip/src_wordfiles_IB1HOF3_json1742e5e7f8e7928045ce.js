"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1HOF3_json"],{

/***/ "./src/wordfiles/IB1HOF3.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1HOF3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"ho","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);