"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_INT1_json"],{

/***/ "./src/presets/sets/INT1.json":
/*!************************************!*\
  !*** ./src/presets/sets/INT1.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"INT1_DEFAULT_12.json"},{"display":"Default 15/12","filename":"INT1_DEFAULT_15.json"},{"display":"Familiarity Phrases","filename":"INT1_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"INT1_FAM_Sentences.json"},{"display":"Familiarity Spelling","filename":"INT1_FAM_Spell.json"},{"display":"Familiarity Words","filename":"INT1_FAM_Words.json"},{"display":"ICR","filename":"INT1_ICR.json"},{"display":"Recognition","filename":"INT1_Recognition.json"},{"display":"Sending Practice","filename":"INT1_SENDING.json"}]}');

/***/ })

}]);