"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LN_json"],{

/***/ "./src/wordfiles/LN.json":
/*!*******************************!*\
  !*** ./src/wordfiles/LN.json ***!
  \*******************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890","minWordSize":1,"maxWordSize":1,"practiceSeconds":120}');

/***/ })

}]);