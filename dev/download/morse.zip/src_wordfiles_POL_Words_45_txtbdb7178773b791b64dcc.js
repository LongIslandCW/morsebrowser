"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Words_45_txt"],{

/***/ "./src/wordfiles/POL_Words_45.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_Words_45.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \r\nANGRY \r\nAPPLE \r\nALARM \r\nAMPLE \r\n\r\nBBB \r\nBREAD \r\nBLAZE \r\nBEACH \r\nBROOM \r\n\r\n\r\n";

/***/ })

}]);