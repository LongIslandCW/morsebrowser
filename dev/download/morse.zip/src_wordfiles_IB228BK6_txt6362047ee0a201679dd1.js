"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK6_txt"],{

/***/ "./src/wordfiles/IB228BK6.txt":
/*!************************************!*\
  !*** ./src/wordfiles/IB228BK6.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "ABT AGE AGN ANT BEEN BK BUG C CALL CLEAR CPI CU CUAGN CUL CW DE DIPOLE DN DR EL ES FB FER FT GA GE GN GND GUD HI HPE HR HW INFO OP OT PSE PWR R RAIN RETIRED RFI RIG RPRT RPT RR RST SIG SOLID SRI SSB SUN T TU U UP UR W WID WIND WUD  \n";

/***/ })

}]);