"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C2_txt"],{

/***/ "./src/wordfiles/SB2C2.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C2.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{<AR>|end of message} \n{<BT>|pause} \n{<SK>|end of contact} \n{599|five nine nine} \n73 \n{5NN|five nine nine} \n{ABT|about} \nAGE \n{AGN|again} \nAM \n{ANT|antenna} \n{B4|before} \nBEEN \n{BK|break} \nBUG \n{C|celsius} \nCALL \n{CFM|confirm} \nCLEAR \n{CPI|copy} \n{CPY|copy} \nCQ \n{CU|see you} \n{CUAGN|see you again} \n{CUL|see you later} \nCW \n{DE|from} \nDIPOLE \n{DN|down} \n{DR|dear} \n{DX|foreign countries} \n{EL|element} \n{ES|and} \n{F|fahrenheit}\n{FB|fine business} \n{FER|for} \nFM \n{FT|feet} \n{GA|good afternoon} \n{GE|good evening} \n{GM|good morning} \n{GN|good night} \n{GND|ground} \n{GUD|good} \nHAM \n{HI|laugh} \n{HP|hope} \n{HPE|hope} \n{HR|here} \n{HW|how} \n{HW?|how copy} \nINFO \n{K|invitation to transmit} \n{OK|O K} \n{OM|old man} \n{OP|operator} \n{OT|old timer} \n{PSE|please} \n{PWR|power} \n{QRM|transmission is being interfered with} \n{QRN|troubled by static} \n{QRP|decrease power} \n{QRQ|send faster} \n{QRS|send slower} \n{QRT|stop sending} \n{QRZ|who is calling} \n{QSB|signals fading} \n{QSL|acknowledge receipt} \n{QSO|communicate with} \n{QSY|change to another frequency} \n{QTH|location} \n{R|roger} \nRAIN \nRETIRED \nRFI \nRIG \n{RPRT|report} \n{RPT|report} \n{RR|roger roger} \nRST \n{RX|receiver} \n{SIG|signal} \n{SKED|schedule} \nSOLID \n{SRI|sorry} \nSSB \nSUN \n{T|zero} \n{TEMP|temperature} \n{TKS|thanks} \n{TNX|thanks} \n{TU|thank you} \n{TX|transmitter} \n{U|you} \nUP \n{UR|your} \n{VERT|vertical} \n{VY\\very} \n{W|watts} \n{WID|with} \nWIND \n{WPM|words per minute} \n{WUD|would} \n{WX|weather} \nYAGI \n{YRS|years}\n";

/***/ })

}]);