"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV8_json"],{

/***/ "./src/wordfiles/SB2QXV8.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2QXV8.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbqxv59,kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);