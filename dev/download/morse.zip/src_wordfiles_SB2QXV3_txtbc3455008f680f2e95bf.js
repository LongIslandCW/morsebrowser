"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV3_txt"],{

/***/ "./src/wordfiles/SB2QXV3.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2QXV3.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "ABT AGE AGN ANT BEEN BUG C CALL CLEAR CPI CU CUAGN CUL CW DE DIPOLE DN DR DX EL ES FB FER FT GA GE GN GND GUD HI HPE HR HW INFO OP OT PSE PWR QRN QRP QRQ QRS QRT QSB QSL QSO QTH R RAIN RETIRED RFI RIG RPRT RPT RR RST RX SIG SOLID SRI SSB SUN T TNX TU TX U UP UR VERT W WID WIND WUD WX  \n";

/***/ })

}]);