"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1HOF6_json"],{

/***/ "./src/wordfiles/IB1HOF6.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1HOF6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"lcdpgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);