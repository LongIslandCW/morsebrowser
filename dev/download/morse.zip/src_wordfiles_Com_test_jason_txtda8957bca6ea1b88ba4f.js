"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Com_test_jason_txt"],{

/***/ "./src/wordfiles/Com_test.jason.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/Com_test.jason.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "{\r\n     \"letters\": \"abcdefghijklmnopqrstuvwxyz1234567890 <sk> <bt> / , . ? <ar> <bk> \",\r\n     \"minWordSize\": 5,\r\n     \"maxWordSize\": 5,\r\n     \"practiceSeconds\" : 120\r\n\r\n }";

/***/ })

}]);