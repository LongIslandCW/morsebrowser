"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_COM_json"],{

/***/ "./src/presets/sets/COM.json":
/*!***********************************!*\
  !*** ./src/presets/sets/COM.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"18/16 wpm","filename":"COM_1816.json"},{"display":"20/16 wpm","filename":"COM_2016.json"},{"display":"22/16 wpm","filename":"COM_2216.json"},{"display":"25/16 wpm","filename":"COM_2516.json"},{"display":"30/16 wpm","filename":"COM_3016.json"}]}');

/***/ })

}]);