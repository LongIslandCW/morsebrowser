"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_configs_ADV1_FAM_Phrases_json"],{

/***/ "./src/presets/configs/ADV1_FAM_Phrases.json":
/*!***************************************************!*\
  !*** ./src/presets/configs/ADV1_FAM_Phrases.json ***!
  \***************************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"morseSettings":[{"key":"wpm","value":28,"comment":null},{"key":"fwpm","value":28,"comment":null},{"key":"xtraWordSpaceDits","value":"1","comment":null},{"key":"volume","value":"4","comment":null},{"key":"stickySets","value":"BK","comment":null},{"key":"ifStickySets","value":false,"comment":null},{"key":"syncWpm","value":true,"comment":null},{"key":"hideList","value":true,"comment":null},{"key":"showRaw","value":false,"comment":null},{"key":"autoCloseLessonAccordian","value":false,"comment":null},{"key":"customGroup","value":"","comment":null},{"key":"showExpertSettings","value":"true","comment":null},{"key":"voiceEnabled","value":true,"comment":null},{"key":"voiceSpelling","value":false,"comment":null},{"key":"voiceThinkingTime","value":"0.5","comment":null},{"key":"voiceAfterThinkingTime","value":"0.5","comment":null},{"key":"voiceVolume","value":10,"comment":null},{"key":"voiceLastOnly","value":false,"comment":null},{"key":"voiceRecap","value":false,"comment":null},{"key":"speakFirst","value":true,"comment":null},{"key":"speakFirstRepeats","value":2,"comment":null},{"key":"speakFirstAdditionalWordspaces","value":2,"comment":null},{"key":"keepLines","value":true,"comment":null},{"key":"syncSize","value":false,"comment":null},{"key":"overrideSize","value":true,"comment":null},{"key":"overrideSizeMin","value":"1","comment":null},{"key":"overrideSizeMax","value":"1","comment":null},{"key":"cardSpace","value":0,"comment":"AKA cardWait"},{"key":"miscSettingsAccordionOpen","value":"true","comment":null},{"key":"speedInterval","value":false,"comment":null},{"key":"intervalTimingsText","value":"","comment":null},{"key":"intervalWpmText","value":"","comment":null},{"key":"intervalFwpmText","value":"","comment":null},{"key":"voiceBufferMaxLength","value":1,"comment":null}]}');

/***/ })

}]);