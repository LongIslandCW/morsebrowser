"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_2-3W_Pt1_txt"],{

/***/ "./src/wordfiles/POL_2-3W_Pt1.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/POL_2-3W_Pt1.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "AAA \nAN \nAT \nAS \nBBB \nBE \nBY \nBUT \nCCC \nCAN \nCAR \nCAP \nDDD \nDO \nDAY \nDID \nEEE \nES \nEX \nEAR \nFFF \nFOR \nFER \nFIT \nGGG \nGO \nGET \nGIN \nHHH \nHE \nHER \nHIM \nIII \nIF \nIT \nIN \nJJJ \nJET \nJAR \nJAB \nKKK \nKIT \nKEG \nKEY \nLLL \nLET \nLAB \nLAW \nMMM \nME \nMY \nMAN \nNNN \nNO \nNOW \nNEW \nOOO \nOR \nON \nOF \nPPP \nPAT \nPET \nPAD \nQQQ \nQSO \nQRL \nQRS \nRRR \nRUN \nRAN \nRAG \nSSS \nSO \nSON \nSKI \nTTT \nTHE \nTO \nTWO \nUUU \nUS \nUP \nUMP \nVVV \nVAN \nVAT \nVET \nWWW \nWE \nWHO \nWEB \nXXX \nXYL \nYYY \nYES \nYET \nYOU \nZZZ \nZIG \nZAG \nZEN \n\r\n";

/***/ })

}]);