"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2164_txt"],{

/***/ "./src/wordfiles/SB2164.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2164.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC GA BOB OP MIKE ANT DIPOLE UP 61 FT <BT> PWR 1W HI HI <BT> HPE CUAGN BOB <BT> PSE RPT INFO <BT> PSE RPT RIG ES ANT <BT> PSE RPT CALL <BT> PWR 1TT W";

/***/ })

}]);