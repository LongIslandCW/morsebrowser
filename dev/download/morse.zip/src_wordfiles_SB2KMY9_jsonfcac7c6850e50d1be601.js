"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY9_json"],{

/***/ "./src/wordfiles/SB2KMY9.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2KMY9.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy4028bkzj/","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);