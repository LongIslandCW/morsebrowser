"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_FAM_UWB_txt"],{

/***/ "./src/wordfiles/BC1_FAM_UWB.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/BC1_FAM_UWB.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "U \r\nW \r\nB \r\nW \r\nB \r\nU \r\nB \r\nU \r\nW \r\nU \r\nW \r\nB \r\n";

/***/ })

}]);