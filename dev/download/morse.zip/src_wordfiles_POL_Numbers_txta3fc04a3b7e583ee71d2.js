"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Numbers_txt"],{

/***/ "./src/wordfiles/POL_Numbers.txt":
/*!***************************************!*\
  !*** ./src/wordfiles/POL_Numbers.txt ***!
  \***************************************/
/***/ ((module) => {

module.exports = "111 \r\n222 \r\n333 \r\n444 \r\n555 \r\n666 \r\n777 \r\n888 \r\n999 \r\n000 ";

/***/ })

}]);