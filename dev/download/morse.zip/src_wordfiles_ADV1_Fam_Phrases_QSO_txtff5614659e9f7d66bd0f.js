"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/ADV1_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/ADV1_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "{W2LCW|w 2 l c w} DE \r\n{W2LCW|w 2 l c w} DE {K2UPS|k 2 u p s} GE \r\n{W2LCW|w 2 l c w} DE {K2UPS|k 2 u p s} GE ES TNX \r\n{W2LCW|w 2 l c w} DE {K2UPS|k 2 u p s} GE ES TNX FER CALL \r\n{<BT>|}\r\nNAME MIKE \r\nNAME MIKE MIKE OK\r\nNAME MIKE MIKE OK HW? <AR> \r\nNAME MIKE MIKE OK HW? <AR> {AB5TN|a b 5 t n} DE {N1CC|n 1 c c} \r\n{<BT>|}\r\nVY NICE \r\nVY NICE QSO ON \r\nVY NICE QSO ON 17M BOB \r\nVY NICE QSO ON 17M BOB, CUL OM \r\n{<BT>|}\r\nWX IS \r\nWX IS VRY NICE \r\nWX IS VRY NICE ES SUNNY \r\nWX IS VRY NICE ES SUNNY WID A BREEZE \r\n{<BT>|}\r\nAGE 58 \r\nAGE 58 YRS BEEN \r\nAGE 58 YRS BEEN HAM FER \r\nAGE 58 YRS BEEN HAM FER 30 YRS \r\n{<BT>|}\r\n";

/***/ })

}]);