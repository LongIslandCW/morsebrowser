"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_bc1_json"],{

/***/ "./src/presets/sets/bc1.json":
/*!***********************************!*\
  !*** ./src/presets/sets/bc1.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/8","filename":"BC1_Default.json"},{"display":"Random groups 1-3","filename":"BC1_Random_groups_1-3.json"},{"display":"VST","filename":"BC1_VST.json"},{"display":"Groups of 5","filename":"BC1_Groups_of_5.json"},{"display":"ICR","filename":"BC1_ICR.json"},{"display":"VET","filename":"BC1_VET.json"},{"display":"Voice On & Spell On","filename":"BC1_Von_Son.json"},{"display":"Voice On &Spell Off","filename":"BC1_Von_Soff.json"},{"display":"Phrases – Voice Off","filename":"BC1_Phrases_Voff.json"},{"display":"Phrases – Voice On","filename":"BC1_Phrases_Von.json"},{"display":"Randy Test","filename":"Randy_Test.json"}]}');

/***/ })

}]);