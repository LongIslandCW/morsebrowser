"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_N_json"],{

/***/ "./src/wordfiles/ADV1_N.json":
/*!***********************************!*\
  !*** ./src/wordfiles/ADV1_N.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"1234567890","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);