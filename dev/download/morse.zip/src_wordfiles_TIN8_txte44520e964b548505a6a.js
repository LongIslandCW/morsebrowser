"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN8_txt"],{

/***/ "./src/wordfiles/TIN8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/TIN8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AR \n{IN|indiana} \nIA \nNE \nRI \nTN \nUT \nWA \nWI \n";

/***/ })

}]);