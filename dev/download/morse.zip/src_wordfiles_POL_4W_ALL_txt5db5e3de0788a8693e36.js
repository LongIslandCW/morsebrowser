"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_4W_ALL_txt"],{

/***/ "./src/wordfiles/POL_4W_ALL.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/POL_4W_ALL.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "AAA \r\nALSO \r\nASAP \r\nABLE \r\nACID \r\nARTS \r\nAXLE \r\nAIRY \r\nBBB \r\nBACK \r\nBUCK \r\nBELT \r\nBENT \r\nBABY \r\nBRAG \r\nBOAT \r\nBEND \r\nCCC \r\nCITY \r\nCART \r\nCOME \r\nCAGE \r\nCAFE \r\nCAKE \r\nCALL \r\nCHIP \r\nDDD \r\nDROP \r\nDONE \r\nDAHS \r\nDAFT \r\nDOZE \r\nDECK \r\nDOCK \r\nDART \r\nEEE \r\nEVEN \r\nECHO \r\nEACH \r\nEAST \r\nEASY \r\nEARN \r\nFFF \r\nFROM \r\nFOUR \r\nFLAG \r\nFACE \r\nFACT \r\nFAIR \r\nFALL \r\nFLIP \r\nFROG \r\nGGG \r\nGOOD \r\nGIVE \r\nGRIP \r\nGAIN \r\nGREW \r\nGALE \r\nGOLF \r\nGOLD \r\nGATE \r\nHHH \r\nHELP \r\nHAVE \r\nHILL \r\nHAZE \r\nHOAX \r\nHERS \r\nHAWK \r\nHERO \r\nHUNT \r\nHARP \r\nIII \r\nINTO \r\nIDOL \r\nIDLE \r\nICON \r\nIDLY \r\nIRON \r\nIDEA \r\nJJJ \r\nJUMP \r\nJUST \r\nJADE \r\nJOIN \r\nJETS \r\nJAIL \r\nJEST \r\nKKK \r\nKNOW \r\nKICK \r\nKITE \r\nKIND \r\nKNEW \r\nKEEP \r\nKINK \r\nKNOB \r\nLLL \r\nLIKE \r\nLIST \r\nLOOK \r\nLACK \r\nLOOP \r\nLEAP \r\nLEFT \r\nLADY \r\nLAZY \r\nLEAF \r\nMMM \r\nMOON \r\nMAKE \r\nMOST \r\nMILE \r\nMEET \r\nMAZE \r\nMEMO \r\nMANY \r\nMADE \r\nNNN \r\nNEST \r\nNONE \r\nNAME \r\nNAIL \r\nNEED \r\nNOOK \r\nNICE \r\nNEAT \r\nNECK \r\nNOTE \r\nOOO \r\nOVER \r\nOATH \r\nOPEN \r\nONLY \r\nONCE \r\nOKAY \r\nOVEN \r\nOBEY \r\nOOZE \r\n0VAL \r\nOMEN \r\nPPP \r\nPARK \r\nPAID \r\nPAGE \r\nPILL \r\nPUFF \r\nPAIR \r\nPICK \r\nPAIL \r\nPINT \r\nPACK \r\nQQQ \r\nQUAD \r\nQUIP \r\nQUIZ \r\nQUIT \r\nQSO \r\nQRL \r\nQRS \r\nQSY \r\nRRR \r\nROCK \r\nRENT \r\nRAID \r\nRACE \r\nRUST \r\nRAFT \r\nROAD \r\nRAIN \r\nRIDE \r\nRAKE \r\nSSS \r\nSOME \r\nSEEM \r\nSAFE \r\nSCAR \r\nSENT \r\nSALT \r\nSAIL \r\nSING \r\nSAID \r\nSNAP \r\nSING \r\nTTT \r\nTHEY \r\nTHAT \r\nTIME \r\nTAKE \r\nTHIS \r\nTHAN \r\nTHEN \r\nTHEM \r\nTELL \r\nTURN \r\nTRIP \r\nTILT \r\nUUU \r\nUSED \r\nUNIT \r\nURGE \r\nUSER \r\nUGLY \r\nUPON \r\nUNDO \r\nVVV \r\nVERY \r\nVAIN \r\nVENT \r\nVOLT \r\nVIEW \r\nVIAL \r\nVOTE \r\nVAIN \r\nVAST \r\nWWW \r\nWITH \r\nWORD \r\nWANT \r\nWILL \r\nWHEN \r\nWALL \r\nWAGE \r\nWORK \r\nWELL \r\nWINK \r\nWARP \r\nXXX \r\nXYL \r\nXRAY \r\nXCVR \r\nXMAS \r\nXBOX \r\nYYY \r\nYAGI \r\nYEAR \r\nYOUR \r\nYAWN \r\nYARN \r\nYOGA \r\nYELL \r\nZZZ \r\nZONE \r\nZEAL \r\nZULU \r\nZING \r\nZOOS \r\nZANY \r\nZIPS \r\nZEST \r\nZOOM \r\nZINC \r\nZONE \r\n";

/***/ })

}]);