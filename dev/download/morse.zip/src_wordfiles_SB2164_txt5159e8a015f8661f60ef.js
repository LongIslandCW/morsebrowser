"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2164_txt"],{

/***/ "./src/wordfiles/SB2164.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2164.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC GA BOB OP ALAN ANT DIPOLE UP 61 FT\nPWR 1W HI HI\nHPE CUAGN BOB\nPSE RPT INFO\nPSE RPT RIG ES ANT\nPSE RPT CALL\nPWR 1TT W  \n";

/***/ })

}]);