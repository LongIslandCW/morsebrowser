"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD8_txt"],{

/***/ "./src/wordfiles/LCD8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/LCD8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CT ID IL IN NC ND SC SD TN\n";

/***/ })

}]);