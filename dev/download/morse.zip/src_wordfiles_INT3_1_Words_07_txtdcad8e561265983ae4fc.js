"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_1_Words_07_txt"],{

/***/ "./src/wordfiles/INT3_1 Words_07.txt":
/*!*******************************************!*\
  !*** ./src/wordfiles/INT3_1 Words_07.txt ***!
  \*******************************************/
/***/ ((module) => {

module.exports = "detailed {faster|} \r\n{|detailed faster} \r\nalready {exhibit|} \r\n{|already exhibit} \r\nactual {recruit|} \r\n{|actual recruit} \r\nSenate {answer|} \r\n{|Senate answer} \r\nscary {their|} \r\n{|scary their} \r\ncorrectly {theology|} \r\n{|correctly theology} \r\nterror {therapist|} \r\n{|terror therapist} \r\nsandwich {minority|} \r\n{|sandwich minority} \r\ntrick {powder|} \r\n{|trick powder} \r\nFrench {suffering|} \r\n{|French suffering} ";

/***/ })

}]);