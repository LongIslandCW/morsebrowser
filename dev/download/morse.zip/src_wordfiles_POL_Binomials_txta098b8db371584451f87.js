"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_POL_Binomials_txt"],{

/***/ "./src/wordfiles/POL_Binomials.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/POL_Binomials.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "AAA \r\nALIVE AND WELL \r\nABOVE AND BEYOND \r\nAPPLES AND ORANGES \r\n\r\nBBB \r\nBACK AND FORTH \r\nBREAD AND BUTTER \r\nBITS AND PIECES \r\n";

/***/ })

}]);