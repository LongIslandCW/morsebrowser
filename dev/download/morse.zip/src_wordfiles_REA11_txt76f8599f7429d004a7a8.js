"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_REA11_txt"],{

/***/ "./src/wordfiles/REA11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/REA11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "RR FB\nHW {R|r} U\nHR ROB\nFB OB\nHW\nFER WHO\nUR HERE\nHW ARE U\nHEAR BOB\nWEAR ROBE\nBARE BEAR\nBREW BEER\nWORE FUR\nFEAR WAR\nOWE ROB\nEURO FARE\nHEAR HERB\nFOR WHO\nFAR WHARF\nEAR FUR\n";

/***/ })

}]);