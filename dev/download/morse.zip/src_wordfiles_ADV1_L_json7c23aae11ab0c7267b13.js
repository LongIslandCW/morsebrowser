"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV1_L_json"],{

/***/ "./src/wordfiles/ADV1_L.json":
/*!***********************************!*\
  !*** ./src/wordfiles/ADV1_L.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);