"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_1_Word_04_txt"],{

/***/ "./src/wordfiles/INT1_1 Word_04.txt":
/*!******************************************!*\
  !*** ./src/wordfiles/INT1_1 Word_04.txt ***!
  \******************************************/
/***/ ((module) => {

module.exports = "goal {unite|} \r\n{|goal unite} \r\nwalk {hell|} \r\n{|walk hell} \r\nbag {worth|} \r\n{|bag worth} \r\naware {able|} \r\n{|aware able} \r\nseat {rifle|} \r\n{|seat rifle} \r\ncook {talk|} \r\n{|cook talk} \r\ngirl {strip|} \r\n{|girl strip} \r\ntrip {lack|} \r\n{|trip lack} \r\njudge {alone|} \r\n{|judge alone} \r\nwho {rage|} \r\n{|who rage} ";

/***/ })

}]);