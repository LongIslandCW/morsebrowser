"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Com_All_json"],{

/***/ "./src/wordfiles/Com_All.json":
/*!************************************!*\
  !*** ./src/wordfiles/Com_All.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz1234567890<sk><bt>/,.?<ar><bk>","minWordSize":5,"maxWordSize":5,"practiceSeconds":120}');

/***/ })

}]);