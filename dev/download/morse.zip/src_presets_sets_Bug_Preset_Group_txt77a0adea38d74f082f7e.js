"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_Bug_Preset_Group_txt"],{

/***/ "./src/presets/sets/Bug Preset Group.txt":
/*!***********************************************!*\
  !*** ./src/presets/sets/Bug Preset Group.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "{\r\n    \"options\": [\r\n        {\r\n            \"display\": \"Spell 12 wpm\",\r\n            \"filename\": \"Bug_12.json\"\r\n        },\r\n        {\r\n            \"display\": \"Words 12 wpm\",\r\n            \"filename\": \"Bug_12_Words.json\"\r\n        },\r\n               {\r\n            \"display\": \"Spell 16 wpm\",\r\n            \"filename\": \"Bug_16.json\"\r\n        },\r\n        {\r\n            \"display\": \"Words 12 wpm\",\r\n            \"filename\": \"Bug_12_Words.json\"\r\n        },\r\n        {\r\n            \"display\": \"Spell 18 wpm\",\r\n            \"filename\": \"Bug_18.json\"\r\n        },\r\n        {\r\n            \"display\": \"Words 18 wpm\",\r\n            \"filename\": \"Bug_18_Words.json\"\r\n        },\r\n        {\r\n            \"display\": \"Spell 20 wpm\",\r\n            \"filename\": \"Bug_20.json\"\r\n        },\r\n        {\r\n            \"display\": \"Words 20 wpm\",\r\n            \"filename\": \"Bug_20_Words.json\"\r\n        }\r\n    ]\r\n}";

/***/ })

}]);