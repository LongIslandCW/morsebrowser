"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Student_Practice_json"],{

/***/ "./src/wordfiles/Student_Practice.json":
/*!*********************************************!*\
  !*** ./src/wordfiles/Student_Practice.json ***!
  \*********************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"YRS","minWordSize":"3","maxWordSize":"3","words":20}');

/***/ })

}]);