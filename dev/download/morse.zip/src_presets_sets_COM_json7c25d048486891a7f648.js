"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_COM_json"],{

/***/ "./src/presets/sets/COM.json":
/*!***********************************!*\
  !*** ./src/presets/sets/COM.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"20 wpm","filename":"Com_test_Preset.json"}]}');

/***/ })

}]);