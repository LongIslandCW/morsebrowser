"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2406_txt"],{

/***/ "./src/wordfiles/IB2406.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2406.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "\n";

/***/ })

}]);