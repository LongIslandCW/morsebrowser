"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LICW_Challenge_PPB_txt"],{

/***/ "./src/wordfiles/LICW_Challenge_PPB.txt":
/*!**********************************************!*\
  !*** ./src/wordfiles/LICW_Challenge_PPB.txt ***!
  \**********************************************/
/***/ ((module) => {

module.exports = "{599|}\n{599 TX|}\n{599 TX TOM|}\n599 TX TOM 450i\r\n{  |}\r\n{379|}\n{379 CA|}\n{379 CA DAVID|}\n379 CA DAVID 1974k\r\n{  |}\r\n{579|}\n{579 OR|}\n{579 OR GLENN|}\n579 OR GLENN 354\r\n{  |}\r\n{599|}\n{599 IL|}\n{599 IL MIKE|}\n599 IL MIKE 2145m\r\n{  |}\r\n{479|}\n{479 MN|}\n{479 MN JANE|}\n479 MN JANE 160is\r\n{  |}\r\n{5NN|}\n{5NN WA|}\n{5NN WA SID|}\n5NN WA SID 759\r\n{  |}\r\n{479|}\n{479 TN|}\n{479 TN HOWARD|}\n479 TN HOWARD 1845a\r\n{  |}\r\n{599|}\n{599 OH|}\n{599 OH CAROL|}\n{599 OH CAROL 750i|}\r\n{  |}\r\n{459|}\n{459 KS|}\n{459 KS TIM|}\n{459 KS TIM 37m|}\r\n{  |}\r\n{599|}\n{599 IA|}\n{599 IA JOE|}\n599 IA JOE 600\r\n{  |}\r\n{579|}\n{579 NH|}\n{579 NH JANE|}\n579 NH JANE 14k\r\n{  |}\r\n{559|}\n{559 AR|}\n{559 AR GARY|}\n559 AR GARY 927i\r\n{  |}\r\n{479|}\n{479 KY|}\n{479 KY ALEX|}\n479 KY ALEX 1257as\r\n{  |}\r\n{5NN|}\n{5NN ND|}\n{5NN ND GREG|}\n599NN ND GREG 2900m\r\n{  |}\r\n{459|}\n{459 WV|}\n{459 WV JEFF|}\n459 WV JEFF 691I\r\n{  |}\r\n{579|}\n{579 SD|}\n{579 SD ROLAND|}\n579 SD ROLAND 375is\r\n{  |}\r\n{599|}\n{599 PA|}\n{599 PA DUFF|}\n599 PA DUFF 981\r\n{  |}\r\n{479|}\n{479 OK|}\n{479 OK FRANK|}\n479 OK FRANK 1195I\r\n{  |}\r\n{599|}\n{599 RI|}\n{599 RI BOB|}\n599 RI BOB 1469m\r\n{  |}\r\n{379|}\n{379 MA|}\n{379 MA BILL|}\n379 MA BILL 1757a\r\n{  |}\r\n{579|}\n{579 MO|}\n{579 MO SKIP|}\n579 MO SKIP 321k\r\n{  |}\r\n{599|}\n{599 AK|}\n{599 AK CATHY|}\n599 AK CATHY 652as\r\n{  |}\r\n{479|}\n{479 DE|}\n{479 DE KAT|}\n479 DE KAT 359a\r\n{  |}\r\n{559|}\n{559 MT|}\n{559 MT ED|}\n559 MT ED 1441I\r\n\r\n";

/***/ })

}]);