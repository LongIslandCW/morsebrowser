"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT1_QSO1_txt"],{

/***/ "./src/wordfiles/INT1_QSO1.txt":
/*!*************************************!*\
  !*** ./src/wordfiles/INT1_QSO1.txt ***!
  \*************************************/
/***/ ((module) => {

module.exports = "CQ CQ DE K2LTL K2LTL K \r\nK2LTL DE K4VN K4VN K \r\nK4VN DE K2LTL \r\nGM ES TNX FER CALL \r\nUR RST 579 57N \r\nQTH AUSTIN, TX AUSTIN, TX\t \r\nNAME PAT PAT \r\nOK HW? K4VN DE K2LTL K \r\nK2LTL DE K4VN \r\nGM ES TNX FER RPRT \r\nUR RST 559 559 \r\nQTH BOSTON, MA BOSTON, MA \r\nNAME ANNETTE ANNETTE \r\nOK HW? K2LTL DE K4VN K \r\nOK ANNETTE FB ES TNX FER RPRT \r\nRIG KX3 ES PWR 500W \r\nANT BEAM UP 25 FT \r\nWX CLOUDY ES TEMP 47F \r\nOK HW? K4VN DE K2LTL K \r\nOK PAT TNX FER INFO \r\nRIG IC 7300 ES PWR 5W \r\nANT VERTICAL UP 25 FT \r\nWX RAINING ES TEMP 59F \r\nOK PAT HW? K2LTL DE K4VN K \r\nOK ANNETTE GUD CPY \r\nBEEN HAM 12 YRS \r\nAGE HR 29 YRS \r\nWRK AS WRITER \r\nOK ANNETTE HW? K4VN DE K2LTL K \r\nOK PAT GUD CPY \r\nBEEN HAM 30 YRS \r\nAGE HR 52 YRS \r\nWRK AS DOCTOR \r\nOK PAT HW? K2LTL DE K4VN K \r\nOK ANNETTE TNX FER FB QSO \r\nES HP CUAGN 73 \r\nK4VN DE K2LTL TU SK \r\nOK PAT TNX FER FB QSO \r\nES HP CUAGN 73 ";

/***/ })

}]);