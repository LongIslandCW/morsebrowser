"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN11_txt"],{

/***/ "./src/wordfiles/TIN11.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/TIN11.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "NEW NET   \nRR TU  \nABT U  \nUR ANT  \nRU NEW\nURBAN TRIBE  \nBEEN ABT  \nATE BURNT  \nEAT TUNA  \nTAN TUBER  \nWET WATER  \nTU NATE  \nEA TUNE\nU WRITE  \nEA WINE  \nUNTIE BRENT  \nUR EAR  \nEA BEAR \n";

/***/ })

}]);