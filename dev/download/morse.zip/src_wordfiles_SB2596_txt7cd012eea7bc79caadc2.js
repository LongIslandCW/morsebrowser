"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2596_txt"],{

/***/ "./src/wordfiles/SB2596.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2596.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL \nAR \nCA \nCO \nCT \n{DE|delaware} \nFL \n{GA|georgia}  \n{HI|hawaii}  \n{ID|idaho} \nIL \n{IN|indiana}  \nIA \n{LA|louisiana} \nNE \nNH \nNC \nND \nOH \nPA \nRI \nSC \nSD \nTN \nUT \nWA \nWI\n";

/***/ })

}]);