"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB21611_json"],{

/***/ "./src/wordfiles/SB21611.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB21611.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb16.<ar><sk><bt>73?qxv59,","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);