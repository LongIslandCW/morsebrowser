"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_txt"],{

/***/ "./src/wordfiles/INT3.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT3.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "a\nb\nc\nd\ne\nf\ng\nh\ni\nj\nk\nl\nm\nn\no\np\nq\nr\ns\nt\nu\nv\nw\nx\ny\nz\n1\n2\n3\n4\n5\n6\n7\n8\n9\n0\n.\n,\n/\n?\n\n";

/***/ })

}]);