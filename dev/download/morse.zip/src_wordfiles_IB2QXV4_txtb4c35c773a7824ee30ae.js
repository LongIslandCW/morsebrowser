"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV4_txt"],{

/***/ "./src/wordfiles/IB2QXV4.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2QXV4.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "GA ES TNX FER CALL <BT> GE ES TNX FER RPRT <BT> TNX FER FB RPRT <BT> SOLID CPI RON <BT> QTH NR PHOENIX <BT> QTH PORTLAND <BT> WX RAIN ES WIND <BT> WX SUN ES NICE <BT> RIG FLEX <BT> RIG QSX = RIG TEN TEC = RIG KNWD = RIG TEN TEC = RIG BOAT ANCHOR <BT> ANT VERT <BT> KEY BUG <BT> NICE FIST OT <BT> NICE SIG <BT> WILL QRT NOW <BT> TNX FER FB QSO <BT> GUD DX ES HPE CUAGN SOCHO san";

/***/ })

}]);