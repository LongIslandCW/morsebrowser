"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_INT3_json"],{

/***/ "./src/presets/sets/INT3.json":
/*!************************************!*\
  !*** ./src/presets/sets/INT3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 16/16","filename":"INT2_Default_16.json"},{"display":"Default 20/20","filename":"INT2_Default_20.json"},{"display":"Familiarity Phrases","filename":"INT3_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"INT3_FAM_Sentences.json"},{"display":"Familiarity Spelling","filename":"INT3_FAM_Spell.json"},{"display":"Familiarity Words","filename":"INT3_FAM_Words.json"},{"display":"Groups of 5","filename":"INT2_Groups_5.json"},{"display":"ICR","filename":"INT2_ICR.json"},{"display":"Phrases","filename":"INT2_Phrases.json"},{"display":"Random Groups 1-5","filename":"INT2_Random_1_5.json"},{"display":"Reverse VET","filename":"INT2_RVET.json"},{"display":"Reverse VST","filename":"INT2_RVST.json"},{"display":"Sending Practice","filename":"INT2_Sending.json"},{"display":"Suduko","filename":"suduko20.json"},{"display":"VET","filename":"INT2_VET.json"},{"display":"VST","filename":"INT2_VST.json"},{"display":"Voice On & Spell On","filename":"INT2_Von_Son.json"},{"display":"Voice On & Spell Off","filename":"INT2_Von_Soff.json"}]}');

/***/ })

}]);