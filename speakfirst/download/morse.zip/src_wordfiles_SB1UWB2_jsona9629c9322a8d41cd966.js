"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1UWB2_json"],{

/***/ "./src/wordfiles/SB1UWB2.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1UWB2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"uwbhof","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);