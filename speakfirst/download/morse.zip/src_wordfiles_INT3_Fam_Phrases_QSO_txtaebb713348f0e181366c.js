"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT3_Fam_Phrases_QSO_txt"],{

/***/ "./src/wordfiles/INT3_Fam_Phrases_QSO.txt":
/*!************************************************!*\
  !*** ./src/wordfiles/INT3_Fam_Phrases_QSO.txt ***!
  \************************************************/
/***/ ((module) => {

module.exports = "WX IS \r\nWX IS VRY NICE \r\nWX IS VRY NICE ES SUNNY \r\n{<BT>|}\r\nVY NICE\r\nVY NICE QSO ON \r\nVY NICE QSO ON 17M BOB \r\n{<BT>|}\r\nUR RST \r\nUR RST 599 5NN \r\nUR RST 599 5NN INTO DALLAS \r\n{<BT>|}\r\nTNX FER \r\nTNX FER THE FB \r\nTNX FER THE FB QSO OM \r\n{<BT>|}\r\nAGE 58 \r\nAGE 58 YRS BEEN \r\nAGE 58 YRS BEEN HAM FER  \r\n{<BT>|}\r\nES {HP|hope}  \r\nES {HP|hope} CUAGN 73 \r\nES {HP|hope} CUAGN 73 N1CC SK \r\n\r\n\r\n";

/***/ })

}]);