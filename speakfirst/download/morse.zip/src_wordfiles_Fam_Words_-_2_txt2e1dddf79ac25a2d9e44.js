"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_2_txt"],{

/***/ "./src/wordfiles/Fam_Words - 2.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 2.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "he \n{he|} \n{he|} \n{|} \r\nhow \n{how|} \n{how|} \n{|} \r\nby \n{by|} \n{by|} \n{|} \r\ncould \n{could|} \n{could|} \n{|} \r\nhis \n{his|} \n{his|} \n{|} \r\nnot \n{not|} \n{not|} \n{|} \r\nno \n{no|} \n{no|} \n{|} \r\nperson \n{person|} \n{person|} \n{|} \r\non \n{on|} \n{on|} \n{|} \r\nwork \n{work|} \n{work|} \n{|} \r\ngood \n{good|} \n{good|} \n{|} \r\nknow \n{know|} \n{know|} \n{|} \r\nwhen \n{when|} \n{when|} \n{|} \r\nI \n{I|} \n{I|} \n{|} \r\nlook \n{look|} \n{look|} \n{|} \r\ngo \n{go|} \n{go|} \n{|} \r\nday \n{day|} \n{day|} \n{|} \r\ncome \n{come|} \n{come|} \n{|} \r\nover \n{over|} \n{over|} \n{|} \r\nsay \n{say|} \n{say|} \n{|} \r\nto \n{to|} \n{to|} \n{|} \r\nfor \n{for|} \n{for|} \n{|} \r\nabout \n{about|} \n{about|} \n{|} \r\nthem \n{them|} \n{them|} \n{|} \r\ncan \n{can|} \n{can|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);