"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB27312_json"],{

/***/ "./src/wordfiles/SB27312.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB27312.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv59,kmy4028bk","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);