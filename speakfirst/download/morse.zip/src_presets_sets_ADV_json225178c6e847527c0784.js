"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV_json"],{

/***/ "./src/presets/sets/ADV.json":
/*!***********************************!*\
  !*** ./src/presets/sets/ADV.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 25/25","filename":"ADVBUF.json"},{"display":"Familiarity Spell 25wpm","filename":"ADV_FAM_Spell_25.json"},{"display":"Familiarity Spell 30wpm","filename":"ADV_FAM_Spell_30.json"},{"display":"Familiarity Spell 35wpm","filename":"ADV_FAM_Spell_35.json"},{"display":"Familiarity Words 25wpm","filename":"ADV_WORDS_25.json"},{"display":"Familiarity Words 30wpm","filename":"ADV_WORDS_30.json"},{"display":"Familiarity Words 35wpm","filename":"ADV_WORDS_35.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Instant Word Recognition","filename":"IWR.json"},{"display":"Prefixes","filename":"ADVBUF.json"},{"display":"Sentences","filename":"ADVBUF.json"},{"display":"Suffixes","filename":"ADVBUF.json"},{"display":"Voice after 2","filename":"ADV2WB.json"},{"display":"Voice after 3","filename":"ADV3WB.json"},{"display":"Voice after 4","filename":"ADV4WB.json"},{"display":"Voice after 5","filename":"ADV5WB.json"}]}');

/***/ })

}]);