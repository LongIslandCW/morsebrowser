"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV2_json"],{

/***/ "./src/presets/sets/ADV2.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 30/30","filename":"ADV2BUF.json"},{"display":"Familiarity Spell","filename":"ADV2_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV2_FAM_WORDS.json"},{"display":"Familiarity Words ADV3","filename":"ADV3_FAM_WORDS.json"},{"display":"Familiarity Phrases","filename":"ADV2_FAM_Phrases.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Prefixes","filename":"ADVBUF.json"},{"display":"Sentences","filename":"ADVBUF.json"},{"display":"Suffixes","filename":"ADVBUF.json"},{"display":"Voice after 2","filename":"ADV2WB.json"}]}');

/***/ })

}]);