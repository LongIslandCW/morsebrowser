"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV_json"],{

/***/ "./src/presets/sets/ADV.json":
/*!***********************************!*\
  !*** ./src/presets/sets/ADV.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 25/25","filename":"ADVBUF.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Sentences","filename":"ADVBUF.json"},{"display":"Instant Word Recognition","filename":"IWR.json"},{"display":"Voice after 2","filename":"ADV2WB.json"},{"display":"Voice after 3","filename":"ADV3WB.json"},{"display":"Voice after 4","filename":"ADV4WB.json"},{"display":"Voice after 5","filename":"ADV5WB.json"},{"display":"Prefixes","filename":"ADVBUF.json"},{"display":"Suffixes","filename":"ADVBUF.json"},{"display":"Familiarity Training","filename":"ADVFAM.json"}]}');

/***/ })

}]);