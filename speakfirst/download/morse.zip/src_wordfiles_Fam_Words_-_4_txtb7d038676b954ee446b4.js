"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_4_txt"],{

/***/ "./src/wordfiles/Fam_Words - 4.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 4.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "who \n{who|} \n{who|} \n{|} \r\ntheir \n{their|} \n{their|} \n{|} \r\nwell \n{well|} \n{well|} \n{|} \r\ndo \n{do|} \n{do|} \n{|} \r\neven \n{even|} \n{even|} \n{|} \r\nor \n{or|} \n{or|} \n{|} \r\nbut \n{but|} \n{but|} \n{|} \r\nthat \n{that|} \n{that|} \n{|} \r\nwhich \n{which|} \n{which|} \n{|} \r\ngive \n{give|} \n{give|} \n{|} \r\ntwo \n{two|} \n{two|} \n{|} \r\nso \n{so|} \n{so|} \n{|} \r\nhim \n{him|} \n{him|} \n{|} \r\nthis \n{this|} \n{this|} \n{|} \r\nyear \n{year|} \n{year|} \n{|} \r\nyour \n{your|} \n{your|} \n{|} \r\nthese \n{these|} \n{these|} \n{|} \r\nwant \n{want|} \n{want|} \n{|} \r\nthey \n{they|} \n{they|} \n{|} \r\nmake \n{make|} \n{make|} \n{|} \r\nand \n{and|} \n{and|} \n{|} \r\nnew \n{new|} \n{new|} \n{|} \r\nbecause \n{because|} \n{because|} \n{|} \r\ntake \n{take|} \n{take|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);