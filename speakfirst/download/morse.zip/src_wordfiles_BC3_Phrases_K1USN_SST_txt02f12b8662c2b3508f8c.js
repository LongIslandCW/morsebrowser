"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_K1USN_SST_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_K1USN_SST.txt":
/*!*************************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_K1USN_SST.txt ***!
  \*************************************************/
/***/ ((module) => {

module.exports = "GA N1CC TOM {TX|texas} \r\n{<BT>|}  \r\nGM {N5AT|n 5 a t} SPENCER MA \r\n{<BT>|}  \r\nGE {KA9ZM|k a 9 z m} FAITH IA \r\n{<BT>|}  \r\nGE {A5BR|A 5 B R} JAN CO \r\n{<BT>|}  \r\nGM WW8TRL {MAXINE|maxine} UT \r\n{<BT>|}  \r\nGE N8VK DARRYL MO \r\n{<BT>|}  \r\nGA N0UIP NICHOLE NE \r\n{<BT>|}  \r\nGE A0QC CHAD MD \r\n{<BT>|}  \r\nGA {AS6ZEJ|A S 6 Z E J} JOHNIE NE \r\n{<BT>|}  \r\nGE KD5J VERA NC \r\n";

/***/ })

}]);