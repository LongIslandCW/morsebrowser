"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ADV2_Fam_Phrases_4L_txt"],{

/***/ "./src/wordfiles/ADV2_Fam_Phrases_4L.txt":
/*!***********************************************!*\
  !*** ./src/wordfiles/ADV2_Fam_Phrases_4L.txt ***!
  \***********************************************/
/***/ ((module) => {

module.exports = "WE CAN \r\nWE CAN SIT ON \r\nWE CAN SIT ON A CAR \r\nWE CAN SIT ON A CAR SEAT NOW \r\n{<BT>|}\r\nTO HIT \r\nTO HIT THE NAIL \r\nTO HIT THE NAIL ON THE \r\nTO HIT THE NAIL ON THE HEAD HARD \r\n{<BT>|}\r\nA COIN \r\nA COIN TOSS CAN \r\nA COIN TOSS CAN END THIS \r\nA COIN TOSS CAN END THIS DEBATE QUICKLY \r\n{<BT>|}\r\nEAT NOW \r\nEAT NOW WHILE YOU \r\nEAT NOW WHILE YOU HAVE THE \r\nEAT NOW WHILE YOU HAVE THE CHANCE TOO \r\n{<BT>|}\r\nYOU CANT \r\nYOU CANT JUDGE A \r\nYOU CANT JUDGE A BOOK BY  \r\nYOU CANT JUDGE A BOOK BY ITS COVER \r\n";

/***/ })

}]);