"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2169_json"],{

/***/ "./src/wordfiles/SB2169.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2169.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb16.<ar><sk><bt>73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);