"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Q_txt"],{

/***/ "./src/wordfiles/Fam_Q.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/Fam_Q.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{QTH|QTH } \n{QTH|} \n{QTH|} \n{|} \r\n{QRL|QRL}  \n{QRL|} \n{QRL|} \n{|} \r\n{QRM|QRM} \n{QRM|} \n{QRM|} \n{|} \r\n{QRN|QRN} \n{QRN|} \n{QRN|} \n{|} \r\n{QRP|QRP} \n{QRP|} \n{QRP|} \n{|} \r\n{QRQ|QRQ} \n{QRQ|} \n{QRQ|} \n{|} \r\n{QRS|QRS} \n{QRS|} \n{QRS|} \n{|} \r\n{QRT|QRT} \n{QRT|} \n{QRT|} \n{|} \r\n{QRZ|Q R Z} \n{QRZ|} \n{QRZ|} \n{|} \r\n{QSB|QSB} \n{QSB|} \n{QSB|} \n{|} \r\n{QSY|QSY} \n{QSY|} \n{QSY|} \n{|} \r\n{QTH|QTH } \n{QTH|} \n{QTH|} \n{|} \r\n{QRL|QRL}  \n{QRL|} \n{QRL|} \n{|} \r\n{QRM|QRM} \n{QRM|} \n{QRM|} \n{|} \r\n{QRN|QRN} \n{QRN|} \n{QRN|} \n{|} \r\n{QRP|QRP} \n{QRP|} \n{QRP|} \n{|} \r\n{QRQ|QRQ} \n{QRQ|} \n{QRQ|} \n{|} \r\n{QRS|QRS} \n{QRS|} \n{QRS|} \n{|} \r\n{QRT|QRT} \n{QRT|} \n{QRT|} \n{|} \r\n{QRZ|Q R Z} \n{QRZ|} \n{QRZ|} \n{|} \r\n{QSB|QSB} \n{QSB|} \n{QSB|} \n{|} \r\n{QSY|QSY} \n{QSY|} \n{QSY|} \n{|} \r\n";

/***/ })

}]);