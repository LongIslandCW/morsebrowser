"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV_json"],{

/***/ "./src/presets/sets/ADV.json":
/*!***********************************!*\
  !*** ./src/presets/sets/ADV.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 25/25","filename":"ADVBUF.json"},{"display":"Familiarity Spell ADV1","filename":"ADV1_FAM_Spell.json"},{"display":"Familiarity Spell ADV2","filename":"ADV2_FAM_Spell.json"},{"display":"Familiarity Spell ADV3","filename":"ADV3_FAM_Spell.json"},{"display":"Familiarity Words ADV1","filename":"ADV1_FAM_WORDS.json"},{"display":"Familiarity Words ADV2","filename":"ADV2_FAM_WORDS.json"},{"display":"Familiarity Words ADV3","filename":"ADV3_FAM_WORDS.json"},{"display":"Familiarity Phrases ADV1","filename":"ADV1_FAM_Phrases.json"},{"display":"Familiarity Phrases ADV2","filename":"ADV2_FAM_Phrases.json"},{"display":"Familiarity Phrases ADV3","filename":"ADV3_FAM_Phrases.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Prefixes","filename":"ADVBUF.json"},{"display":"Sentences","filename":"ADVBUF.json"},{"display":"Suffixes","filename":"ADVBUF.json"},{"display":"Voice after 2","filename":"ADV2WB.json"},{"display":"Voice after 3","filename":"ADV3WB.json"},{"display":"Voice after 4","filename":"ADV4WB.json"},{"display":"Voice after 5","filename":"ADV5WB.json"}]}');

/***/ })

}]);