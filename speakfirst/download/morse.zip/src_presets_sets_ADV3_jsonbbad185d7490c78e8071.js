"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV3_json"],{

/***/ "./src/presets/sets/ADV3.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 35/35","filename":"ADV3BUF.json"},{"display":"Familiarity Phrases","filename":"ADV3_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"ADV3_FAM_Sentences.json"},{"display":"Familiarity Spell","filename":"ADV3_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV3_FAM_WORDS.json"},{"display":"ICR","filename":"ADVICR.json"},{"display":"Prefixes","filename":"ADVBUF.json"},{"display":"Sentences","filename":"ADVBUF.json"},{"display":"Suffixes","filename":"ADVBUF.json"},{"display":"Voice after 2","filename":"ADV2WB.json"}]}');

/***/ })

}]);