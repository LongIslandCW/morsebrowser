"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY10_json"],{

/***/ "./src/wordfiles/SB2KMY10.json":
/*!*************************************!*\
  !*** ./src/wordfiles/SB2KMY10.json ***!
  \*************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy4028bkzj/16.","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);