"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_P-Eval_CS_txt"],{

/***/ "./src/wordfiles/BC2_P-Eval_CS.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/BC2_P-Eval_CS.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "WO6ZQ \r\nAF2JCW \r\nNB4RU \r\nNS8EY \r\nKØDL \r\nNV1HG \r\nW9PAM \r\nAX5TI \r\nN3GE \r\nN7RD \r\nN1SM \r\nW6ZF \r\nW2RT \r\nNØAB \r\nAC7LD \r\nNA3ILG \r\nKB9XO \r\nWP4J \r\nWY5HQ \r\nN8VEU \r\nN5DS \r\nW1AW \r\nVE8TO \r\nW2LC \r\nAC3Y \r\nWBØHQ \r\nAC6PFA \r\nJ7TIZ \r\nWX9ER \r\nKG4UM \r\nVK1TF \r\nW6ARF \r\nK2NDG \r\nAB8U \r\nWØIS \r\nAP4NQ \r\nW5HOY \r\nN9CDL \r\nN7XZ \r\nWM3EJ \r\nAH7CUL \r\nN3IE \r\nAI4PL \r\nGØPXT \r\nWB9R \r\nAA5TIY \r\nK2DG \r\nWJ8FQ \r\nWO6Z \r\nVE1SM \r\n";

/***/ })

}]);