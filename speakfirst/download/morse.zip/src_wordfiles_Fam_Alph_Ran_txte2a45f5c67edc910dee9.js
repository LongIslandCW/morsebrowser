"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Alph_Ran_txt"],{

/***/ "./src/wordfiles/Fam_Alph_Ran.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/Fam_Alph_Ran.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "Z \n{Z|} \n{Z|} \n{|} \r\nQ \n{Q|} \n{Q|} \n{|} \r\nD \n{D|} \n{D|} \n{|} \r\nO \n{O|} \n{O|} \n{|} \r\nX \n{X|} \n{X|} \n{|} \r\nE \n{E|} \n{E|} \n{|} \r\nY \n{Y|} \n{Y|} \n{|} \r\nJ \n{J|} \n{J|} \n{|} \r\n{R|R}  \n{R|} \n{R|} \n{|} \r\nA \n{A|} \n{A|} \n{|} \r\n{K|K} \n{K|} \n{K|} \n{|} \r\nS \n{S|} \n{S|} \n{|} \r\nP \n{P|} \n{P|} \n{|} \r\n{F|F} \n{F|} \n{F|} \n{|} \r\nM \n{M|} \n{M|} \n{|} \r\nH \n{H|} \n{H|} \n{|} \r\n{C|C} \n{C|} \n{C|} \n{|} \r\n{W|W}  \n{W|} \n{W|} \n{|} \r\nG \n{G|} \n{G|} \n{|} \r\n{T|T}  \n{T|} \n{T|} \n{|} \r\nU \n{U|} \n{U|} \n{|} \r\nI \n{I|} \n{I|} \n{|} \r\nV \n{V|} \n{V|} \n{|} \r\n{N|N} \n{N|} \n{N|} \n{|} \r\nB \n{B|} \n{B|} \n{|} \r\nL \n{L|} \n{L|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);