"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB24012_json"],{

/***/ "./src/wordfiles/SB24012.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB24012.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb4028bkzj/16.<ar><sk><bt>73?","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);