"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK14_json"],{

/***/ "./src/wordfiles/SB228BK14.json":
/*!**************************************!*\
  !*** ./src/wordfiles/SB228BK14.json ***!
  \**************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb28bkzj/16.<ar><sk><bt>73?qxv59,kmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);