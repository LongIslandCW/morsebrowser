"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC1_P_Eval_W_txt"],{

/***/ "./src/wordfiles/BC1_P_Eval_W.txt":
/*!****************************************!*\
  !*** ./src/wordfiles/BC1_P_Eval_W.txt ***!
  \****************************************/
/***/ ((module) => {

module.exports = "NICE \r\nRUB \r\nFOR \r\nBREW \r\nFOUR \r\nRUBE \r\nWEAR \r\nDIGS \r\nTIN \r\nHOPING \r\nFOLD \r\nBOAR \r\nHEAR \r\nHOPING \r\nWHAT \r\nWHIP \r\nSHIFT \r\nCLING \r\nSPLIT \r\nGOLD \r\nTUNE \r\nRIG \r\nPAINT \r\nFOUR \r\nAGE \r\nHANGS \r\nCLEAR \r\nTAP \r\nGRASP \r\nBEEN \r\nTRAIN \r\nWIND \r\nEAT \r\nWET \r\nAIR \r\nTUNE \r\nSHOP \r\nDOCS \r\nGOLD \r\nBAIT \r\nRENT \r\nWHO \r\nFOUL \r\nFOLD \r\nBRAGS \r\nRAIN \r\nSUN \r\nNICE \r\nBUG \r\nWIND \r\nTEN \r\nSLIP \r\nWET \r\nWHO \r\nWIND \r\nSOLID \r\nDIPOLE \r\nRAIN \r\nBEEN \r\nFOR \r\nRING \r\nWATER \r\nCLUB \r\nWHO \r\nSLIP \r\nSOLD \r\nFOG \r\nCLUB \r\nBOLD \r\nCOULD \r\nWENT \r\nBURN \r\nBAIT \r\nSHOP \r\nFOG \r\nRAIN \r\nNICE \r\nFOUR \r\nRUBE \r\nBOAR \r\nHEAR \r\nWENT \r\nSLIP \r\nGOLD \r\nHOPING \r\nWHAT \r\nRAIN \r\nBEEN \r\nSNAP \r\nFOUL \r\nPEAS \r\nSUN \r\nNICE \r\nWIND \r\nPAINTS \r\nTIN \r\nWIRE \r\nCLEAR \r\nGROUP \r\nRUB \r\nHERO \r\nDIPOLE \r\nSUN \r\nSHIFT \r\n";

/***/ })

}]);