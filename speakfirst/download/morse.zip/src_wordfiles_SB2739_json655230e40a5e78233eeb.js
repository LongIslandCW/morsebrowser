"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2739_json"],{

/***/ "./src/wordfiles/SB2739.json":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2739.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb73?qxv59,","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);