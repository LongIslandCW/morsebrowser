"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT9_txt"],{

/***/ "./src/wordfiles/INT9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/INT9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AL \nAK \nAZ \nAR \nCA \nCO \nCT \n{DE|delaware} \nFL \n{GA|georgia} \n{HI|hawaii} \n{ID|idaho} \nIL \n{IN|indiana} \nIA \nKS \nKY \n{LA|louisiana} \n{ME|maine} \nMD \nMA \nMI \nMN \nMS \nMO \nMT \nNC \nND \nNE \nNV \nNH \nNJ \n{NM|new mexico} \nNY \n{OH|ohio} \n{OK|oklahoma}  \n{OR|oregon} \nPA \nRI \nSC \nSD \nTN \n{TX|texas} \nUT \nVT \nVA \nWA \nWV \nWI \nWY\n";

/***/ })

}]);