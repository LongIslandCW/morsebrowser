"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB1REA2_json"],{

/***/ "./src/wordfiles/SB1REA2.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB1REA2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reauwb","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);