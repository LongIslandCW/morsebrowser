"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2406_txt"],{

/***/ "./src/wordfiles/IB2406.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2406.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AD0WE \nAI4PL \nG4FON \nG0POT \nWB0ISG \nN4DTR \nWB4UTB \nWB0HOA \nAA0TIN \nAC4LCD \nAB0CD \nN4FOH \nN0CDL\n";

/***/ })

}]);