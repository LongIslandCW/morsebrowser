"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY2_json"],{

/***/ "./src/wordfiles/IB2KMY2.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB2KMY2.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"m","minWordSize":1,"maxWordSize":1,"practiceSeconds":60}');

/***/ })

}]);