"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2593_json"],{

/***/ "./src/wordfiles/IB2593.json":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2593.json ***!
  \***********************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"59","minWordSize":2,"maxWordSize":2,"practiceSeconds":120}');

/***/ })

}]);