"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_1_txt"],{

/***/ "./src/wordfiles/Fam_Words - 1.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 1.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "some \n{some|} \n{some|} \n{|} \r\nthan \n{than|} \n{than|} \n{|} \r\nin \n{in|} \n{in|} \n{|} \r\nnow \n{now|} \n{now|} \n{|} \r\none \n{one|} \n{one|} \n{|} \r\nback \n{back|} \n{back|} \n{|} \r\nof \n{of|} \n{of|} \n{|} \r\nall \n{all|} \n{all|} \n{|} \r\nup \n{up|} \n{up|} \n{|} \r\njust \n{just|} \n{just|} \n{|} \r\nalso \n{also|} \n{also|} \n{|} \r\nwhat \n{what|} \n{what|} \n{|} \r\nlike \n{like|} \n{like|} \n{|} \r\nthen \n{then|} \n{then|} \n{|} \r\nme \n{me|} \n{me|} \n{|} \r\nits \n{its|} \n{its|} \n{|} \r\nmost \n{most|} \n{most|} \n{|} \r\nafter \n{after|} \n{after|} \n{|} \r\nother \n{other|} \n{other|} \n{|} \r\nwould \n{would|} \n{would|} \n{|} \r\nuse \n{use|} \n{use|} \n{|} \r\nus \n{us|} \n{us|} \n{|} \r\nshe \n{she|} \n{she|} \n{|} \r\nhave \n{have|} \n{have|} \n{|} \r\nan \n{an|} \n{an|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);