"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB24013_json"],{

/***/ "./src/wordfiles/SB24013.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB24013.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwb4028bkzj/16.<ar><sk><bt>73?qxv","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);