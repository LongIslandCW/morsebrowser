"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Words_-_3_txt"],{

/***/ "./src/wordfiles/Fam_Words - 3.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/Fam_Words - 3.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "way \n{way|} \n{way|} \n{|} \r\nthere \n{there|} \n{there|} \n{|} \r\nfrom \n{from|} \n{from|} \n{|} \r\nour \n{our|} \n{our|} \n{|} \r\nmy \n{my|} \n{my|} \n{|} \r\nsee \n{see|} \n{see|} \n{|} \r\nany \n{any|} \n{any|} \n{|} \r\nbe \n{be|} \n{be|} \n{|} \r\nget \n{get|} \n{get|} \n{|} \r\nas \n{as|} \n{as|} \n{|} \r\nit \n{it|} \n{it|} \n{|} \r\nonly \n{only|} \n{only|} \n{|} \r\nfirst \n{first|} \n{first|} \n{|} \r\nif \n{if|} \n{if|} \n{|} \r\nat \n{at|} \n{at|} \n{|} \r\na \n{a|} \n{a|} \n{|} \r\nthe \n{the|} \n{the|} \n{|} \r\nyou \n{you|} \n{you|} \n{|} \r\nout \n{out|} \n{out|} \n{|} \r\nwill \n{will|} \n{will|} \n{|} \r\nwith \n{with|} \n{with|} \n{|} \r\nher \n{her|} \n{her|} \n{|} \r\nwe \n{we|} \n{we|} \n{|} \r\nthink \n{think|} \n{think|} \n{|} \r\ntime \n{time|} \n{time|} \n{|} \r\n\r\n\r\n";

/***/ })

}]);