"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2KMY6_json"],{

/***/ "./src/wordfiles/SB2KMY6.json":
/*!************************************!*\
  !*** ./src/wordfiles/SB2KMY6.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"reatinpgslcdhofuwbkmy","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);