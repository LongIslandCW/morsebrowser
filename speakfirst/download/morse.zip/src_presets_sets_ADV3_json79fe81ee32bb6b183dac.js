"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_ADV3_json"],{

/***/ "./src/presets/sets/ADV3.json":
/*!************************************!*\
  !*** ./src/presets/sets/ADV3.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 35/35","filename":"ADV3BUF.json"},{"display":"Affixes","filename":"ADV3BUF.json"},{"display":"Familiarity Phrases","filename":"ADV3_FAM_Phrases.json"},{"display":"Familiarity Sentences","filename":"ADV3_FAM_Sentences.json"},{"display":"Familiarity Spell","filename":"ADV3_FAM_Spell.json"},{"display":"Familiarity Words","filename":"ADV3_FAM_WORDS.json"},{"display":"ICR","filename":"ADVICR.json"}]}');

/***/ })

}]);