"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB1HOF7_json"],{

/***/ "./src/wordfiles/IB1HOF7.json":
/*!************************************!*\
  !*** ./src/wordfiles/IB1HOF7.json ***!
  \************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"hoflcdpgs","minWordSize":3,"maxWordSize":3,"practiceSeconds":120}');

/***/ })

}]);