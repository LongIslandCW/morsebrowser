"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC2_P-Eval_CS_txt"],{

/***/ "./src/wordfiles/BC2_P-Eval_CS.txt":
/*!*****************************************!*\
  !*** ./src/wordfiles/BC2_P-Eval_CS.txt ***!
  \*****************************************/
/***/ ((module) => {

module.exports = "WO6ZQ AF2JCW NB4RU NS8EY KØDL NV1HG W9PAM AX5TI N3GE N7RD \r\nN1SM W6ZF W2RT NØAB AC7LD NA3ILG KB9XO WP4J WY5HQ N8VEU \r\nN5DS W1AW VE8TO W2LC AC3Y WBØHQ AC6PFAJ7TIZ WX9ER KG4UM \r\nVK1TF W6ARF K2NDG AB8U WØIS  AP4NQ W5HOY N9CDL N7XZ WM3EJ \r\nAH7CUL N3IE AI4PL GØPXT WB9R AA5TIY K2DG WJ8FQ WO6Z VE1SM ";

/***/ })

}]);