"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_BC3_Phrases_SOTA_txt"],{

/***/ "./src/wordfiles/BC3_Phrases_SOTA.txt":
/*!********************************************!*\
  !*** ./src/wordfiles/BC3_Phrases_SOTA.txt ***!
  \********************************************/
/***/ ((module) => {

module.exports = "GA K4LJI FLOYD AR \r\n{<BT>|} \r\nGM KG7MEX DALTON IL \r\n{<BT>|} \r\nGE A7BZ TYLER WI \r\n{<BT>|} \r\nGA KV1G RICKEY MD \r\n{<BT>|} \r\nGA AV0V KATHRYN NV \r\n{<BT>|} \r\nGA AK2Z KURT PA \r\n{<BT>|} \r\nGA N1RC JOE GREG LA \r\n{<BT>|} \r\nGA NG0EV ELLEN VA \r\n{<BT>|} \r\nGE WZ0F DENISE NC \r\n{<BT>|} \r\nGE N8CT TED NY\r\n ";

/***/ })

}]);