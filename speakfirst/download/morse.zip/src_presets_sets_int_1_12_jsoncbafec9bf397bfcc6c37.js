"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_presets_sets_int_1_12_json"],{

/***/ "./src/presets/sets/int_1_12.json":
/*!****************************************!*\
  !*** ./src/presets/sets/int_1_12.json ***!
  \****************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"options":[{"display":"Default 12/12","filename":"BPT_Default_12.json"},{"display":"Default 15/12","filename":"BPT_Default_15.json"},{"display":"Familiarity Phrases","filename":"INT1_FAM_Phrases.json"},{"display":"Familiarity Spelling","filename":"INT1_FAM_Spell.json"},{"display":"Familiarity Words","filename":"INT1_FAM_Words.json"},{"display":"Groups of 5","filename":"BPT_Groups_5.json"},{"display":"ICR","filename":"BPT_ICR.json"},{"display":"Instant Word Recognition","filename":"IWR.json"},{"display":"Inter-character Head Copy","filename":"BPT_ICHC.json"},{"display":"Random Groups 1-5","filename":"BPT_Random_1_5.json"},{"display":"Reverse VET","filename":"BPT_RVET.json"},{"display":"Reverse VST","filename":"BPT_RVST.json"},{"display":"Sending Practice","filename":"BPT_Sending.json"},{"display":"Suduko","filename":"suduko12.json"},{"display":"VET","filename":"BPT_VET.json"},{"display":"VST","filename":"BPT_VST.json"},{"display":"Voice On & Spell On","filename":"BPT_Von_Son.json"},{"display":"Voice On & Spell Off","filename":"BPT_Von_Soff.json"}]}');

/***/ })

}]);