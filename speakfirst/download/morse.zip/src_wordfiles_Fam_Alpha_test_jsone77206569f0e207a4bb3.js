"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_Fam_Alpha_test_json"],{

/***/ "./src/wordfiles/Fam_Alpha test.json":
/*!*******************************************!*\
  !*** ./src/wordfiles/Fam_Alpha test.json ***!
  \*******************************************/
/***/ ((module) => {

module.exports = JSON.parse('{"letters":"abcdefghijklmnopqrstuvwxyz","minWordSize":1,"maxWordSize":1,"practiceSeconds":120}');

/***/ })

}]);