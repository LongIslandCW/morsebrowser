"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK6_txt"],{

/***/ "./src/wordfiles/SB228BK6.txt":
/*!************************************!*\
  !*** ./src/wordfiles/SB228BK6.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "AL \r\nAR \r\nCA \r\nCO \r\nCT \r\n{DE|delaware} \r\nFL \r\n{GA|georgia} \r\n{HI|hawaii} \r\n{ID|idaho} \r\nID \r\nIL \r\n{IN|indiana} \r\nIA \r\n{IN|indiana} \r\nNE \r\nNH \r\nNC \r\nND \r\n{OH|ohio} \r\n{OR|oregon} \r\nPA \r\nRI \r\nSC \r\nSD \r\nTN \r\nUT \r\nWA \r\nWI \r\n";

/***/ })

}]);