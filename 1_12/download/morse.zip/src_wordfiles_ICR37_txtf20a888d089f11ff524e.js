"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR37_txt"],{

/***/ "./src/wordfiles/ICR37.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR37.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "4I6UW \r\nI5DIU \r\n4SU5E \r\nIBEUV \r\nIW5WW \r\nIEU4T \r\nBTVJE \r\nTDIBV \r\nDSJ4B \r\nUH6W4 \r\n1JVV1 \r\n4B551 \r\nIBD1T \r\n4S5V1 \r\nIH6UJ \r\n65V1B \r\nUD5J4 \r\nEWVHD \r\nHID4H \r\nIESWU \r\n66ITT \r\nSD6UU \r\n6HSUS \r\nHJIDD \r\nHWEEW \r\nS1I66 \r\nH5SHD \r\n11JDU \r\nEJBE4 \r\nH1T5T \r\nE1UD5 \r\nW5IJ1 \r\nSU1J5 \r\nJVEIW \r\n46BWV \r\nSDE4D \r\nI5VTT \r\nWWBT5 \r\nD5B5D \r\nTHDBS \r\nII1DH \r\nESIES \r\nST451 \r\nTEUS1 \r\nVB4UI \r\nTSH4J \r\nJ45JI \r\nDVU54 \r\nI6JBV \r\n5HD6W \r\nHDD61 \r\nHBJ4H \r\nWJ6HT \r\nEI6DD \r\nBJ15T \r\n6WUBB \r\nBBBES \r\nT55BS \r\nSTSWE \r\nWITDH \r\nDT61B \r\n56B6T \r\n6J4W6 \r\n6B5IU \r\nI6EE4 \r\nVTUBU \r\nB6S6V \r\nETV6I \r\n6UJTE \r\nBJ5IB \r\nSWVET \r\nUJ6U1 \r\nB5TD6 \r\n55HBS \r\nBH66S \r\n4JUH6 \r\n1DDEI \r\nHEJJ6 \r\n4HHJU \r\nU6T4J \r\n4T6UW \r\n14DUB \r\nH5E56 \r\n155JV \r\n45VJW \r\n1EWIB \r\nH4HDU \r\nU1BV5 \r\nHSBIJ \r\nSVSVJ \r\nTWEBJ \r\nUD4SV \r\nITEVT \r\nISW4I \r\nH1U5J \r\n4SSTI \r\nTB4D4 \r\nH6TDI \r\nH5BVH \r\nBV1BD \r\nBU5DU \r\nJEVUE \r\n6UIDU \r\nUVTHJ \r\nDBIJU \r\nUETJU \r\nUJJI6 \r\n1U5DD \r\n6B16V \r\n5I5T5 \r\nVWJ6V \r\nUDI5I \r\n1SHV1 \r\n6SETT \r\nHIV4S \r\nWS1US \r\n64DUT \r\nWW1T5 \r\nES1E5 \r\n4BW54 \r\nV1JTI \r\nSEE55 \r\nTBU55 \r\nHDT5H \r\nDHJHJ \r\n61TDV \r\nUD4VE \r\nUE1HE \r\nUWDBW \r\nDSWBU \r\nJETTJ \r\n6EU5H \r\n6HHW6 \r\n1EWSI \r\nH61UE \r\nW1V55 \r\n65565\r\n4W1EW \r\nE444W \r\n6DJIJ \r\nJEDB6 \r\nE4EST \r\n46V1D \r\n4HIEH \r\nDHT61 \r\nVD4VI \r\n6WHJV \r\nUBSUD \r\nJJTID \r\n6UHTU \r\n5D65S \r\n146WW \r\n51SJJ \r\n5VV51 \r\nUE6TW \r\nVJIWE \r\nJ6TUV \r\nT1HD1 \r\nEWEUH \r\n1E1JB \r\nVIHVH \r\n5V46V \r\nD5ISV \r\n1WVV1 \r\nSDSU1 \r\nSBT4D \r\n1J541 \r\nTV5SU \r\nD4465 \r\n1JE1W \r\nI6BB4 \r\n4EVTV \r\nHT551 \r\nB4JTW \r\nDWBS5 \r\nTD1E4 \r\nVB1DT \r\nSJUD1 \r\nT5HES \r\nVJUIB \r\n4USEH \r\n4HVSH \r\nEI5WS \r\nSTBIU \r\n11VSV \r\nWSSI6 \r\nUT1W6 \r\n46TBS \r\nJWSBI \r\n61U6B \r\nBEWT5 \r\n64BHD \r\nBTBU5 \r\nDWDVI \r\nBBBW4 \r\nVJBWJ \r\nHWTJ1 \r\n6T5ES \r\nDB55S \r\nWUB5B \r\n";

/***/ })

}]);