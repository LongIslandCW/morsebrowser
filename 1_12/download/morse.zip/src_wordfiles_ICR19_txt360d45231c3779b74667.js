"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR19_txt"],{

/***/ "./src/wordfiles/ICR19.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR19.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "OK \r\ndry \r\nold \r\nmom \r\nrow \r\nlet \r\ngod \r\nkid \r\nmix \r\nwho \r\nby \r\nsee \r\nbye \r\nart \r\ntry \r\njam \r\ncar \r\nbar \r\ngas \r\nfry \r\nfun \r\nfix \r\ndo \r\nTV \r\ntie \r\nfar \r\nsun \r\nbuy \r\nday \r\nraw \r\ntip \r\nhe \r\nlab \r\nweb \r\noff \r\nyet \r\nI \r\npet \r\nin \r\nshe \r\nnut \r\njoy \r\nsad \r\npig \r\nlay \r\nair \r\nwar \r\nhot \r\nodd \r\nyes \r\nmad \r\nflu \r\nor \r\ncan \r\ncow \r\nour \r\nbe \r\noil \r\nboy \r\ntea \r\nbid \r\nto \r\non \r\nwin \r\nof \r\nuse \r\nits \r\ndad \r\nsex \r\nadd \r\nbag \r\nhow \r\nfor \r\nice \r\ntwo \r\npot \r\nkey \r\nten \r\nbig \r\nyou \r\negg \r\nall \r\nman \r\nCD \r\nhi \r\nit \r\ndig \r\nput \r\nbed \r\nme \r\nfur \r\nso \r\nbit \r\nbeg \r\nact \r\nad \r\narm \r\npop \r\nshy \r\nbad \r\nhis \r\nleg \r\nand \r\nnow \r\ncry \r\ncap \r\nred \r\njob \r\ndog \r\nage \r\near \r\nlaw \r\nnor \r\nban \r\neat \r\nmy \r\npay \r\nski \r\ncut \r\nhim \r\ngap \r\ngun \r\nrid \r\nsum \r\nsix \r\nwe \r\nrun \r\nvia \r\nper \r\naid \r\ntoe \r\nbee \r\nsea \r\nson \r\nmud \r\nfly \r\ngym \r\nat \r\nask \r\nlow \r\nton \r\nah \r\nan \r\napp \r\nout \r\nset \r\ntop \r\nnet \r\nDVD \r\nany \r\nend \r\nnew \r\nget \r\npin \r\nbus \r\nown \r\nguy \r\nfan \r\nfat \r\nus \r\neye \r\ngo \r\ndie \r\ncup \r\nfit \r\nas \r\nway \r\none \r\nbut \r\nup \r\nsky \r\nbet \r\ndue \r\ntax \r\npan \r\nif \r\nbox \r\nlip \r\nlie \r\nhat \r\nrub \r\nowe \r\na \r\ncat \r\ntoy \r\nago \r\nhey \r\ntoo \r\nhit \r\nwow \r\nvan \r\nill \r\nfew \r\nlot \r\nher \r\npen \r\nmap \r\nwet \r\nno \r\nMay \r\nwhy \r\nsir \r\nfee \r\nthe \r\noh \r\nnot \r\nsay \r\naim \r\nsit \r\n\r\n";

/***/ })

}]);