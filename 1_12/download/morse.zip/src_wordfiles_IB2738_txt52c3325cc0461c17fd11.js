"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2738_txt"],{

/***/ "./src/wordfiles/IB2738.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2738.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AC3D N3GE N3IOE N7RD AB7NT WB3WUB WB3OHF AA7TIN AC7CLD AB7CDL WB3EAR N3FOH N7CDL  \r\n";

/***/ })

}]);