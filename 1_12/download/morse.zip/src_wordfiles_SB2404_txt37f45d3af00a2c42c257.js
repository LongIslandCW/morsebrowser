"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2404_txt"],{

/***/ "./src/wordfiles/SB2404.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2404.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "ANT DIPOLE UP 4Ø FT\r\nAGE 4Ø\r\nNICE TO CU AGN ON 4Ø\r\nNICE SIG ON 4Ø\r\nADØWE DE AI4PL\r\nGØPOT DE WBØISG\r\n";

/***/ })

}]);