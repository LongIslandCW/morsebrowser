"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C4_txt"],{

/***/ "./src/wordfiles/IB2C4.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C4.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "W2LCW DE WB2UZE FB CPY RICH ES TNX FER NICE RPRT\t\r\nRIG IC7300 ES PWR 100W \t\r\nANT DIPOLE UP 35 FT\t\r\nWX RAIN ES TEMP 40F\r\nOK HW? <AR> W2LCW DE WB2UZE K\r\n";

/***/ })

}]);