"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2ZJ7_txt"],{

/***/ "./src/wordfiles/IB2ZJ7.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2ZJ7.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "OP ALAN \r\nNICE TO CUAGN BOB\r\nOP ROB\r\nRIG TEN TEC ES ANT DIPOLE\r\nRIG TEN TEC\r\nNICE RIG\r\nUR BOAT ANCHOR FB WID GUD SIG  \r\n";

/***/ })

}]);