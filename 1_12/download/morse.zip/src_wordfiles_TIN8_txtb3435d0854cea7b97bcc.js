"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_TIN8_txt"],{

/***/ "./src/wordfiles/TIN8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/TIN8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "AR \r\n{IN|indiana} \r\nIA \r\nNE \r\n{OR|oregon} \r\nRI \r\nTN \r\nUT \r\nWA \r\nWI \r\n";

/***/ })

}]);