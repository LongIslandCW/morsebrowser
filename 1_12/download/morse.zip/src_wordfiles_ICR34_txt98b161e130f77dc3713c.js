"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR34_txt"],{

/***/ "./src/wordfiles/ICR34.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR34.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "a foregone conclusion\r\na place for everything and everything in its place\r\nabsolute power corrupts absolutely\r\ncompassion fatigue\r\nelementary my dear watson\r\nforegone conclusion\r\nforewarned is forearmed\r\ngeneration x\r\nincluding, but not limited to\r\nkeep your nose to the grindstone\r\npull yourself up by your bootstraps\r\nthe dow jones industrial average\r\nit is not surprising that\r\nthis is all things considered\r\ndon’t take it personally\r\nan ounce of prevention is worth a pound of cure\r\neverything comes to those who wait\r\nmoderation in all things\r\nmoney is not everything\r\npossession is nine tenths of the law\r\nprevention is better than cure\r\nthe shoemakers son always goes barefoot\r\nthere is no accounting for tastes\r\nyou cant unscramble eggs\r\ncleanliness is next to godliness\r\ngrandfather clock\r\nin an interesting condition\r\npolitically correct\r\nbe represented in ascii text\r\nnot be represented in ascii\r\ncan not be represented in\r\nthat cannot be represented\r\nfamiliarity breeds contempt\r\nfirst impressions\r\nopportunity knocks\r\na sledgehammer to crack a nut\r\naccidentally on purpose\r\nbeat swords into ploughshares\r\nfreezing temperatures\r\ngenius is 1 percent inspiration and 99 percent perspiration\r\npomp and circumstance\r\nprepositional phrases\r\nthe food and drug administration\r\nprocrastination is the thief of time\r\n\r\n";

/***/ })

}]);