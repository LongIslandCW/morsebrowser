"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_INT10_txt"],{

/***/ "./src/wordfiles/INT10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/INT10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "<AR> \r\n<BT> \r\n<SK> \r\n599 \r\n73 \r\n5NN \r\nABT \r\nAGE \r\nAGN \r\nAM \r\nANT \r\nB4 \r\nBEEN \r\nBK \r\nBUG \r\nC \r\nCALL \r\nCFM \r\nCLEAR \r\nCPI \r\nCPY \r\nCQ \r\nCU \r\nCUAGN \r\nCUL \r\nCW \r\nDE \r\nDN \r\nDR \r\nDX \r\nEL \r\nES \r\nFB \r\nFER \r\nFM \r\nFT \r\nGA \r\nGE \r\nGM \r\nGN \r\nGND \r\nGUD \r\nHAM \r\nHI \r\nHPE \r\nHR \r\nHW \r\nHW? \r\nINFO \r\nK \r\nOK \r\nOM \r\nOP \r\nOT \r\nPSE \r\nPWR \r\nQRM \r\nQRN \r\nQRP \r\nQRQ \r\nQRS \r\nQRT \r\nQRZ \r\nQSB \r\nQSL \r\nQSO \r\nQSY \r\nQTH \r\nR \r\nRAIN \r\nRFI \r\nRIG \r\nRPRT \r\nRPT \r\nRR \r\nRST \r\nRX \r\nSIG \r\nSKED \r\nSOLID \r\nSRI \r\nSSB \r\nSUN \r\nT \r\nTEMP \r\nTKS \r\nTNX \r\nTU \r\nTX \r\nU \r\nUP \r\nUR \r\nVERT \r\nVY \r\nW \r\nWID \r\nWIND \r\nWPM \r\nWUD \r\nWX \r\nYAGI \r\nYRS \r\n";

/***/ })

}]);