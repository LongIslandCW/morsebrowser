"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR5_txt"],{

/***/ "./src/wordfiles/ICR5.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR5.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "A\r\nI\r\nAT\r\nIT\r\nNO\r\nTO\r\nAS\r\nSO\r\nOR\r\nAN\r\nON\r\nIN\r\nIS\r\nANT\r\nTOE\r\nONE\r\nRAT\r\nSAT\r\nEAT\r\nSIT\r\nCAR\r\nACE\r\nCAT\r\nOAR\r\nSET\r\nARE\r\nSEE\r\nACT\r\nTAN\r\nRAN\r\nEEL\r\nNOR\r\nTIN\r\nATE\r\nCAN\r\nOIL\r\nILL\r\nLOT\r\nCOT\r\nNOT\r\nTEN\r\nLIE\r\nALL\r\nITS\r\nLATE\r\nTORN\r\nEARN\r\nSAIL\r\nCOIN\r\nTALE\r\nRARE\r\nLOST\r\nTOOL\r\nROLL\r\nCOOT\r\nSOLE\r\nSTAN\r\nASIA\r\nROSE\r\nLOSE\r\nACRE\r\nONCE\r\nTONE\r\nLESS\r\nTEST\r\nCATS\r\nSORT\r\nLACE\r\nNEAR\r\nROOT\r\nCENT\r\nRATS\r\nCANT\r\nREST\r\nSLOT\r\nLOON\r\nEATS\r\nNEAT\r\nELSE\r\nALSO\r\nTILT\r\nCORE\r\nLETS\r\nLAST\r\nCOST\r\nSOOT\r\nSINE\r\nRENT\r\nISNT\r\nIOTA\r\nNOON\r\nACES\r\nNOTE\r\nCARS\r\nCOAT\r\nREEL\r\nCOAL\r\nEASE\r\nSARA\r\nCONE\r\nIRON\r\nRACE\r\nRISE\r\nCASE\r\nSOIL\r\nNICE\r\nSEEN\r\nSORE\r\nTELL\r\nSCAN\r\nTIRE\r\nRANT\r\nSELL\r\nCOOL\r\nNEON\r\nLEAN\r\nTOES\r\nLINE\r\nCORN\r\nOATS\r\nAREA\r\nSEAL\r\nSOON\r\nCITE\r\nOARS\r\nREAR\r\nTOSS\r\nLION\r\nTALL\r\nTART\r\nCOIL\r\nNOSE\r\nLOTS\r\nSALE\r\nSANE\r\nTENT\r\nLONE\r\nCARE\r\nRAIL\r\nCANE\r\nTEAR\r\nTREE\r\nTOTE\r\nCANS\r\nLOAN\r\nLENS\r\nLIST\r\nSEAT\r\nSTAR\r\nRAIN\r\nNAIL\r\nROAR\r\nREAL\r\nRIOT\r\nTAIL\r\n\r\n";

/***/ })

}]);