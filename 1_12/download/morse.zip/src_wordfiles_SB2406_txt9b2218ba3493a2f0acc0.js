"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2406_txt"],{

/***/ "./src/wordfiles/SB2406.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2406.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AL \r\nAR \r\nCA \r\nCO \r\nCT \r\n{DE|delaware} \r\nFL \r\n{GA|georgia} \r\n{HI|hawaii} \r\n{ID|idaho} \r\nIL \r\n{IN|indiana} \r\nIA \r\n{LA|louisiana} \r\nNE \r\nNH \r\nNC \r\nND \r\n{OH|ohio} \r\n\r\n\r\nPA \r\nRI \r\nSC \r\nSD \r\nTN \r\nUT \r\nWA \r\nWI \r\n";

/***/ })

}]);