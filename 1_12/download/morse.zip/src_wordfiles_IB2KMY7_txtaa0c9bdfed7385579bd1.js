"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2KMY7_txt"],{

/***/ "./src/wordfiles/IB2KMY7.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2KMY7.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "MY RIG KNWD\r\nANT DIPOLE\r\nANT YAGI\r\nOK OM SOLID CPY\r\nSOLID CPI\r\nFB CATHY\r\nNAME MIKE\r\nNAME HOWARD\r\nNAME RICH\r\nBEEN HAM TWO YRS\r\nSRI OM\r\nMY RIG ICOM\r\nMY RIG YAESU\r\nMY RIG TEN TEC\r\nMY RIG BOAT ANCHOR\r\nMY KEY BUG\r\nNICE SIG OM\r\n";

/***/ })

}]);