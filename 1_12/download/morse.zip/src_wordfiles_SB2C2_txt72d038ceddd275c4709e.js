"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2C2_txt"],{

/***/ "./src/wordfiles/SB2C2.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/SB2C2.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "{<AR>|end of message} \r\n{<BT>|pause} \r\n{<SK>|end of contact} \r\n{599|five nine nine} \r\n73 \r\n{5NN|five nine nine} \r\n{ABT|about} \r\nAGE \r\n{AGN|again} \r\n{AM|a m} \r\n{ANT|antenna} \r\n{B4|before} \r\nBEEN \r\n{BK|break} \r\nBUG \r\n{C|celsius} \r\nCALL \r\n{CFM|confirm} \r\nCLEAR \r\n{CPI|copy} \r\n{CPY|copy} \r\n{CQ|c q} \r\n{CU|see you} \r\n{CUAGN|see you again} \r\n{CUL|see you later} \r\n{CW|c w} \r\n{DE|from} \r\nDIPOLE \r\n{DN|down} \r\n{DR|dear} \r\n{DX|foreign countries} \r\n{EL|element} \r\n{ES|and} \r\n{F|fahrenheit}\r\n{FB|fine business} \r\n{FER|for} \r\n{FM|f m} \r\n{FT|feet} \r\n{GA|good afternoon} \r\n{GE|good evening} \r\n{GM|good morning} \r\n{GN|good night} \r\n{GND|ground} \r\n{GUD|good} \r\nHAM \r\n{HI|laugh} \r\n{HP|hope} \r\n{HPE|hope} \r\n{HR|here} \r\n{HW|how} \r\n{HW?|how copy} \r\nINFO \r\n{K|invitation to transmit} \r\n{OK|O K} \r\n{OM|old man} \r\n{OP|operator} \r\n{OT|old timer} \r\n{PSE|please} \r\n{PWR|power} \r\n{QRM|transmission is being interfered with} \r\n{QRN|troubled by static} \r\n{QRP|decrease power} \r\n{QRQ|send faster} \r\n{QRS|send slower} \r\n{QRT|stop sending} \r\n{QRZ|who is calling} \r\n{QSB|signals fading} \r\n{QSL|acknowledge receipt} \r\n{QSO|contact} \r\n{QSY|change to another frequency} \r\n{QTH|location} \r\n{R|roger} \r\nRAIN \r\nRETIRED \r\n{RFI|r f i} \r\nRIG \r\n{RPRT|report} \r\n{RPT|report} \r\n{RR|roger roger} \r\n{RST|r s t} \r\n{RX|receiver} \r\n{SIG|signal} \r\n{SKED|schedule} \r\nSOLID \r\n{SRI|sorry} \r\n{SSB|s s b} \r\nSUN \r\n{T|zero} \r\n{TEMP|temperature} \r\n{TKS|thanks} \r\n{TNX|thanks} \r\n{TU|thank you} \r\n{TX|transmitter} \r\n{U|you} \r\nUP \r\n{UR|your} \r\n{VERT|vertical} \r\n{VY|very} \r\n{W|watts} \r\n{WID|with} \r\nWIND \r\n{WPM|words per minute} \r\n{WUD|would} \r\n{WX|weather} \r\nYAGI \r\n{YRS|years}\r\n";

/***/ })

}]);