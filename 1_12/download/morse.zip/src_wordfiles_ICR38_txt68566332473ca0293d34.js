"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR38_txt"],{

/***/ "./src/wordfiles/ICR38.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR38.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "SI \r\n54 \r\nE5 \r\nE6 \r\nE6 \r\nHT \r\n6J \r\nSD \r\nI1 \r\n56 \r\n1T \r\nSI \r\n6D \r\nI1 \r\nES \r\nH5 \r\n6B \r\nBH \r\nTI \r\nI6 \r\nI4 \r\nDB \r\n56 \r\n5I \r\n6D \r\n1D \r\nS6 \r\n6J \r\nD1 \r\n5S \r\nSH \r\nST \r\nSH \r\nHT \r\nES \r\nVD \r\nI1 \r\nDJ \r\n6B \r\n6T \r\nT5 \r\nVT \r\n56 \r\nSV \r\nSE \r\n5B \r\nS1 \r\nHE \r\nVB \r\nSI \r\nH6 \r\n1H \r\nSD \r\nIE \r\nVS \r\n6H \r\nEJ \r\n5S \r\nT1 \r\nBH \r\n1H \r\n6S \r\nIB \r\nV4 \r\n1E \r\nSD \r\nE6 \r\n5J \r\nHE \r\nTS \r\nT5 \r\n15 \r\nVH \r\nTB \r\n6S \r\nSB \r\n54 \r\nHV \r\n1I \r\nE1 \r\nE6 \r\nE6 \r\n6T \r\n41 \r\nT1 \r\n4V \r\nDJ \r\n6H \r\nD1 \r\nE6 \r\nSJ \r\nHE \r\n4D \r\nIS \r\nDT \r\n64 \r\n5T \r\n6T \r\nHB \r\nIT \r\n14 \r\n6H \r\nT5 \r\nBI \r\n4E \r\nBE \r\n41 \r\nDJ \r\n4D \r\nV1 \r\nDJ \r\n66 \r\nJJ \r\n6S \r\n4V \r\nTV \r\nTB \r\nBJ \r\nS5 \r\nHS \r\n5H \r\nSH \r\nVB \r\n6B \r\n5J \r\nHI \r\nIH \r\nBB \r\nDV \r\nIV \r\nDJ \r\nSS \r\nJ5 \r\n4E \r\nJ5 \r\nHB \r\nD4 \r\nHH \r\nBE \r\nH6 \r\n5J \r\n65 \r\nIS \r\n64 \r\n6J \r\n1B \r\nB1 \r\nSD \r\n6V \r\n51 \r\nDH \r\nJJ \r\nSV \r\nJ6 \r\n45 \r\nTV \r\nV6 \r\n4D \r\n6E \r\nSB \r\n45 \r\nDJ \r\nH6 \r\nS5 \r\n44 \r\n6E \r\nD5 \r\n5V \r\nDE \r\nH1 \r\n1B \r\nDE \r\n15 \r\n4I \r\nEE \r\n6T \r\nSD \r\nIE \r\nVS \r\nV5 \r\nVE \r\n45 \r\n6B \r\nH5 \r\n1D \r\nT4 \r\n56 \r\n";

/***/ })

}]);