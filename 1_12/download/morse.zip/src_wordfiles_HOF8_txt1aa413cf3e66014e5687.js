"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_HOF8_txt"],{

/***/ "./src/wordfiles/HOF8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/HOF8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CO \r\nFL \r\n{OH|ohio} \r\n{OR|oregon} \r\nSC \r\nSD \r\n";

/***/ })

}]);