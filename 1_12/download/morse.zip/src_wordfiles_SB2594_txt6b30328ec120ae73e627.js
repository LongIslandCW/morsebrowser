"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2594_txt"],{

/***/ "./src/wordfiles/SB2594.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2594.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AB5TN DE N5DR GA FRED\r\nSOLID CPI\r\nUR RST 599 5NN\r\nATLANTA, GA\r\nORLANDO, FL\r\nSEATTLE, WA\r\nWASHINGTON, DC\r\nCHICAGO, IL\r\nBOISE, ID\r\nNR SFO, CA\r\nAGE 59\r\nWIND ES RAIN\r\nRETIRED COP\r\nRETIRED AIRLINE PILOT\r\nPWR 5W\r\n";

/***/ })

}]);