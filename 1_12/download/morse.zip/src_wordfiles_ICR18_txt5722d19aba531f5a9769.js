"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR18_txt"],{

/***/ "./src/wordfiles/ICR18.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR18.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "KY0IK/P \r\nSX24BYE \r\nDJ9JM/P \r\nNG6NE/P \r\nDJ7HU/P \r\nKE8OD/P \r\nSN2016SP \r\nDL4WR/P \r\nNQ8DE/P \r\nSX24DAU \r\nSN2013ZQ \r\nKQ6NK/P \r\nSX24BQV \r\nNA9MV/P \r\nNH0HL/P \r\nSN2017ET \r\nDJ2TW/P \r\nSN2010TQ \r\nI3ZIW/P \r\nDL1EP/P \r\nSX24RJJ \r\nNS4NU/P \r\nI4YKF/P \r\nDL8TD/P \r\nDJ2UC/P \r\nW3LQ/QRP \r\nDJ6FI/P \r\nW6CH/QRP \r\nDL2TK/P \r\nI6ZFX/P \r\nDJ0MB/P \r\nI2HQM/P \r\nDJ4CM/P \r\nI1STE/P \r\nW8KL/QRP \r\nI4GUY/P \r\nDL8HN/P \r\nKW1ET/P \r\nDJ8DK/P \r\nW1HN/QRP \r\nSN2019FO \r\nDJ9AF/P \r\nSX24VWU \r\nKL5WJ/P \r\nDJ7UH/P \r\nDL2WO/P \r\nI3KBL/P \r\nDJ6EB/P \r\nW8XA/QRP \r\nDJ9NL/P \r\nSN2019GI \r\nKB4YG/P \r\nI6YRG/P \r\nI4LEE/P \r\nKP2LH/P \r\nI4IEH/P \r\nKM7NF/P \r\nSN2019HF \r\nNK3RO/P \r\nKX1WR/P \r\nNP0WY/P \r\nNS3XZ/P \r\nDL0UN/P \r\nDJ2PX/P \r\nDJ3FU/P \r\nDJ0FC/P \r\nNL0VG/P \r\nDJ4YY/P \r\nI6TAJ/P \r\nSX24OAL \r\nKC7GG/P \r\nSX24DZK \r\nDJ6NQ/P \r\nNR0BK/P \r\nI5RSM/P \r\nKG2GC/P \r\nDL7QU/P \r\nDL2TR/P \r\nI1UNY/P \r\nKL4YR/P \r\nDJ0ZN/P \r\nSN2017PL \r\nDJ1VV/P \r\nKW4HD/P \r\nNO4LD/P \r\nI0KPK/P \r\nSX24RAW \r\nSN2016XR \r\nDL9XM/P \r\nSN2012KR \r\nSX24UIE \r\nDJ1IM/P \r\nKF0VT/P \r\nSX24RZT \r\nW1NM/QRP \r\nW6EJ/QRP \r\nKB9OR/P \r\nNO8HF/P \r\n\r\n";

/***/ })

}]);