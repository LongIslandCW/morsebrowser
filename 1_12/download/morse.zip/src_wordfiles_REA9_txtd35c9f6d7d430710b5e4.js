"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_REA9_txt"],{

/***/ "./src/wordfiles/REA9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/REA9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "R RR HW FB FER HR OB U UR\r\n";

/***/ })

}]);