"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2ARSKBT4_txt"],{

/***/ "./src/wordfiles/SB2ARSKBT4.txt":
/*!**************************************!*\
  !*** ./src/wordfiles/SB2ARSKBT4.txt ***!
  \**************************************/
/***/ ((module) => {

module.exports = "NICE TO CU AGN\r\nOP RIN\r\nANT DIPOLE UP IN TREE\r\nRETIRED AIR FORCE\r\nRIG TEN TEC\r\nTU FER INFO\r\nHPE CUAGN DR BOB\r\nHPE CUAGN DR HIRO san\r\n";

/***/ })

}]);