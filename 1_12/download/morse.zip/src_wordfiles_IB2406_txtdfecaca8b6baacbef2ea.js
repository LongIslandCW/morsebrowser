"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2406_txt"],{

/***/ "./src/wordfiles/IB2406.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/IB2406.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "AD0WE \r\nAI4PL \r\nG4FON \r\nG0POT \r\nWB0ISG \r\nN4DTR \r\nWB4UTB \r\nWB0HOA \r\nAA0TIN \r\nAC4LCD \r\nAB0CD \r\nN4FOH \r\nN0CDL\r\n";

/***/ })

}]);