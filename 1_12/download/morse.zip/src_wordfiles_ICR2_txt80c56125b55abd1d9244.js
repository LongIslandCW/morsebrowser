"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR2_txt"],{

/***/ "./src/wordfiles/ICR2.txt":
/*!********************************!*\
  !*** ./src/wordfiles/ICR2.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "OR\r\nCA\r\nNE\r\nIA\r\nAR\r\nLA\r\nIL\r\nAL\r\nIN\r\nTN\r\nNC\r\nSC\r\nRI\r\nCT\r\n";

/***/ })

}]);