"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2164_txt"],{

/***/ "./src/wordfiles/SB2164.txt":
/*!**********************************!*\
  !*** ./src/wordfiles/SB2164.txt ***!
  \**********************************/
/***/ ((module) => {

module.exports = "WO6W DE N1CC \r\nGA BOB \r\nOP ALAN \r\nANT DIPOLE UP 61 FT\r\nPWR 1W HI HI\r\nHPE CUAGN BOB\r\nPSE RPT INFO\r\nPSE RPT RIG ES ANT\r\nPSE RPT CALL\r\nPWR 1TT W  \r\n";

/***/ })

}]);