"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2C3_txt"],{

/***/ "./src/wordfiles/IB2C3.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/IB2C3.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "W2LCW DE K2UPS GE ES TNX FER CALL\t\r\nUR RST 599 5NN\r\nQTH LONG ISLAND, NY LONG ISLAND, NY\r\nNAME RICH RICH\r\nOK HW? <AR> W2LCW DE K2UPS\r\n";

/***/ })

}]);