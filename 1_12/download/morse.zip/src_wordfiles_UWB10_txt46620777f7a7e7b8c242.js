"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_UWB10_txt"],{

/***/ "./src/wordfiles/UWB10.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/UWB10.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "CUB WHO HUB LOW COW OWL CLUB BOLD COULD HOWL CHOW CHUB WOULD OUCH FOLD CLUB CLOUD LOUD\r\n";

/***/ })

}]);