"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB228BK5_txt"],{

/***/ "./src/wordfiles/SB228BK5.txt":
/*!************************************!*\
  !*** ./src/wordfiles/SB228BK5.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "W2ITT I2RTF N2DEE N2GSL N2PPI W2NDG W2LCW WB8WUB AC8LL AB8DU WB8FAR  \r\n";

/***/ })

}]);