"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB2QXV7_txt"],{

/***/ "./src/wordfiles/IB2QXV7.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/IB2QXV7.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "GA ES TNX FER CALL\r\nGE ES TNX FER RPRT\r\nTNX FER FB RPRT\r\nSOLID CPI RON\r\nQTH NR PHOENIX\r\nQTH PORTLAND\r\nWX RAIN ES WIND\r\nWX SUN ES NICE\r\nRIG FLEX\r\nRIG QSX\r\nRIG TEN TEC\r\nRIG TEN TEC\r\nRIG BOAT ANCHOR\r\nANT VERT\r\nNICE FIST OT\r\nNICE SIG\r\nWILL QRT NOW\r\nTNX FER FB QSO\r\nGUD DX ES HPE CUAGN SOCHO san  \r\n";

/***/ })

}]);