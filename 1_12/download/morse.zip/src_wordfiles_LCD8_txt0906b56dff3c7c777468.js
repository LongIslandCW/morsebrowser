"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_LCD8_txt"],{

/***/ "./src/wordfiles/LCD8.txt":
/*!********************************!*\
  !*** ./src/wordfiles/LCD8.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "CT \r\n{ID|idaho} \r\nIL \r\n{IN|indiana} \r\nNC \r\nND \r\nSC \r\nSD \r\nTN \r\n\r\n";

/***/ })

}]);