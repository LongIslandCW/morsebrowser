"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_SB2QXV4_txt"],{

/***/ "./src/wordfiles/SB2QXV4.txt":
/*!***********************************!*\
  !*** ./src/wordfiles/SB2QXV4.txt ***!
  \***********************************/
/***/ ((module) => {

module.exports = "GA ES TNX FER CALL\r\nGE ES TNX FER RPRT\r\nTNX FER FB RPRT\r\nSOLID CPI RON\r\nQTH NR PHOENIX\r\nQTH PORTLAND\r\nWX RAIN ES WIND\r\nWX SUN ES NICE\r\nRIG FLEX\r\nRIG QSX\r\nRIG TEN TEC\r\nRIG TEN TEC\r\nRIG BOAT ANCHOR\r\nANT VERT\r\nNICE FIST OT\r\nNICE SIG\r\nWILL QRT NOW\r\nTNX FER FB QSO\r\nGUD DX ES HPE CUAGN SOCHO san  \r\n";

/***/ })

}]);