"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_UWB9_txt"],{

/***/ "./src/wordfiles/UWB9.txt":
/*!********************************!*\
  !*** ./src/wordfiles/UWB9.txt ***!
  \********************************/
/***/ ((module) => {

module.exports = "FB CUL WUD U CW CUD HW CU WL\r\n";

/***/ })

}]);