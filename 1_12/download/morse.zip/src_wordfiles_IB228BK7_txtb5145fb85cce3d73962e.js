"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_IB228BK7_txt"],{

/***/ "./src/wordfiles/IB228BK7.txt":
/*!************************************!*\
  !*** ./src/wordfiles/IB228BK7.txt ***!
  \************************************/
/***/ ((module) => {

module.exports = "HOWARD BTU BK\r\nBK FB RICH AGE 28 RETIRED HI HI BK\r\nBK FB ES TU FER INFO UR RIG DOING FB BK\r\nBK RR UR ANT DOING FB WID GUD SIG HR BK\r\nBK ANT EFHW IN ATTIC BK\r\n\r\n";

/***/ })

}]);