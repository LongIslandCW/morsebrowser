"use strict";
(self["webpackChunk"] = self["webpackChunk"] || []).push([["src_wordfiles_ICR35_txt"],{

/***/ "./src/wordfiles/ICR35.txt":
/*!*********************************!*\
  !*** ./src/wordfiles/ICR35.txt ***!
  \*********************************/
/***/ ((module) => {

module.exports = "IH5 \r\nIII \r\nIH5 \r\n5SI \r\nIES \r\nEES \r\n5SE \r\nEIS \r\nEE5 \r\nS55 \r\n5ES \r\nIHI \r\nISS \r\nIIE \r\nHIS \r\n5EE \r\nEEE \r\n55S \r\n5EI \r\n5SI \r\nB16 \r\nBBH \r\nBH1 \r\nHH6 \r\nHB1 \r\nB6B \r\nBBB \r\nHBH \r\n11H \r\n11H \r\nH61 \r\nH11 \r\nBBH \r\nB1B \r\n166 \r\nB66 \r\n6HH \r\nH1B \r\n6HB \r\nHHH \r\nJBJ \r\nJBB \r\nJB1 \r\nW11 \r\n1WW \r\nJBB \r\nBBJ \r\nBW1 \r\nJ1J \r\nJWW \r\nJB1 \r\nB1W \r\nJ1W \r\nJBB \r\nWWW \r\nWBW \r\nJBW \r\nBJJ \r\nW1W \r\nJ11 \r\nU11 \r\nS61 \r\nS6U \r\nU16 \r\nUUI \r\nU66 \r\n666 \r\n661 \r\nIUU \r\nSSI \r\nI16 \r\nUI1 \r\n1SS \r\n6I1 \r\n1I6 \r\nI16 \r\n1I6 \r\nS1S \r\nSUS \r\n1SU \r\n44J \r\nBBV \r\nB4J \r\n4BV \r\nB4H \r\nHB4 \r\nVJB \r\n4BV \r\nVJ4 \r\nHVH \r\nHV4 \r\nVBH \r\nVBB \r\nJ4H \r\nBHH \r\nH4B \r\nBHH \r\nVB4 \r\nJHB \r\nHB4 \r\nUSU \r\nEST \r\nU6T \r\nUSS \r\nS6T \r\nUEE \r\nSSU \r\nESS \r\nU66 \r\nTT6 \r\nTST \r\n6TS \r\n6S6 \r\n6S6 \r\nE6T \r\nETS \r\nSTE \r\nTTU \r\nTUU \r\nVEB \r\nVBB \r\n4EE \r\nVV4 \r\nEEE \r\nVVE \r\n4BB \r\n4EB \r\nWVW \r\nEBW \r\nVBB \r\nV4E \r\nW4W \r\nBBE \r\nBB4 \r\n4V4 \r\nEBB \r\nVEV \r\nVVE \r\n4VE \r\n5H5 \r\nJJH \r\n5TI \r\nH5T \r\nHIT \r\nTHT \r\nJHH \r\n5TT \r\nJI5 \r\n5JT \r\n5IJ \r\nIIJ \r\nHIJ \r\nIIH \r\nIT5 \r\nJH5 \r\nH5J \r\nJTI \r\nT55 \r\nHHI \r\nHEU \r\nEUJ \r\nHHI \r\nEHI \r\nJIJ \r\nJEU \r\nHHJ \r\nIJU \r\nEJE \r\nHIU \r\nJEU \r\nUUE \r\nJHU \r\nHHU \r\nUIJ \r\nHUI \r\nHEH \r\nIHH \r\nHIJ \r\nIEH \r\nHWW \r\n6WH \r\nHDV \r\nVV6 \r\n66V \r\nVVH \r\n6HD \r\nHH6 \r\nHWV \r\nVD6 \r\nVVD \r\n6DW \r\nDVD \r\nBSB \r\nHHE \r\nEH5 \r\n5SS \r\nSSH \r\nS5H \r\nBBE \r\n55S \r\nESH \r\n5EH \r\nH5S \r\nHBH \r\nS5E \r\nBB5 \r\nBHE \r\nESE \r\n5SH \r\nBHE \r\nBSS \r\nEEE \r\n";

/***/ })

}]);